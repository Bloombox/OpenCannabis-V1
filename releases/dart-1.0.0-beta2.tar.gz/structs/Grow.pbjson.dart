///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Grow_pbjson;

const Grow$json = const {
  '1': 'Grow',
  '2': const [
    const {'1': 'GENERIC', '2': 0},
    const {'1': 'INDOOR', '2': 1},
    const {'1': 'GREENHOUSE', '2': 2},
    const {'1': 'OUTDOOR', '2': 3},
  ],
};

