///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Brand_pbjson;

const Brand$json = const {
  '1': 'Brand',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.Name', '10': 'name'},
    const {'1': 'parent', '3': 2, '4': 1, '5': 11, '6': '.Brand', '10': 'parent'},
    const {'1': 'summary', '3': 3, '4': 1, '5': 11, '6': '.Content', '10': 'summary'},
    const {'1': 'media', '3': 20, '4': 3, '5': 11, '6': '.MediaItem', '10': 'media'},
  ],
};

