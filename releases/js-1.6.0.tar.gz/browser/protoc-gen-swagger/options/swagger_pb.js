/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Operation', null, global);
goog.exportSymbol('proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Schema', null, global);
goog.exportSymbol('proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Swagger', null, global);
goog.exportSymbol('proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Tag', null, global);

/**
 * A tuple of {field number, class constructor} for the extension
 * field named `openapiv2Swagger`.
 * @type {!jspb.ExtensionFieldInfo<!proto.grpc.gateway.protoc_gen_swagger.options.Swagger>}
 */
proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Swagger = new jspb.ExtensionFieldInfo(
    1042,
    {openapiv2Swagger: 0},
    proto.grpc.gateway.protoc_gen_swagger.options.Swagger,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         proto.grpc.gateway.protoc_gen_swagger.options.Swagger.toObject),
    0);

proto.google.protobuf.FileOptions.extensionsBinary[1042] = new jspb.ExtensionFieldBinaryInfo(
    proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Swagger,
    jspb.BinaryReader.prototype.readMessage,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.grpc.gateway.protoc_gen_swagger.options.Swagger.serializeBinaryToWriter,
    proto.grpc.gateway.protoc_gen_swagger.options.Swagger.deserializeBinaryFromReader,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.FileOptions.extensions[1042] = proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Swagger;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `openapiv2Operation`.
 * @type {!jspb.ExtensionFieldInfo<!proto.grpc.gateway.protoc_gen_swagger.options.Operation>}
 */
proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Operation = new jspb.ExtensionFieldInfo(
    1042,
    {openapiv2Operation: 0},
    proto.grpc.gateway.protoc_gen_swagger.options.Operation,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         proto.grpc.gateway.protoc_gen_swagger.options.Operation.toObject),
    0);

proto.google.protobuf.MethodOptions.extensionsBinary[1042] = new jspb.ExtensionFieldBinaryInfo(
    proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Operation,
    jspb.BinaryReader.prototype.readMessage,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.grpc.gateway.protoc_gen_swagger.options.Operation.serializeBinaryToWriter,
    proto.grpc.gateway.protoc_gen_swagger.options.Operation.deserializeBinaryFromReader,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.MethodOptions.extensions[1042] = proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Operation;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `openapiv2Schema`.
 * @type {!jspb.ExtensionFieldInfo<!proto.grpc.gateway.protoc_gen_swagger.options.Schema>}
 */
proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Schema = new jspb.ExtensionFieldInfo(
    1042,
    {openapiv2Schema: 0},
    proto.grpc.gateway.protoc_gen_swagger.options.Schema,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         proto.grpc.gateway.protoc_gen_swagger.options.Schema.toObject),
    0);

proto.google.protobuf.MessageOptions.extensionsBinary[1042] = new jspb.ExtensionFieldBinaryInfo(
    proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Schema,
    jspb.BinaryReader.prototype.readMessage,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.grpc.gateway.protoc_gen_swagger.options.Schema.serializeBinaryToWriter,
    proto.grpc.gateway.protoc_gen_swagger.options.Schema.deserializeBinaryFromReader,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.MessageOptions.extensions[1042] = proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Schema;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `openapiv2Tag`.
 * @type {!jspb.ExtensionFieldInfo<!proto.grpc.gateway.protoc_gen_swagger.options.Tag>}
 */
proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Tag = new jspb.ExtensionFieldInfo(
    1042,
    {openapiv2Tag: 0},
    proto.grpc.gateway.protoc_gen_swagger.options.Tag,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         proto.grpc.gateway.protoc_gen_swagger.options.Tag.toObject),
    0);

proto.google.protobuf.ServiceOptions.extensionsBinary[1042] = new jspb.ExtensionFieldBinaryInfo(
    proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Tag,
    jspb.BinaryReader.prototype.readMessage,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.grpc.gateway.protoc_gen_swagger.options.Tag.serializeBinaryToWriter,
    proto.grpc.gateway.protoc_gen_swagger.options.Tag.deserializeBinaryFromReader,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.ServiceOptions.extensions[1042] = proto.grpc.gateway.protoc_gen_swagger.options.openapiv2Tag;

