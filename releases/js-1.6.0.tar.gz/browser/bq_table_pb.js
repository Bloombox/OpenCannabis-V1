/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.gen_bq_schema.tableDescription', null, global);
goog.exportSymbol('proto.gen_bq_schema.tableName', null, global);

/**
 * A tuple of {field number, class constructor} for the extension
 * field named `tableName`.
 * @type {!jspb.ExtensionFieldInfo<string>}
 */
proto.gen_bq_schema.tableName = new jspb.ExtensionFieldInfo(
    1021,
    {tableName: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

proto.google.protobuf.MessageOptions.extensionsBinary[1021] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.tableName,
    jspb.BinaryReader.prototype.readString,
    jspb.BinaryWriter.prototype.writeString,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.MessageOptions.extensions[1021] = proto.gen_bq_schema.tableName;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `tableDescription`.
 * @type {!jspb.ExtensionFieldInfo<string>}
 */
proto.gen_bq_schema.tableDescription = new jspb.ExtensionFieldInfo(
    1026,
    {tableDescription: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

proto.google.protobuf.MessageOptions.extensionsBinary[1026] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.tableDescription,
    jspb.BinaryReader.prototype.readString,
    jspb.BinaryWriter.prototype.writeString,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
proto.google.protobuf.MessageOptions.extensions[1026] = proto.gen_bq_schema.tableDescription;

