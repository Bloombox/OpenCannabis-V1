/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.structs.Shelf', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.structs.Shelf = {
  GENERIC_SHELF: 0,
  ECONOMY: 1,
  MIDSHELF: 2,
  TOPSHELF: 3
};

