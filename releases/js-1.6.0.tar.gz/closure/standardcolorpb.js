/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.content.StandardColor');

/**
 * @enum {number}
 */
proto.opencannabis.content.StandardColor = {
  UNSPECIFIED_COLOR: 0,
  RED: 1,
  GREEN: 2,
  BLUE: 3,
  YELLOW: 4,
  PURPLE: 5,
  ORANGE: 6,
  PINK: 7,
  GRAY: 8,
  BROWN: 9
};

