/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.crypto.HashAlgorithm');

/**
 * @enum {number}
 */
proto.opencannabis.crypto.HashAlgorithm = {
  SHA1: 0,
  MD5: 1,
  SHA256: 2,
  SHA384: 3,
  SHA512: 4,
  MURMUR: 6
};

