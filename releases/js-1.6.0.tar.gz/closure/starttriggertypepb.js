/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.inventory.rfid.StartTriggerType');

/**
 * @enum {number}
 */
proto.opencannabis.inventory.rfid.StartTriggerType = {
  NO_START_TRIGGER: 0,
  IMMEDIATE: 1,
  PERIODIC: 2,
  GPIO_START: 3
};

