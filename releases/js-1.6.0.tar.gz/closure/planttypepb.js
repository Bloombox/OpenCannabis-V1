/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.PlantType');

/**
 * @enum {number}
 */
proto.opencannabis.products.PlantType = {
  UNSPECIFIED_PLANT: 0,
  SEED: 1,
  CLONE: 2
};

