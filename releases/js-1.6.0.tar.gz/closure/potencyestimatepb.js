/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.PotencyEstimate');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.PotencyEstimate = {
  LIGHT: 0,
  MEDIUM: 1,
  HEAVY: 2,
  SUPER: 3
};

