/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.ApothecaryType');

/**
 * @enum {number}
 */
proto.opencannabis.products.ApothecaryType = {
  UNSPECIFIED_APOTHECARY: 0,
  TOPICAL: 1,
  TINCTURE: 2,
  CAPSULE: 3,
  INJECTOR: 4
};

