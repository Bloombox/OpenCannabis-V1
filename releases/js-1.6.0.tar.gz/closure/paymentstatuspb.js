/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.PaymentStatus');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentStatus = {
  NOT_APPLICABLE: 0,
  WAITING: 1,
  PREAUTHORIZED: 2,
  BOUNCED: 3,
  RETRIED: 4
};

