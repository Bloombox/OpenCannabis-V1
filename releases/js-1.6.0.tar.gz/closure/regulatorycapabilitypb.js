/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.inventory.rfid.RegulatoryCapability');

/**
 * @enum {number}
 */
proto.opencannabis.inventory.rfid.RegulatoryCapability = {
  UNSPECIFIED_REGULATORY_REGION: 0,
  US_FCC: 1,
  ETSI_302_208: 2,
  ETSI_300_220: 3,
  AUSTRALIA_LIPD_1W: 4,
  AUSTRALIA_LIPD_4W: 5,
  JAPAN_ARIB_STD_T89: 6,
  HONGKONG_OFTA_1049: 7,
  TAIWAN_DGT_LP0002: 8,
  KOREA_MIC_ARTICLE_5_2: 9
};

