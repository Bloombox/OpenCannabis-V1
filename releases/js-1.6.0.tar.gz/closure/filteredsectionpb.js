/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.menu.section.FilteredSection');

/**
 * @enum {number}
 */
proto.opencannabis.products.menu.section.FilteredSection = {
  ON_SALE: 0,
  HOUSE: 1,
  CBD: 2,
  SEARCH: 3
};

