/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.oauth.ResponseType');

/**
 * @enum {number}
 */
proto.opencannabis.oauth.ResponseType = {
  UNSPECIFIED_RESPONSE_TYPE: 0,
  TOKEN: 1,
  CODE: 2,
  ID_TOKEN: 3
};

