/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.inventory.rfid.StopTriggerType');

/**
 * @enum {number}
 */
proto.opencannabis.inventory.rfid.StopTriggerType = {
  NO_STOP_TRIGGER: 0,
  DURATION: 1,
  GPIO_STOP: 2
};

