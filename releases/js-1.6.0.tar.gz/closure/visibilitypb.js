/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.core.Visibility');

/**
 * @enum {number}
 */
proto.core.Visibility = {
  PUBLIC: 0,
  PRIVATE: 1,
  PROTECTED: 2,
  PACKAGE: 3,
  EXPORT: 4
};

