/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.person.Gender');

/**
 * @enum {number}
 */
proto.opencannabis.person.Gender = {
  UNSPECIFIED: 0,
  MALE: 1,
  FEMALE: 2,
  OTHER: 3
};

