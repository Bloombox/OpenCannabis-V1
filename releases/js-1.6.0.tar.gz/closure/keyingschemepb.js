/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.crypto.KeyingScheme');

/**
 * @enum {number}
 */
proto.opencannabis.crypto.KeyingScheme = {
  RSA: 0,
  ECC: 1,
  DSA: 2,
  EDDSA: 3
};

