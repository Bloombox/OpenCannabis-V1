/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.MerchandiseType');

/**
 * @enum {number}
 */
proto.opencannabis.products.MerchandiseType = {
  UNSPECIFIED_MERCHANDISE: 0,
  CLOTHING: 1,
  GLASSWARE: 2,
  CONTAINER: 3,
  LIGHTER: 4,
  TSHIRT: 5,
  HOODIE: 6,
  HAT: 7
};

