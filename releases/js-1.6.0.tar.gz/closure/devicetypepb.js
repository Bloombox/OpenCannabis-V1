/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.device.DeviceType');

/**
 * @enum {number}
 */
proto.opencannabis.device.DeviceType = {
  UNKNOWN_DEVICE_TYPE: 0,
  DESKTOP: 1,
  PHONE: 2,
  TABLET: 3,
  TV: 4,
  EMBEDDED: 5,
  SERVER: 6
};

