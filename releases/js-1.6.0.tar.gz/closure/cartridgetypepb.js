/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.CartridgeType');

/**
 * @enum {number}
 */
proto.opencannabis.products.CartridgeType = {
  UNSPECIFIED_CARTRIDGE: 0,
  CARTRIDGE: 1,
  BATTERY: 2,
  KIT: 3
};

