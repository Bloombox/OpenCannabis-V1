/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.crypto.StreamCipher');

/**
 * @enum {number}
 */
proto.opencannabis.crypto.StreamCipher = {
  UNSPECIFIED_STREAM_CIPHER: 0,
  RC5: 1,
  RC6: 2,
  CHACHA20: 3
};

