/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.inventory.rfid.ReaderModel');

/**
 * @enum {number}
 */
proto.opencannabis.inventory.rfid.ReaderModel = {
  UNRECOGNIZED_READER: 0,
  SPEEDWAY_R120: 1,
  SPEEDWAY_R220: 2,
  SPEEDWAY_R420: 2001002,
  SPEEDWAY_XPORTAL: 4,
  ALIEN_ALRH450: 5,
  ALIEN_F800: 6,
  ALIEN_ALR9680: 7
};

