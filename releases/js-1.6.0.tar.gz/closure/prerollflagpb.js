/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.PrerollFlag');

/**
 * @enum {number}
 */
proto.opencannabis.products.PrerollFlag = {
  NO_PREROLL_FLAGS: 0,
  HASH_INFUSED: 1,
  KIEF_INFUSED: 2,
  FORTIFIED: 3,
  FULL_FLOWER: 4,
  CONTAINS_TOBACCO: 5
};

