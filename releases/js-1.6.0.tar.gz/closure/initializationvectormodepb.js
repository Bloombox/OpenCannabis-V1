/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.crypto.InitializationVectorMode');

/**
 * @enum {number}
 */
proto.opencannabis.crypto.InitializationVectorMode = {
  STATIC_IV: 0,
  TOTP: 1,
  COUNTER: 2
};

