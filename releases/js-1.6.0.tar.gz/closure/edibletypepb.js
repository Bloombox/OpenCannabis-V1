/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.EdibleType');

/**
 * @enum {number}
 */
proto.opencannabis.products.EdibleType = {
  UNSPECIFIED_EDIBLE: 0,
  CHOCOLATE: 1,
  BAKED_GOOD: 2,
  CANDY: 3,
  BEVERAGE: 4,
  LOZENGE: 5,
  SUBLINGUAL: 6,
  GUMMY: 7,
  BUTTER: 8,
  OILS: 9,
  CEREAL: 10
};

