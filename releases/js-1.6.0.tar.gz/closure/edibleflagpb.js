/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.EdibleFlag');

/**
 * @enum {number}
 */
proto.opencannabis.products.EdibleFlag = {
  NO_EDIBLE_FLAG: 0,
  VEGAN: 1,
  GLUTEN_FREE: 2,
  SUGAR_FREE: 3,
  FAIR_TRADE: 4,
  ORGANIC: 5,
  LOCAL: 6
};

