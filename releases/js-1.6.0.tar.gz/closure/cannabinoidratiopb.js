/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.CannabinoidRatio');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.CannabinoidRatio = {
  NO_CANNABINOID_PREFERENCE: 0,
  THC_ONLY: 1,
  THC_OVER_CBD: 2,
  EQUAL: 3,
  CBD_OVER_THC: 4,
  CBD_ONLY: 5
};

