/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.menu.section.SectionFlag');

/**
 * @enum {number}
 */
proto.opencannabis.products.menu.section.SectionFlag = {
  HIDDEN: 0,
  FEATURED: 1
};

