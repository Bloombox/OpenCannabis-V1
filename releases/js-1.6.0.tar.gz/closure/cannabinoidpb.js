/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.Cannabinoid');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.Cannabinoid = {
  THC: 0,
  THC_A: 1,
  THC_V: 2,
  CBD: 10,
  CBD_A: 11,
  CBD_V: 12,
  CBD_VA: 13,
  CBC: 20,
  CBG: 30,
  CBG_A: 31,
  CBN: 40,
  CBV: 50,
  CBV_A: 51
};

