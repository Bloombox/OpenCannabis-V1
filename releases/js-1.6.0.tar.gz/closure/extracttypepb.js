/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.ExtractType');

/**
 * @enum {number}
 */
proto.opencannabis.products.ExtractType = {
  UNSPECIFIED_EXTRACT: 0,
  OIL: 1,
  WAX: 2,
  SHATTER: 3,
  KIEF: 4,
  HASH: 5,
  LIVE_RESIN: 6,
  ROSIN: 7,
  CRUMBLE: 8,
  SAUCE: 9,
  SUGAR: 10
};

