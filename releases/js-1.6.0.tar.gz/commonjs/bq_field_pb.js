/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();

var google_protobuf_descriptor_pb = require('google-protobuf/google/protobuf/descriptor_pb.js');
goog.object.extend(proto, google_protobuf_descriptor_pb);
goog.exportSymbol('proto.gen_bq_schema.description', null, global);
goog.exportSymbol('proto.gen_bq_schema.ignore', null, global);
goog.exportSymbol('proto.gen_bq_schema.require', null, global);
goog.exportSymbol('proto.gen_bq_schema.typeOverride', null, global);

/**
 * A tuple of {field number, class constructor} for the extension
 * field named `require`.
 * @type {!jspb.ExtensionFieldInfo<boolean>}
 */
proto.gen_bq_schema.require = new jspb.ExtensionFieldInfo(
    1022,
    {require: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

google_protobuf_descriptor_pb.FieldOptions.extensionsBinary[1022] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.require,
    jspb.BinaryReader.prototype.readBool,
    jspb.BinaryWriter.prototype.writeBool,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
google_protobuf_descriptor_pb.FieldOptions.extensions[1022] = proto.gen_bq_schema.require;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `typeOverride`.
 * @type {!jspb.ExtensionFieldInfo<string>}
 */
proto.gen_bq_schema.typeOverride = new jspb.ExtensionFieldInfo(
    1023,
    {typeOverride: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

google_protobuf_descriptor_pb.FieldOptions.extensionsBinary[1023] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.typeOverride,
    jspb.BinaryReader.prototype.readString,
    jspb.BinaryWriter.prototype.writeString,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
google_protobuf_descriptor_pb.FieldOptions.extensions[1023] = proto.gen_bq_schema.typeOverride;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `ignore`.
 * @type {!jspb.ExtensionFieldInfo<boolean>}
 */
proto.gen_bq_schema.ignore = new jspb.ExtensionFieldInfo(
    1024,
    {ignore: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

google_protobuf_descriptor_pb.FieldOptions.extensionsBinary[1024] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.ignore,
    jspb.BinaryReader.prototype.readBool,
    jspb.BinaryWriter.prototype.writeBool,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
google_protobuf_descriptor_pb.FieldOptions.extensions[1024] = proto.gen_bq_schema.ignore;


/**
 * A tuple of {field number, class constructor} for the extension
 * field named `description`.
 * @type {!jspb.ExtensionFieldInfo<string>}
 */
proto.gen_bq_schema.description = new jspb.ExtensionFieldInfo(
    1025,
    {description: 0},
    null,
     /** @type {?function((boolean|undefined),!jspb.Message=): !Object} */ (
         null),
    0);

google_protobuf_descriptor_pb.FieldOptions.extensionsBinary[1025] = new jspb.ExtensionFieldBinaryInfo(
    proto.gen_bq_schema.description,
    jspb.BinaryReader.prototype.readString,
    jspb.BinaryWriter.prototype.writeString,
    undefined,
    undefined,
    false);
// This registers the extension field with the extended class, so that
// toObject() will function correctly.
google_protobuf_descriptor_pb.FieldOptions.extensions[1025] = proto.gen_bq_schema.description;

goog.object.extend(exports, proto.gen_bq_schema);
