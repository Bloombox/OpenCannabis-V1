/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.structs.labtesting.AromaFlavor');

/**
 * @enum {number}
 */
proto.structs.labtesting.AromaFlavor = {
  PINE: 0,
  LEMON: 1,
  PEPPER: 2,
  LAVENDER: 3,
  HOPS: 4
};

