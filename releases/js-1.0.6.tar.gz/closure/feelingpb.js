/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.structs.labtesting.Feeling');

/**
 * @enum {number}
 */
proto.structs.labtesting.Feeling = {
  GROUNDING: 0,
  SLEEP: 1,
  CALMING: 2,
  STIMULATING: 3,
  FUNNY: 4,
  FOCUS: 5,
  PASSION: 6
};

