///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Flower_pbjson;

const Flower$json = const {
  '1': 'Flower',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.ProductKey', '10': 'key'},
    const {'1': 'product_data', '3': 20, '4': 1, '5': 11, '6': '.ProductContent', '10': 'productData'},
    const {'1': 'material_data', '3': 21, '4': 1, '5': 11, '6': '.MaterialsData', '10': 'materialData'},
    const {'1': 'flags', '3': 22, '4': 1, '5': 11, '6': '.FlagsDescriptor', '10': 'flags'},
    const {'1': 'pricing', '3': 23, '4': 1, '5': 11, '6': '.ProductPricing', '10': 'pricing'},
  ],
};

