///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Product_pbjson;

const Product$json = const {
  '1': 'Product',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.ProductKey', '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 11, '6': '.ProductType', '10': 'type'},
    const {'1': 'data', '3': 3, '4': 1, '5': 11, '6': '.google.protobuf.Any', '10': 'data'},
  ],
};

