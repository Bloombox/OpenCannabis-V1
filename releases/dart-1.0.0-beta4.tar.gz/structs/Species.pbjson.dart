///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Species_pbjson;

const Species$json = const {
  '1': 'Species',
  '2': const [
    const {'1': 'UNSPECIFIED', '2': 0},
    const {'1': 'SATIVA', '2': 1},
    const {'1': 'HYBRID_SATIVA', '2': 2},
    const {'1': 'HYBRID', '2': 3},
    const {'1': 'HYBRID_INDICA', '2': 4},
    const {'1': 'INDICA', '2': 5},
  ],
};

