///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Language_pbjson;

const Language$json = const {
  '1': 'Language',
  '2': const [
    const {'1': 'ENGLISH', '2': 0},
    const {'1': 'SPANISH', '2': 1},
    const {'1': 'FRENCH', '2': 2},
  ],
};

