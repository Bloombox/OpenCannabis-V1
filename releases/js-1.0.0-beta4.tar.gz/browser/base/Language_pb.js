/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.Language', null, global);
/**
 * @enum {number}
 */
proto.Language = {
  ENGLISH: 0,
  SPANISH: 1,
  FRENCH: 2
};

