/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.SaleType');

/**
 * @enum {number}
 */
proto.SaleType = {
  PERCENTAGE: 0,
  BOGO: 1,
  LOYALTY: 2
};

