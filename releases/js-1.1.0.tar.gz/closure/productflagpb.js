/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.structs.ProductFlag');

/**
 * @enum {number}
 */
proto.structs.ProductFlag = {
  VISIBLE: 0,
  PREMIUM: 1,
  FEATURED: 2,
  ORGANIC: 3,
  EXCLUSIVE: 4,
  IN_HOUSE: 5,
  LAST_CHANCE: 6,
  LIMITED_TIME: 7
};

