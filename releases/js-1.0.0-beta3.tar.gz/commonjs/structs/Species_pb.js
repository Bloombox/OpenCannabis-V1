/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();

goog.exportSymbol('proto.Species', null, global);
/**
 * @enum {number}
 */
proto.Species = {
  UNSPECIFIED: 0,
  SATIVA: 1,
  HYBRID_SATIVA: 2,
  HYBRID: 3,
  HYBRID_INDICA: 4,
  INDICA: 5
};

goog.object.extend(exports, proto);
