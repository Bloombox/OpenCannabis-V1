/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.PricingType');

/**
 * @enum {number}
 */
proto.PricingType = {
  UNIT: 0,
  WEIGHTED: 1,
  FREEBIE: 2
};

