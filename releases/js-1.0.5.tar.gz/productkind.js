/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.ProductKind');

/**
 * @enum {number}
 */
proto.ProductKind = {
  FLOWERS: 0,
  EDIBLES: 1,
  EXTRACTS: 2,
  PREROLLS: 3,
  APOTHECARY: 4,
  CARTRIDGES: 5,
  PLANTS: 6,
  MERCHANDISE: 7
};

