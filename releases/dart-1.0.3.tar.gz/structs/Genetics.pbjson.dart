///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Genetics_pbjson;

const Genetics$json = const {
  '1': 'Genetics',
  '2': const [
    const {'1': 'male', '3': 1, '4': 1, '5': 11, '6': '.Name', '10': 'male'},
    const {'1': 'female', '3': 2, '4': 1, '5': 11, '6': '.Name', '10': 'female'},
  ],
};

