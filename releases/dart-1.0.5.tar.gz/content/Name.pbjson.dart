///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library content_Name_pbjson;

const Name$json = const {
  '1': 'Name',
  '2': const [
    const {'1': 'primary', '3': 1, '4': 1, '5': 9, '10': 'primary'},
    const {'1': 'display', '3': 2, '4': 1, '5': 9, '10': 'display'},
  ],
};

