///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library content_MaterialsData_pbjson;

const MaterialsData$json = const {
  '1': 'MaterialsData',
  '2': const [
    const {'1': 'ingredients', '3': 1, '4': 3, '5': 9, '10': 'ingredients'},
    const {'1': 'grow', '3': 2, '4': 1, '5': 14, '6': '.structs.Grow', '10': 'grow'},
    const {'1': 'species', '3': 3, '4': 1, '5': 14, '6': '.structs.Species', '10': 'species'},
    const {'1': 'genetics', '3': 4, '4': 1, '5': 11, '6': '.structs.Genetics', '10': 'genetics'},
  ],
};

