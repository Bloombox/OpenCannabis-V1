///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library base_ProductKey_pbjson;

const ProductKey$json = const {
  '1': 'ProductKey',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'type', '3': 2, '4': 1, '5': 11, '6': '.base.ProductType', '10': 'type'},
  ],
};

