///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library base_ProductType_pbjson;

const ProductType$json = const {
  '1': 'ProductType',
  '2': const [
    const {'1': 'kind', '3': 1, '4': 1, '5': 14, '6': '.base.ProductKind', '10': 'kind'},
  ],
};

