///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_FlagsDescriptor_pbjson;

const FlagType$json = const {
  '1': 'FlagType',
  '2': const [
    const {'1': 'VISIBLE', '2': 0},
    const {'1': 'PREMIUM', '2': 1},
    const {'1': 'FEATURED', '2': 2},
    const {'1': 'LASTCHANCE', '2': 3},
    const {'1': 'INHOUSE', '2': 4},
  ],
};

const ProductFlag$json = const {
  '1': 'ProductFlag',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.structs.FlagType', '10': 'type'},
    const {'1': 'value', '3': 2, '4': 1, '5': 8, '10': 'value'},
  ],
};

