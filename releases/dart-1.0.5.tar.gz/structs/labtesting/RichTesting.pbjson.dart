///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_RichTesting_pbjson;

const AromaFlavor$json = const {
  '1': 'AromaFlavor',
  '2': const [
    const {'1': 'PINE', '2': 0},
    const {'1': 'LEMON', '2': 1},
    const {'1': 'PEPPER', '2': 2},
    const {'1': 'LAVENDER', '2': 3},
    const {'1': 'HOPS', '2': 4},
  ],
};

const Terpene$json = const {
  '1': 'Terpene',
  '2': const [
    const {'1': 'LIMONENE', '2': 0},
    const {'1': 'PINENE', '2': 1},
  ],
};

const TerpeneTestValue$json = const {
  '1': 'TerpeneTestValue',
  '2': const [
    const {'1': 'terpene', '3': 1, '4': 1, '5': 14, '6': '.structs.labtesting.Terpene', '10': 'terpene'},
    const {'1': 'measurement', '3': 2, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

const RichTesting$json = const {
  '1': 'RichTesting',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'media', '3': 2, '4': 3, '5': 11, '6': '.structs.labtesting.TestMedia', '10': 'media'},
    const {'1': 'last_updated', '3': 3, '4': 1, '5': 3, '10': 'lastUpdated'},
    const {'1': 'basic', '3': 30, '4': 1, '5': 11, '6': '.structs.labtesting.BasicTesting', '10': 'basic'},
    const {'1': 'terpenes', '3': 31, '4': 1, '5': 11, '6': '.structs.labtesting.TerpeneTesting', '10': 'terpenes'},
    const {'1': 'pesticides', '3': 32, '4': 1, '5': 11, '6': '.structs.labtesting.PesticideTesting', '10': 'pesticides'},
    const {'1': 'moisture', '3': 33, '4': 1, '5': 11, '6': '.structs.labtesting.MoistureTesting', '10': 'moisture'},
    const {'1': 'aroma', '3': 34, '4': 3, '5': 14, '6': '.structs.labtesting.AromaFlavor', '10': 'aroma'},
    const {'1': 'subjective_testing', '3': 35, '4': 1, '5': 11, '6': '.structs.labtesting.SubjectiveTesting', '10': 'subjectiveTesting'},
  ],
};

const TerpeneTesting$json = const {
  '1': 'TerpeneTesting',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'terpenes', '3': 10, '4': 3, '5': 11, '6': '.structs.labtesting.TerpeneTestValue', '10': 'terpenes'},
  ],
};

const PesticideTesting$json = const {
  '1': 'PesticideTesting',
};

const MoistureTesting$json = const {
  '1': 'MoistureTesting',
};

