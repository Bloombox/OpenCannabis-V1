///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestValue;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../../media/MediaItem.pb.dart' as media;

import 'TestValue.pbenum.dart';

export 'TestValue.pbenum.dart';

class TestValue extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('TestValue')
    ..e/*<TestValueType>*/(1, 'type', PbFieldType.OE, TestValueType.MILLIGRAMS, TestValueType.valueOf)
    ..a/*<double>*/(10, 'measurement', PbFieldType.OD)
    ..a/*<bool>*/(20, 'present', PbFieldType.OB)
    ..hasRequiredFields = false
  ;

  TestValue() : super();
  TestValue.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestValue.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestValue clone() => new TestValue()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static TestValue create() => new TestValue();
  static PbList<TestValue> createRepeated() => new PbList<TestValue>();
  static TestValue getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTestValue();
    return _defaultInstance;
  }
  static TestValue _defaultInstance;
  static void $checkItem(TestValue v) {
    if (v is! TestValue) checkItemFailed(v, 'TestValue');
  }

  TestValueType get type => $_get(0, 1, null);
  set type(TestValueType v) { setField(1, v); }
  bool hasType() => $_has(0, 1);
  void clearType() => clearField(1);

  double get measurement => $_get(1, 10, null);
  set measurement(double v) { $_setDouble(1, 10, v); }
  bool hasMeasurement() => $_has(1, 10);
  void clearMeasurement() => clearField(10);

  bool get present => $_get(2, 20, false);
  set present(bool v) { $_setBool(2, 20, v); }
  bool hasPresent() => $_has(2, 20);
  void clearPresent() => clearField(20);
}

class _ReadonlyTestValue extends TestValue with ReadonlyMessageMixin {}

class TestMedia extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('TestMedia')
    ..e/*<TestMediaType>*/(1, 'type', PbFieldType.OE, TestMediaType.CERTIFICATE, TestMediaType.valueOf)
    ..a/*<media.MediaItem>*/(2, 'mediaItem', PbFieldType.OM, media.MediaItem.getDefault, media.MediaItem.create)
    ..hasRequiredFields = false
  ;

  TestMedia() : super();
  TestMedia.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestMedia.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestMedia clone() => new TestMedia()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static TestMedia create() => new TestMedia();
  static PbList<TestMedia> createRepeated() => new PbList<TestMedia>();
  static TestMedia getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTestMedia();
    return _defaultInstance;
  }
  static TestMedia _defaultInstance;
  static void $checkItem(TestMedia v) {
    if (v is! TestMedia) checkItemFailed(v, 'TestMedia');
  }

  TestMediaType get type => $_get(0, 1, null);
  set type(TestMediaType v) { setField(1, v); }
  bool hasType() => $_has(0, 1);
  void clearType() => clearField(1);

  media.MediaItem get mediaItem => $_get(1, 2, null);
  set mediaItem(media.MediaItem v) { setField(2, v); }
  bool hasMediaItem() => $_has(1, 2);
  void clearMediaItem() => clearField(2);
}

class _ReadonlyTestMedia extends TestMedia with ReadonlyMessageMixin {}

