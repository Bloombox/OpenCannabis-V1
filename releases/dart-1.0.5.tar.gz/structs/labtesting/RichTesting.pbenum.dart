///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_RichTesting_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class AromaFlavor extends ProtobufEnum {
  static const AromaFlavor PINE = const AromaFlavor._(0, 'PINE');
  static const AromaFlavor LEMON = const AromaFlavor._(1, 'LEMON');
  static const AromaFlavor PEPPER = const AromaFlavor._(2, 'PEPPER');
  static const AromaFlavor LAVENDER = const AromaFlavor._(3, 'LAVENDER');
  static const AromaFlavor HOPS = const AromaFlavor._(4, 'HOPS');

  static const List<AromaFlavor> values = const <AromaFlavor> [
    PINE,
    LEMON,
    PEPPER,
    LAVENDER,
    HOPS,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static AromaFlavor valueOf(int value) => _byValue[value] as AromaFlavor;
  static void $checkItem(AromaFlavor v) {
    if (v is! AromaFlavor) checkItemFailed(v, 'AromaFlavor');
  }

  const AromaFlavor._(int v, String n) : super(v, n);
}

class Terpene extends ProtobufEnum {
  static const Terpene LIMONENE = const Terpene._(0, 'LIMONENE');
  static const Terpene PINENE = const Terpene._(1, 'PINENE');

  static const List<Terpene> values = const <Terpene> [
    LIMONENE,
    PINENE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Terpene valueOf(int value) => _byValue[value] as Terpene;
  static void $checkItem(Terpene v) {
    if (v is! Terpene) checkItemFailed(v, 'Terpene');
  }

  const Terpene._(int v, String n) : super(v, n);
}

