///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_RichTesting;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart';

import 'TestValue.pb.dart';
import 'BasicTesting.pb.dart';
import 'SubjectiveTesting.pb.dart';

import 'RichTesting.pbenum.dart';

export 'RichTesting.pbenum.dart';

class TerpeneTestValue extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('TerpeneTestValue')
    ..e/*<Terpene>*/(1, 'terpene', PbFieldType.OE, Terpene.LIMONENE, Terpene.valueOf)
    ..a/*<TestValue>*/(2, 'measurement', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..hasRequiredFields = false
  ;

  TerpeneTestValue() : super();
  TerpeneTestValue.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TerpeneTestValue.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TerpeneTestValue clone() => new TerpeneTestValue()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static TerpeneTestValue create() => new TerpeneTestValue();
  static PbList<TerpeneTestValue> createRepeated() => new PbList<TerpeneTestValue>();
  static TerpeneTestValue getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTerpeneTestValue();
    return _defaultInstance;
  }
  static TerpeneTestValue _defaultInstance;
  static void $checkItem(TerpeneTestValue v) {
    if (v is! TerpeneTestValue) checkItemFailed(v, 'TerpeneTestValue');
  }

  Terpene get terpene => $_get(0, 1, null);
  set terpene(Terpene v) { setField(1, v); }
  bool hasTerpene() => $_has(0, 1);
  void clearTerpene() => clearField(1);

  TestValue get measurement => $_get(1, 2, null);
  set measurement(TestValue v) { setField(2, v); }
  bool hasMeasurement() => $_has(1, 2);
  void clearMeasurement() => clearField(2);
}

class _ReadonlyTerpeneTestValue extends TerpeneTestValue with ReadonlyMessageMixin {}

class RichTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('RichTesting')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<TestMedia>*/(2, 'media', PbFieldType.PM, TestMedia.$checkItem, TestMedia.create)
    ..a/*<Int64>*/(3, 'lastUpdated', PbFieldType.O6, Int64.ZERO)
    ..a/*<BasicTesting>*/(30, 'basic', PbFieldType.OM, BasicTesting.getDefault, BasicTesting.create)
    ..a/*<TerpeneTesting>*/(31, 'terpenes', PbFieldType.OM, TerpeneTesting.getDefault, TerpeneTesting.create)
    ..a/*<PesticideTesting>*/(32, 'pesticides', PbFieldType.OM, PesticideTesting.getDefault, PesticideTesting.create)
    ..a/*<MoistureTesting>*/(33, 'moisture', PbFieldType.OM, MoistureTesting.getDefault, MoistureTesting.create)
    ..pp/*<AromaFlavor>*/(34, 'aroma', PbFieldType.PE, AromaFlavor.$checkItem, null, AromaFlavor.valueOf)
    ..a/*<SubjectiveTesting>*/(35, 'subjectiveTesting', PbFieldType.OM, SubjectiveTesting.getDefault, SubjectiveTesting.create)
    ..hasRequiredFields = false
  ;

  RichTesting() : super();
  RichTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  RichTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  RichTesting clone() => new RichTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static RichTesting create() => new RichTesting();
  static PbList<RichTesting> createRepeated() => new PbList<RichTesting>();
  static RichTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyRichTesting();
    return _defaultInstance;
  }
  static RichTesting _defaultInstance;
  static void $checkItem(RichTesting v) {
    if (v is! RichTesting) checkItemFailed(v, 'RichTesting');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<TestMedia> get media => $_get(1, 2, null);

  Int64 get lastUpdated => $_get(2, 3, null);
  set lastUpdated(Int64 v) { $_setInt64(2, 3, v); }
  bool hasLastUpdated() => $_has(2, 3);
  void clearLastUpdated() => clearField(3);

  BasicTesting get basic => $_get(3, 30, null);
  set basic(BasicTesting v) { setField(30, v); }
  bool hasBasic() => $_has(3, 30);
  void clearBasic() => clearField(30);

  TerpeneTesting get terpenes => $_get(4, 31, null);
  set terpenes(TerpeneTesting v) { setField(31, v); }
  bool hasTerpenes() => $_has(4, 31);
  void clearTerpenes() => clearField(31);

  PesticideTesting get pesticides => $_get(5, 32, null);
  set pesticides(PesticideTesting v) { setField(32, v); }
  bool hasPesticides() => $_has(5, 32);
  void clearPesticides() => clearField(32);

  MoistureTesting get moisture => $_get(6, 33, null);
  set moisture(MoistureTesting v) { setField(33, v); }
  bool hasMoisture() => $_has(6, 33);
  void clearMoisture() => clearField(33);

  List<AromaFlavor> get aroma => $_get(7, 34, null);

  SubjectiveTesting get subjectiveTesting => $_get(8, 35, null);
  set subjectiveTesting(SubjectiveTesting v) { setField(35, v); }
  bool hasSubjectiveTesting() => $_has(8, 35);
  void clearSubjectiveTesting() => clearField(35);
}

class _ReadonlyRichTesting extends RichTesting with ReadonlyMessageMixin {}

class TerpeneTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('TerpeneTesting')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<TerpeneTestValue>*/(10, 'terpenes', PbFieldType.PM, TerpeneTestValue.$checkItem, TerpeneTestValue.create)
    ..hasRequiredFields = false
  ;

  TerpeneTesting() : super();
  TerpeneTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TerpeneTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TerpeneTesting clone() => new TerpeneTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static TerpeneTesting create() => new TerpeneTesting();
  static PbList<TerpeneTesting> createRepeated() => new PbList<TerpeneTesting>();
  static TerpeneTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTerpeneTesting();
    return _defaultInstance;
  }
  static TerpeneTesting _defaultInstance;
  static void $checkItem(TerpeneTesting v) {
    if (v is! TerpeneTesting) checkItemFailed(v, 'TerpeneTesting');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<TerpeneTestValue> get terpenes => $_get(1, 10, null);
}

class _ReadonlyTerpeneTesting extends TerpeneTesting with ReadonlyMessageMixin {}

class PesticideTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('PesticideTesting')
    ..hasRequiredFields = false
  ;

  PesticideTesting() : super();
  PesticideTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PesticideTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PesticideTesting clone() => new PesticideTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static PesticideTesting create() => new PesticideTesting();
  static PbList<PesticideTesting> createRepeated() => new PbList<PesticideTesting>();
  static PesticideTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyPesticideTesting();
    return _defaultInstance;
  }
  static PesticideTesting _defaultInstance;
  static void $checkItem(PesticideTesting v) {
    if (v is! PesticideTesting) checkItemFailed(v, 'PesticideTesting');
  }
}

class _ReadonlyPesticideTesting extends PesticideTesting with ReadonlyMessageMixin {}

class MoistureTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('MoistureTesting')
    ..hasRequiredFields = false
  ;

  MoistureTesting() : super();
  MoistureTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MoistureTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MoistureTesting clone() => new MoistureTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static MoistureTesting create() => new MoistureTesting();
  static PbList<MoistureTesting> createRepeated() => new PbList<MoistureTesting>();
  static MoistureTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyMoistureTesting();
    return _defaultInstance;
  }
  static MoistureTesting _defaultInstance;
  static void $checkItem(MoistureTesting v) {
    if (v is! MoistureTesting) checkItemFailed(v, 'MoistureTesting');
  }
}

class _ReadonlyMoistureTesting extends MoistureTesting with ReadonlyMessageMixin {}

