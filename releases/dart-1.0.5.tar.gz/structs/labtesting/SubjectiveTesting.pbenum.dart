///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_SubjectiveTesting_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Feeling extends ProtobufEnum {
  static const Feeling GROUNDING = const Feeling._(0, 'GROUNDING');
  static const Feeling SLEEP = const Feeling._(1, 'SLEEP');
  static const Feeling CALMING = const Feeling._(2, 'CALMING');
  static const Feeling STIMULATING = const Feeling._(3, 'STIMULATING');
  static const Feeling FUNNY = const Feeling._(4, 'FUNNY');
  static const Feeling FOCUS = const Feeling._(5, 'FOCUS');
  static const Feeling PASSION = const Feeling._(6, 'PASSION');

  static const List<Feeling> values = const <Feeling> [
    GROUNDING,
    SLEEP,
    CALMING,
    STIMULATING,
    FUNNY,
    FOCUS,
    PASSION,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Feeling valueOf(int value) => _byValue[value] as Feeling;
  static void $checkItem(Feeling v) {
    if (v is! Feeling) checkItemFailed(v, 'Feeling');
  }

  const Feeling._(int v, String n) : super(v, n);
}

class PotencyEstimate extends ProtobufEnum {
  static const PotencyEstimate LIGHT = const PotencyEstimate._(0, 'LIGHT');
  static const PotencyEstimate MEDIUM = const PotencyEstimate._(1, 'MEDIUM');
  static const PotencyEstimate HEAVY = const PotencyEstimate._(2, 'HEAVY');
  static const PotencyEstimate TOP = const PotencyEstimate._(3, 'TOP');

  static const List<PotencyEstimate> values = const <PotencyEstimate> [
    LIGHT,
    MEDIUM,
    HEAVY,
    TOP,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static PotencyEstimate valueOf(int value) => _byValue[value] as PotencyEstimate;
  static void $checkItem(PotencyEstimate v) {
    if (v is! PotencyEstimate) checkItemFailed(v, 'PotencyEstimate');
  }

  const PotencyEstimate._(int v, String n) : super(v, n);
}

