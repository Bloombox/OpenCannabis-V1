///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_SubjectiveTesting_pbjson;

const Feeling$json = const {
  '1': 'Feeling',
  '2': const [
    const {'1': 'GROUNDING', '2': 0},
    const {'1': 'SLEEP', '2': 1},
    const {'1': 'CALMING', '2': 2},
    const {'1': 'STIMULATING', '2': 3},
    const {'1': 'FUNNY', '2': 4},
    const {'1': 'FOCUS', '2': 5},
    const {'1': 'PASSION', '2': 6},
  ],
};

const PotencyEstimate$json = const {
  '1': 'PotencyEstimate',
  '2': const [
    const {'1': 'LIGHT', '2': 0},
    const {'1': 'MEDIUM', '2': 1},
    const {'1': 'HEAVY', '2': 2},
    const {'1': 'TOP', '2': 3},
  ],
};

const SubjectiveTesting$json = const {
  '1': 'SubjectiveTesting',
  '2': const [
    const {'1': 'description', '3': 1, '4': 1, '5': 11, '6': '.content.Content', '10': 'description'},
    const {'1': 'potency', '3': 2, '4': 1, '5': 14, '6': '.structs.labtesting.PotencyEstimate', '10': 'potency'},
    const {'1': 'feeling_tags', '3': 3, '4': 3, '5': 14, '6': '.structs.labtesting.Feeling', '10': 'feelingTags'},
  ],
};

