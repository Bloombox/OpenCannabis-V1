/**
 * @fileoverview
 * @enhanceable
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.Language');

/**
 * @enum {number}
 */
proto.Language = {
  ENGLISH: 0,
  SPANISH: 1,
  FRENCH: 2
};

