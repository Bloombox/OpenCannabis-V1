///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library content_MaterialsData;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../structs/Genetics.pb.dart' as structs;

import '../structs/Grow.pbenum.dart' as structs;
import '../structs/Species.pbenum.dart' as structs;

class MaterialsData extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('MaterialsData')
    ..p/*<String>*/(1, 'ingredients', PbFieldType.PS)
    ..e/*<structs.Grow>*/(2, 'grow', PbFieldType.OE, structs.Grow.GENERIC, structs.Grow.valueOf)
    ..e/*<structs.Species>*/(3, 'species', PbFieldType.OE, structs.Species.UNSPECIFIED, structs.Species.valueOf)
    ..a/*<structs.Genetics>*/(4, 'genetics', PbFieldType.OM, structs.Genetics.getDefault, structs.Genetics.create)
    ..hasRequiredFields = false
  ;

  MaterialsData() : super();
  MaterialsData.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MaterialsData.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MaterialsData clone() => new MaterialsData()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static MaterialsData create() => new MaterialsData();
  static PbList<MaterialsData> createRepeated() => new PbList<MaterialsData>();
  static MaterialsData getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyMaterialsData();
    return _defaultInstance;
  }
  static MaterialsData _defaultInstance;
  static void $checkItem(MaterialsData v) {
    if (v is! MaterialsData) checkItemFailed(v, 'MaterialsData');
  }

  List<String> get ingredients => $_get(0, 1, null);

  structs.Grow get grow => $_get(1, 2, null);
  set grow(structs.Grow v) { setField(2, v); }
  bool hasGrow() => $_has(1, 2);
  void clearGrow() => clearField(2);

  structs.Species get species => $_get(2, 3, null);
  set species(structs.Species v) { setField(3, v); }
  bool hasSpecies() => $_has(2, 3);
  void clearSpecies() => clearField(3);

  structs.Genetics get genetics => $_get(3, 4, null);
  set genetics(structs.Genetics v) { setField(4, v); }
  bool hasGenetics() => $_has(3, 4);
  void clearGenetics() => clearField(4);
}

class _ReadonlyMaterialsData extends MaterialsData with ReadonlyMessageMixin {}

