///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library content_ProductContent;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart';

import 'Name.pb.dart';
import 'Content.pb.dart';
import 'Brand.pb.dart';
import '../media/MediaItem.pb.dart' as media;
import '../structs/pricing/PricingDescriptor.pb.dart' as structs$pricing;

import '../structs/ProductFlags.pbenum.dart' as structs;

class ProductContent extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('ProductContent')
    ..a/*<Name>*/(1, 'name', PbFieldType.OM, Name.getDefault, Name.create)
    ..a/*<Content>*/(2, 'summary', PbFieldType.OM, Content.getDefault, Content.create)
    ..a/*<Brand>*/(3, 'brand', PbFieldType.OM, Brand.getDefault, Brand.create)
    ..pp/*<media.MediaItem>*/(20, 'media', PbFieldType.PM, media.MediaItem.$checkItem, media.MediaItem.create)
    ..pp/*<structs.ProductFlag>*/(22, 'flags', PbFieldType.PE, structs.ProductFlag.$checkItem, null, structs.ProductFlag.valueOf)
    ..a/*<structs$pricing.ProductPricing>*/(24, 'pricing', PbFieldType.OM, structs$pricing.ProductPricing.getDefault, structs$pricing.ProductPricing.create)
    ..a/*<Content>*/(30, 'usage', PbFieldType.OM, Content.getDefault, Content.create)
    ..a/*<Content>*/(31, 'dosage', PbFieldType.OM, Content.getDefault, Content.create)
    ..a/*<Content>*/(32, 'advice', PbFieldType.OM, Content.getDefault, Content.create)
    ..a/*<Int64>*/(40, 'modified', PbFieldType.O6, Int64.ZERO)
    ..a/*<Int64>*/(41, 'created', PbFieldType.O6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  ProductContent() : super();
  ProductContent.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductContent.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductContent clone() => new ProductContent()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static ProductContent create() => new ProductContent();
  static PbList<ProductContent> createRepeated() => new PbList<ProductContent>();
  static ProductContent getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyProductContent();
    return _defaultInstance;
  }
  static ProductContent _defaultInstance;
  static void $checkItem(ProductContent v) {
    if (v is! ProductContent) checkItemFailed(v, 'ProductContent');
  }

  Name get name => $_get(0, 1, null);
  set name(Name v) { setField(1, v); }
  bool hasName() => $_has(0, 1);
  void clearName() => clearField(1);

  Content get summary => $_get(1, 2, null);
  set summary(Content v) { setField(2, v); }
  bool hasSummary() => $_has(1, 2);
  void clearSummary() => clearField(2);

  Brand get brand => $_get(2, 3, null);
  set brand(Brand v) { setField(3, v); }
  bool hasBrand() => $_has(2, 3);
  void clearBrand() => clearField(3);

  List<media.MediaItem> get media => $_get(3, 20, null);

  List<structs.ProductFlag> get flags => $_get(4, 22, null);

  structs$pricing.ProductPricing get pricing => $_get(5, 24, null);
  set pricing(structs$pricing.ProductPricing v) { setField(24, v); }
  bool hasPricing() => $_has(5, 24);
  void clearPricing() => clearField(24);

  Content get usage => $_get(6, 30, null);
  set usage(Content v) { setField(30, v); }
  bool hasUsage() => $_has(6, 30);
  void clearUsage() => clearField(30);

  Content get dosage => $_get(7, 31, null);
  set dosage(Content v) { setField(31, v); }
  bool hasDosage() => $_has(7, 31);
  void clearDosage() => clearField(31);

  Content get advice => $_get(8, 32, null);
  set advice(Content v) { setField(32, v); }
  bool hasAdvice() => $_has(8, 32);
  void clearAdvice() => clearField(32);

  Int64 get modified => $_get(9, 40, null);
  set modified(Int64 v) { $_setInt64(9, 40, v); }
  bool hasModified() => $_has(9, 40);
  void clearModified() => clearField(40);

  Int64 get created => $_get(10, 41, null);
  set created(Int64 v) { $_setInt64(10, 41, v); }
  bool hasCreated() => $_has(10, 41);
  void clearCreated() => clearField(41);
}

class _ReadonlyProductContent extends ProductContent with ReadonlyMessageMixin {}

