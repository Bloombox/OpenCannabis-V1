///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Apothecary_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Apothecary_Type extends ProtobufEnum {
  static const Apothecary_Type TOPICAL = const Apothecary_Type._(0, 'TOPICAL');
  static const Apothecary_Type TINCTURE = const Apothecary_Type._(1, 'TINCTURE');
  static const Apothecary_Type CAPSULE = const Apothecary_Type._(2, 'CAPSULE');
  static const Apothecary_Type INJECTOR = const Apothecary_Type._(3, 'INJECTOR');
  static const Apothecary_Type SUBLINGUAL = const Apothecary_Type._(4, 'SUBLINGUAL');
  static const Apothecary_Type OTHER = const Apothecary_Type._(99, 'OTHER');

  static const List<Apothecary_Type> values = const <Apothecary_Type> [
    TOPICAL,
    TINCTURE,
    CAPSULE,
    INJECTOR,
    SUBLINGUAL,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Apothecary_Type valueOf(int value) => _byValue[value] as Apothecary_Type;
  static void $checkItem(Apothecary_Type v) {
    if (v is! Apothecary_Type) checkItemFailed(v, 'Apothecary_Type');
  }

  const Apothecary_Type._(int v, String n) : super(v, n);
}

