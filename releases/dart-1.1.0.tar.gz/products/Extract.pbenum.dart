///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Extract_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Extract_Type extends ProtobufEnum {
  static const Extract_Type OIL = const Extract_Type._(0, 'OIL');
  static const Extract_Type WAX = const Extract_Type._(1, 'WAX');
  static const Extract_Type SHATTER = const Extract_Type._(2, 'SHATTER');
  static const Extract_Type KIEF = const Extract_Type._(3, 'KIEF');
  static const Extract_Type HASH = const Extract_Type._(4, 'HASH');
  static const Extract_Type LIVE_RESIN = const Extract_Type._(5, 'LIVE_RESIN');
  static const Extract_Type ROSIN = const Extract_Type._(6, 'ROSIN');
  static const Extract_Type OTHER = const Extract_Type._(99, 'OTHER');

  static const List<Extract_Type> values = const <Extract_Type> [
    OIL,
    WAX,
    SHATTER,
    KIEF,
    HASH,
    LIVE_RESIN,
    ROSIN,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Extract_Type valueOf(int value) => _byValue[value] as Extract_Type;
  static void $checkItem(Extract_Type v) {
    if (v is! Extract_Type) checkItemFailed(v, 'Extract_Type');
  }

  const Extract_Type._(int v, String n) : super(v, n);
}

