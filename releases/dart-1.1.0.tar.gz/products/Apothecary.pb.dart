///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Apothecary;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../base/ProductKey.pb.dart' as base;
import '../content/ProductContent.pb.dart' as content;
import '../content/MaterialsData.pb.dart' as content;
import '../structs/labtesting/BasicTestResults.pb.dart' as structs$labtesting;

import 'Apothecary.pbenum.dart';

export 'Apothecary.pbenum.dart';

class Apothecary extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Apothecary')
    ..a/*<base.ProductKey>*/(1, 'key', PbFieldType.OM, base.ProductKey.getDefault, base.ProductKey.create)
    ..e/*<Apothecary_Type>*/(2, 'type', PbFieldType.OE, Apothecary_Type.TOPICAL, Apothecary_Type.valueOf)
    ..a/*<content.ProductContent>*/(20, 'product', PbFieldType.OM, content.ProductContent.getDefault, content.ProductContent.create)
    ..a/*<content.MaterialsData>*/(21, 'material', PbFieldType.OM, content.MaterialsData.getDefault, content.MaterialsData.create)
    ..a/*<structs$labtesting.BasicTestResults>*/(22, 'testing', PbFieldType.OM, structs$labtesting.BasicTestResults.getDefault, structs$labtesting.BasicTestResults.create)
    ..hasRequiredFields = false
  ;

  Apothecary() : super();
  Apothecary.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Apothecary.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Apothecary clone() => new Apothecary()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Apothecary create() => new Apothecary();
  static PbList<Apothecary> createRepeated() => new PbList<Apothecary>();
  static Apothecary getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyApothecary();
    return _defaultInstance;
  }
  static Apothecary _defaultInstance;
  static void $checkItem(Apothecary v) {
    if (v is! Apothecary) checkItemFailed(v, 'Apothecary');
  }

  base.ProductKey get key => $_get(0, 1, null);
  set key(base.ProductKey v) { setField(1, v); }
  bool hasKey() => $_has(0, 1);
  void clearKey() => clearField(1);

  Apothecary_Type get type => $_get(1, 2, null);
  set type(Apothecary_Type v) { setField(2, v); }
  bool hasType() => $_has(1, 2);
  void clearType() => clearField(2);

  content.ProductContent get product => $_get(2, 20, null);
  set product(content.ProductContent v) { setField(20, v); }
  bool hasProduct() => $_has(2, 20);
  void clearProduct() => clearField(20);

  content.MaterialsData get material => $_get(3, 21, null);
  set material(content.MaterialsData v) { setField(21, v); }
  bool hasMaterial() => $_has(3, 21);
  void clearMaterial() => clearField(21);

  structs$labtesting.BasicTestResults get testing => $_get(4, 22, null);
  set testing(structs$labtesting.BasicTestResults v) { setField(22, v); }
  bool hasTesting() => $_has(4, 22);
  void clearTesting() => clearField(22);
}

class _ReadonlyApothecary extends Apothecary with ReadonlyMessageMixin {}

