///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Edible_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Edible_Type extends ProtobufEnum {
  static const Edible_Type CHOCOLATE = const Edible_Type._(0, 'CHOCOLATE');
  static const Edible_Type BAKED_GOOD = const Edible_Type._(1, 'BAKED_GOOD');
  static const Edible_Type CANDY = const Edible_Type._(2, 'CANDY');
  static const Edible_Type DRINK = const Edible_Type._(3, 'DRINK');
  static const Edible_Type OTHER = const Edible_Type._(99, 'OTHER');

  static const List<Edible_Type> values = const <Edible_Type> [
    CHOCOLATE,
    BAKED_GOOD,
    CANDY,
    DRINK,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Edible_Type valueOf(int value) => _byValue[value] as Edible_Type;
  static void $checkItem(Edible_Type v) {
    if (v is! Edible_Type) checkItemFailed(v, 'Edible_Type');
  }

  const Edible_Type._(int v, String n) : super(v, n);
}

class Edible_Flag extends ProtobufEnum {
  static const Edible_Flag VEGAN = const Edible_Flag._(0, 'VEGAN');
  static const Edible_Flag GLUTEN_FREE = const Edible_Flag._(2, 'GLUTEN_FREE');
  static const Edible_Flag SUGAR_FREE = const Edible_Flag._(3, 'SUGAR_FREE');
  static const Edible_Flag FAIR_TRADE = const Edible_Flag._(4, 'FAIR_TRADE');

  static const List<Edible_Flag> values = const <Edible_Flag> [
    VEGAN,
    GLUTEN_FREE,
    SUGAR_FREE,
    FAIR_TRADE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Edible_Flag valueOf(int value) => _byValue[value] as Edible_Flag;
  static void $checkItem(Edible_Flag v) {
    if (v is! Edible_Flag) checkItemFailed(v, 'Edible_Flag');
  }

  const Edible_Flag._(int v, String n) : super(v, n);
}

