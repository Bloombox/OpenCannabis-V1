///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Cartridge;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../base/ProductKey.pb.dart' as base;
import '../content/ProductContent.pb.dart' as content;
import '../content/MaterialsData.pb.dart' as content;
import '../structs/labtesting/BasicTestResults.pb.dart' as structs$labtesting;

import 'Cartridge.pbenum.dart';

export 'Cartridge.pbenum.dart';

class Cartridge extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Cartridge')
    ..a/*<base.ProductKey>*/(1, 'key', PbFieldType.OM, base.ProductKey.getDefault, base.ProductKey.create)
    ..e/*<Cartridge_Type>*/(2, 'type', PbFieldType.OE, Cartridge_Type.CARTRIDGE, Cartridge_Type.valueOf)
    ..a/*<content.ProductContent>*/(20, 'product', PbFieldType.OM, content.ProductContent.getDefault, content.ProductContent.create)
    ..a/*<content.MaterialsData>*/(21, 'material', PbFieldType.OM, content.MaterialsData.getDefault, content.MaterialsData.create)
    ..a/*<structs$labtesting.BasicTestResults>*/(22, 'testing', PbFieldType.OM, structs$labtesting.BasicTestResults.getDefault, structs$labtesting.BasicTestResults.create)
    ..hasRequiredFields = false
  ;

  Cartridge() : super();
  Cartridge.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Cartridge.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Cartridge clone() => new Cartridge()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Cartridge create() => new Cartridge();
  static PbList<Cartridge> createRepeated() => new PbList<Cartridge>();
  static Cartridge getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyCartridge();
    return _defaultInstance;
  }
  static Cartridge _defaultInstance;
  static void $checkItem(Cartridge v) {
    if (v is! Cartridge) checkItemFailed(v, 'Cartridge');
  }

  base.ProductKey get key => $_get(0, 1, null);
  set key(base.ProductKey v) { setField(1, v); }
  bool hasKey() => $_has(0, 1);
  void clearKey() => clearField(1);

  Cartridge_Type get type => $_get(1, 2, null);
  set type(Cartridge_Type v) { setField(2, v); }
  bool hasType() => $_has(1, 2);
  void clearType() => clearField(2);

  content.ProductContent get product => $_get(2, 20, null);
  set product(content.ProductContent v) { setField(20, v); }
  bool hasProduct() => $_has(2, 20);
  void clearProduct() => clearField(20);

  content.MaterialsData get material => $_get(3, 21, null);
  set material(content.MaterialsData v) { setField(21, v); }
  bool hasMaterial() => $_has(3, 21);
  void clearMaterial() => clearField(21);

  structs$labtesting.BasicTestResults get testing => $_get(4, 22, null);
  set testing(structs$labtesting.BasicTestResults v) { setField(22, v); }
  bool hasTesting() => $_has(4, 22);
  void clearTesting() => clearField(22);
}

class _ReadonlyCartridge extends Cartridge with ReadonlyMessageMixin {}

