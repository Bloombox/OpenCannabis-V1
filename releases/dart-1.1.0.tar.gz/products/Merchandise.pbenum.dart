///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Merchandise_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Merchandise_Type extends ProtobufEnum {
  static const Merchandise_Type CLOTHING = const Merchandise_Type._(0, 'CLOTHING');
  static const Merchandise_Type GLASSWARE = const Merchandise_Type._(1, 'GLASSWARE');
  static const Merchandise_Type ACCESSORIES = const Merchandise_Type._(2, 'ACCESSORIES');
  static const Merchandise_Type OTHER = const Merchandise_Type._(99, 'OTHER');

  static const List<Merchandise_Type> values = const <Merchandise_Type> [
    CLOTHING,
    GLASSWARE,
    ACCESSORIES,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Merchandise_Type valueOf(int value) => _byValue[value] as Merchandise_Type;
  static void $checkItem(Merchandise_Type v) {
    if (v is! Merchandise_Type) checkItemFailed(v, 'Merchandise_Type');
  }

  const Merchandise_Type._(int v, String n) : super(v, n);
}

class Merchandise_Flag extends ProtobufEnum {
  static const Merchandise_Flag MEDICAL_ONLY = const Merchandise_Flag._(0, 'MEDICAL_ONLY');

  static const List<Merchandise_Flag> values = const <Merchandise_Flag> [
    MEDICAL_ONLY,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Merchandise_Flag valueOf(int value) => _byValue[value] as Merchandise_Flag;
  static void $checkItem(Merchandise_Flag v) {
    if (v is! Merchandise_Flag) checkItemFailed(v, 'Merchandise_Flag');
  }

  const Merchandise_Flag._(int v, String n) : super(v, n);
}

