///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Plant_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Plant_Type extends ProtobufEnum {
  static const Plant_Type SEED = const Plant_Type._(0, 'SEED');
  static const Plant_Type CLONE = const Plant_Type._(1, 'CLONE');
  static const Plant_Type OTHER = const Plant_Type._(99, 'OTHER');

  static const List<Plant_Type> values = const <Plant_Type> [
    SEED,
    CLONE,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Plant_Type valueOf(int value) => _byValue[value] as Plant_Type;
  static void $checkItem(Plant_Type v) {
    if (v is! Plant_Type) checkItemFailed(v, 'Plant_Type');
  }

  const Plant_Type._(int v, String n) : super(v, n);
}

