///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Cartridge_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Cartridge_Type extends ProtobufEnum {
  static const Cartridge_Type CARTRIDGE = const Cartridge_Type._(0, 'CARTRIDGE');
  static const Cartridge_Type BATTERY = const Cartridge_Type._(1, 'BATTERY');
  static const Cartridge_Type KIT = const Cartridge_Type._(2, 'KIT');
  static const Cartridge_Type OTHER = const Cartridge_Type._(99, 'OTHER');

  static const List<Cartridge_Type> values = const <Cartridge_Type> [
    CARTRIDGE,
    BATTERY,
    KIT,
    OTHER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Cartridge_Type valueOf(int value) => _byValue[value] as Cartridge_Type;
  static void $checkItem(Cartridge_Type v) {
    if (v is! Cartridge_Type) checkItemFailed(v, 'Cartridge_Type');
  }

  const Cartridge_Type._(int v, String n) : super(v, n);
}

