///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Extract;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../base/ProductKey.pb.dart' as base;
import 'Flower.pb.dart';
import '../content/ProductContent.pb.dart' as content;
import '../content/MaterialsData.pb.dart' as content;
import '../structs/labtesting/TestResults.pb.dart' as structs$labtesting;

import '../structs/Shelf.pbenum.dart' as structs;
import 'Extract.pbenum.dart';

export 'Extract.pbenum.dart';

class Extract extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Extract')
    ..a/*<base.ProductKey>*/(1, 'key', PbFieldType.OM, base.ProductKey.getDefault, base.ProductKey.create)
    ..e/*<structs.Shelf>*/(2, 'shelf', PbFieldType.OE, structs.Shelf.ECONOMY, structs.Shelf.valueOf)
    ..e/*<Extract_Type>*/(3, 'type', PbFieldType.OE, Extract_Type.OIL, Extract_Type.valueOf)
    ..a/*<Flower>*/(4, 'flower', PbFieldType.OM, Flower.getDefault, Flower.create)
    ..a/*<content.ProductContent>*/(20, 'product', PbFieldType.OM, content.ProductContent.getDefault, content.ProductContent.create)
    ..a/*<content.MaterialsData>*/(21, 'material', PbFieldType.OM, content.MaterialsData.getDefault, content.MaterialsData.create)
    ..a/*<structs$labtesting.TestResults>*/(22, 'testing', PbFieldType.OM, structs$labtesting.TestResults.getDefault, structs$labtesting.TestResults.create)
    ..hasRequiredFields = false
  ;

  Extract() : super();
  Extract.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Extract.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Extract clone() => new Extract()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Extract create() => new Extract();
  static PbList<Extract> createRepeated() => new PbList<Extract>();
  static Extract getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyExtract();
    return _defaultInstance;
  }
  static Extract _defaultInstance;
  static void $checkItem(Extract v) {
    if (v is! Extract) checkItemFailed(v, 'Extract');
  }

  base.ProductKey get key => $_get(0, 1, null);
  set key(base.ProductKey v) { setField(1, v); }
  bool hasKey() => $_has(0, 1);
  void clearKey() => clearField(1);

  structs.Shelf get shelf => $_get(1, 2, null);
  set shelf(structs.Shelf v) { setField(2, v); }
  bool hasShelf() => $_has(1, 2);
  void clearShelf() => clearField(2);

  Extract_Type get type => $_get(2, 3, null);
  set type(Extract_Type v) { setField(3, v); }
  bool hasType() => $_has(2, 3);
  void clearType() => clearField(3);

  Flower get flower => $_get(3, 4, null);
  set flower(Flower v) { setField(4, v); }
  bool hasFlower() => $_has(3, 4);
  void clearFlower() => clearField(4);

  content.ProductContent get product => $_get(4, 20, null);
  set product(content.ProductContent v) { setField(20, v); }
  bool hasProduct() => $_has(4, 20);
  void clearProduct() => clearField(20);

  content.MaterialsData get material => $_get(5, 21, null);
  set material(content.MaterialsData v) { setField(21, v); }
  bool hasMaterial() => $_has(5, 21);
  void clearMaterial() => clearField(21);

  structs$labtesting.TestResults get testing => $_get(6, 22, null);
  set testing(structs$labtesting.TestResults v) { setField(22, v); }
  bool hasTesting() => $_has(6, 22);
  void clearTesting() => clearField(22);
}

class _ReadonlyExtract extends Extract with ReadonlyMessageMixin {}

