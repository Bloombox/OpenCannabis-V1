///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Merchandise_pbjson;

const Merchandise$json = const {
  '1': 'Merchandise',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.base.ProductKey', '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.products.Merchandise.Type', '10': 'type'},
    const {'1': 'flags', '3': 10, '4': 3, '5': 14, '6': '.products.Merchandise.Flag', '10': 'flags'},
    const {'1': 'product', '3': 20, '4': 1, '5': 11, '6': '.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 21, '4': 1, '5': 11, '6': '.content.MaterialsData', '10': 'material'},
  ],
  '4': const [Merchandise_Type$json, Merchandise_Flag$json],
};

const Merchandise_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CLOTHING', '2': 0},
    const {'1': 'GLASSWARE', '2': 1},
    const {'1': 'ACCESSORIES', '2': 2},
    const {'1': 'OTHER', '2': 99},
  ],
};

const Merchandise_Flag$json = const {
  '1': 'Flag',
  '2': const [
    const {'1': 'MEDICAL_ONLY', '2': 0},
  ],
};

