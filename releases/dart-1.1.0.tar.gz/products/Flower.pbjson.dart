///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Flower_pbjson;

const Flower$json = const {
  '1': 'Flower',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.base.ProductKey', '10': 'key'},
    const {'1': 'shelf', '3': 2, '4': 1, '5': 14, '6': '.structs.Shelf', '10': 'shelf'},
    const {'1': 'product', '3': 20, '4': 1, '5': 11, '6': '.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 21, '4': 1, '5': 11, '6': '.content.MaterialsData', '10': 'material'},
    const {'1': 'testing', '3': 22, '4': 1, '5': 11, '6': '.structs.labtesting.TestResults', '10': 'testing'},
  ],
};

