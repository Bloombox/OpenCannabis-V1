///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Preroll_pbjson;

const Preroll$json = const {
  '1': 'Preroll',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.base.ProductKey', '10': 'key'},
    const {'1': 'shelf', '3': 2, '4': 1, '5': 14, '6': '.structs.Shelf', '10': 'shelf'},
    const {'1': 'flower', '3': 3, '4': 1, '5': 11, '6': '.products.Flower', '10': 'flower'},
    const {'1': 'length', '3': 4, '4': 1, '5': 1, '10': 'length'},
    const {'1': 'thickness', '3': 5, '4': 1, '5': 1, '10': 'thickness'},
    const {'1': 'flags', '3': 10, '4': 3, '5': 14, '6': '.products.Preroll.Flag', '10': 'flags'},
    const {'1': 'product', '3': 20, '4': 1, '5': 11, '6': '.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 21, '4': 1, '5': 11, '6': '.content.MaterialsData', '10': 'material'},
    const {'1': 'testing', '3': 22, '4': 1, '5': 11, '6': '.structs.labtesting.BasicTestResults', '10': 'testing'},
  ],
  '4': const [Preroll_Flag$json],
};

const Preroll_Flag$json = const {
  '1': 'Flag',
  '2': const [
    const {'1': 'HASH_INFUSED', '2': 0},
    const {'1': 'KIEF_INFUSED', '2': 1},
    const {'1': 'FORTIFIED', '2': 2},
    const {'1': 'FULL_FLOWER', '2': 3},
  ],
};

