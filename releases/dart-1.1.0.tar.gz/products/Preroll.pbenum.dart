///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library products_Preroll_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Preroll_Flag extends ProtobufEnum {
  static const Preroll_Flag HASH_INFUSED = const Preroll_Flag._(0, 'HASH_INFUSED');
  static const Preroll_Flag KIEF_INFUSED = const Preroll_Flag._(1, 'KIEF_INFUSED');
  static const Preroll_Flag FORTIFIED = const Preroll_Flag._(2, 'FORTIFIED');
  static const Preroll_Flag FULL_FLOWER = const Preroll_Flag._(3, 'FULL_FLOWER');

  static const List<Preroll_Flag> values = const <Preroll_Flag> [
    HASH_INFUSED,
    KIEF_INFUSED,
    FORTIFIED,
    FULL_FLOWER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Preroll_Flag valueOf(int value) => _byValue[value] as Preroll_Flag;
  static void $checkItem(Preroll_Flag v) {
    if (v is! Preroll_Flag) checkItemFailed(v, 'Preroll_Flag');
  }

  const Preroll_Flag._(int v, String n) : super(v, n);
}

