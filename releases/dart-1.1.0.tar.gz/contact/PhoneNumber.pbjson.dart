///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_PhoneNumber_pbjson;

const PhoneNumber$json = const {
  '1': 'PhoneNumber',
  '2': const [
    const {'1': 'e164', '3': 1, '4': 1, '5': 9, '10': 'e164'},
    const {'1': 'validated', '3': 2, '4': 1, '5': 8, '10': 'validated'},
  ],
};

