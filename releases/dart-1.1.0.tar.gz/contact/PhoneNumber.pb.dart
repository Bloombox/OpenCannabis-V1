///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_PhoneNumber;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class PhoneNumber extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('PhoneNumber')
    ..a/*<String>*/(1, 'e164', PbFieldType.OS)
    ..a/*<bool>*/(2, 'validated', PbFieldType.OB)
    ..hasRequiredFields = false
  ;

  PhoneNumber() : super();
  PhoneNumber.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PhoneNumber.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PhoneNumber clone() => new PhoneNumber()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static PhoneNumber create() => new PhoneNumber();
  static PbList<PhoneNumber> createRepeated() => new PbList<PhoneNumber>();
  static PhoneNumber getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyPhoneNumber();
    return _defaultInstance;
  }
  static PhoneNumber _defaultInstance;
  static void $checkItem(PhoneNumber v) {
    if (v is! PhoneNumber) checkItemFailed(v, 'PhoneNumber');
  }

  String get e164 => $_get(0, 1, '');
  set e164(String v) { $_setString(0, 1, v); }
  bool hasE164() => $_has(0, 1);
  void clearE164() => clearField(1);

  bool get validated => $_get(1, 2, false);
  set validated(bool v) { $_setBool(1, 2, v); }
  bool hasValidated() => $_has(1, 2);
  void clearValidated() => clearField(2);
}

class _ReadonlyPhoneNumber extends PhoneNumber with ReadonlyMessageMixin {}

