///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_EmailAddress_pbjson;

const EmailAddress$json = const {
  '1': 'EmailAddress',
  '2': const [
    const {'1': 'address', '3': 1, '4': 1, '5': 9, '10': 'address'},
    const {'1': 'validated', '3': 2, '4': 1, '5': 8, '10': 'validated'},
  ],
};

