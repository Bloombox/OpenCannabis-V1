///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_ContactInfo_pbjson;

const ContactInfo$json = const {
  '1': 'ContactInfo',
  '2': const [
    const {'1': 'location', '3': 1, '4': 1, '5': 11, '6': '.geo.Location', '10': 'location'},
    const {'1': 'phone', '3': 2, '4': 1, '5': 11, '6': '.contact.PhoneNumber', '10': 'phone'},
    const {'1': 'email', '3': 3, '4': 1, '5': 11, '6': '.contact.EmailAddress', '10': 'email'},
  ],
};

