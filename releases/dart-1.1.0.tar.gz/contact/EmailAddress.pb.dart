///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_EmailAddress;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class EmailAddress extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('EmailAddress')
    ..a/*<String>*/(1, 'address', PbFieldType.OS)
    ..a/*<bool>*/(2, 'validated', PbFieldType.OB)
    ..hasRequiredFields = false
  ;

  EmailAddress() : super();
  EmailAddress.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EmailAddress.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EmailAddress clone() => new EmailAddress()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static EmailAddress create() => new EmailAddress();
  static PbList<EmailAddress> createRepeated() => new PbList<EmailAddress>();
  static EmailAddress getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyEmailAddress();
    return _defaultInstance;
  }
  static EmailAddress _defaultInstance;
  static void $checkItem(EmailAddress v) {
    if (v is! EmailAddress) checkItemFailed(v, 'EmailAddress');
  }

  String get address => $_get(0, 1, '');
  set address(String v) { $_setString(0, 1, v); }
  bool hasAddress() => $_has(0, 1);
  void clearAddress() => clearField(1);

  bool get validated => $_get(1, 2, false);
  set validated(bool v) { $_setBool(1, 2, v); }
  bool hasValidated() => $_has(1, 2);
  void clearValidated() => clearField(2);
}

class _ReadonlyEmailAddress extends EmailAddress with ReadonlyMessageMixin {}

