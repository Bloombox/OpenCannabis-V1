///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library contact_ContactInfo;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../geo/Location.pb.dart' as geo;
import 'PhoneNumber.pb.dart';
import 'EmailAddress.pb.dart';

class ContactInfo extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('ContactInfo')
    ..a/*<geo.Location>*/(1, 'location', PbFieldType.OM, geo.Location.getDefault, geo.Location.create)
    ..a/*<PhoneNumber>*/(2, 'phone', PbFieldType.OM, PhoneNumber.getDefault, PhoneNumber.create)
    ..a/*<EmailAddress>*/(3, 'email', PbFieldType.OM, EmailAddress.getDefault, EmailAddress.create)
    ..hasRequiredFields = false
  ;

  ContactInfo() : super();
  ContactInfo.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ContactInfo.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ContactInfo clone() => new ContactInfo()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static ContactInfo create() => new ContactInfo();
  static PbList<ContactInfo> createRepeated() => new PbList<ContactInfo>();
  static ContactInfo getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyContactInfo();
    return _defaultInstance;
  }
  static ContactInfo _defaultInstance;
  static void $checkItem(ContactInfo v) {
    if (v is! ContactInfo) checkItemFailed(v, 'ContactInfo');
  }

  geo.Location get location => $_get(0, 1, null);
  set location(geo.Location v) { setField(1, v); }
  bool hasLocation() => $_has(0, 1);
  void clearLocation() => clearField(1);

  PhoneNumber get phone => $_get(1, 2, null);
  set phone(PhoneNumber v) { setField(2, v); }
  bool hasPhone() => $_has(1, 2);
  void clearPhone() => clearField(2);

  EmailAddress get email => $_get(2, 3, null);
  set email(EmailAddress v) { setField(3, v); }
  bool hasEmail() => $_has(2, 3);
  void clearEmail() => clearField(3);
}

class _ReadonlyContactInfo extends ContactInfo with ReadonlyMessageMixin {}

