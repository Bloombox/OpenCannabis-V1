///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library base_ProductKind_pbjson;

const ProductKind$json = const {
  '1': 'ProductKind',
  '2': const [
    const {'1': 'FLOWERS', '2': 0},
    const {'1': 'EDIBLES', '2': 1},
    const {'1': 'EXTRACTS', '2': 2},
    const {'1': 'PREROLLS', '2': 3},
    const {'1': 'APOTHECARY', '2': 4},
    const {'1': 'CARTRIDGES', '2': 5},
    const {'1': 'PLANTS', '2': 6},
    const {'1': 'MERCHANDISE', '2': 7},
  ],
};

