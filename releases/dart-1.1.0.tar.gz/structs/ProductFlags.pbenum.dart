///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_ProductFlags_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class ProductFlag extends ProtobufEnum {
  static const ProductFlag VISIBLE = const ProductFlag._(0, 'VISIBLE');
  static const ProductFlag PREMIUM = const ProductFlag._(1, 'PREMIUM');
  static const ProductFlag FEATURED = const ProductFlag._(2, 'FEATURED');
  static const ProductFlag ORGANIC = const ProductFlag._(3, 'ORGANIC');
  static const ProductFlag EXCLUSIVE = const ProductFlag._(4, 'EXCLUSIVE');
  static const ProductFlag IN_HOUSE = const ProductFlag._(5, 'IN_HOUSE');
  static const ProductFlag LAST_CHANCE = const ProductFlag._(6, 'LAST_CHANCE');
  static const ProductFlag LIMITED_TIME = const ProductFlag._(7, 'LIMITED_TIME');

  static const List<ProductFlag> values = const <ProductFlag> [
    VISIBLE,
    PREMIUM,
    FEATURED,
    ORGANIC,
    EXCLUSIVE,
    IN_HOUSE,
    LAST_CHANCE,
    LIMITED_TIME,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static ProductFlag valueOf(int value) => _byValue[value] as ProductFlag;
  static void $checkItem(ProductFlag v) {
    if (v is! ProductFlag) checkItemFailed(v, 'ProductFlag');
  }

  const ProductFlag._(int v, String n) : super(v, n);
}

