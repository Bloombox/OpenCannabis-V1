///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_Shelf_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class Shelf extends ProtobufEnum {
  static const Shelf ECONOMY = const Shelf._(0, 'ECONOMY');
  static const Shelf MIDSHELF = const Shelf._(1, 'MIDSHELF');
  static const Shelf TOPSHELF = const Shelf._(2, 'TOPSHELF');

  static const List<Shelf> values = const <Shelf> [
    ECONOMY,
    MIDSHELF,
    TOPSHELF,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Shelf valueOf(int value) => _byValue[value] as Shelf;
  static void $checkItem(Shelf v) {
    if (v is! Shelf) checkItemFailed(v, 'Shelf');
  }

  const Shelf._(int v, String n) : super(v, n);
}

