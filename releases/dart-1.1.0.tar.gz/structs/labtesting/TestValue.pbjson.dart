///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestValue_pbjson;

const TestValueType$json = const {
  '1': 'TestValueType',
  '2': const [
    const {'1': 'MILLIGRAMS', '2': 0},
    const {'1': 'PERCENTAGE', '2': 1},
    const {'1': 'PRESENCE', '2': 3},
  ],
};

const TestMediaType$json = const {
  '1': 'TestMediaType',
  '2': const [
    const {'1': 'CERTIFICATE', '2': 0},
    const {'1': 'RESULTS', '2': 1},
    const {'1': 'PRODUCT_IMAGE', '2': 2},
  ],
};

const TestValue$json = const {
  '1': 'TestValue',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.structs.labtesting.TestValueType', '10': 'type'},
    const {'1': 'measurement', '3': 10, '4': 1, '5': 1, '9': 0, '10': 'measurement'},
    const {'1': 'present', '3': 20, '4': 1, '5': 8, '9': 0, '10': 'present'},
  ],
  '8': const [
    const {'1': 'value'},
  ],
};

const TestMedia$json = const {
  '1': 'TestMedia',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.structs.labtesting.TestMediaType', '10': 'type'},
    const {'1': 'media_item', '3': 2, '4': 1, '5': 11, '6': '.media.MediaItem', '10': 'mediaItem'},
  ],
};

