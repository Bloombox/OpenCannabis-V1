///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestValue_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class TestValueType extends ProtobufEnum {
  static const TestValueType MILLIGRAMS = const TestValueType._(0, 'MILLIGRAMS');
  static const TestValueType PERCENTAGE = const TestValueType._(1, 'PERCENTAGE');
  static const TestValueType PRESENCE = const TestValueType._(3, 'PRESENCE');

  static const List<TestValueType> values = const <TestValueType> [
    MILLIGRAMS,
    PERCENTAGE,
    PRESENCE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static TestValueType valueOf(int value) => _byValue[value] as TestValueType;
  static void $checkItem(TestValueType v) {
    if (v is! TestValueType) checkItemFailed(v, 'TestValueType');
  }

  const TestValueType._(int v, String n) : super(v, n);
}

class TestMediaType extends ProtobufEnum {
  static const TestMediaType CERTIFICATE = const TestMediaType._(0, 'CERTIFICATE');
  static const TestMediaType RESULTS = const TestMediaType._(1, 'RESULTS');
  static const TestMediaType PRODUCT_IMAGE = const TestMediaType._(2, 'PRODUCT_IMAGE');

  static const List<TestMediaType> values = const <TestMediaType> [
    CERTIFICATE,
    RESULTS,
    PRODUCT_IMAGE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static TestMediaType valueOf(int value) => _byValue[value] as TestMediaType;
  static void $checkItem(TestMediaType v) {
    if (v is! TestMediaType) checkItemFailed(v, 'TestMediaType');
  }

  const TestMediaType._(int v, String n) : super(v, n);
}

