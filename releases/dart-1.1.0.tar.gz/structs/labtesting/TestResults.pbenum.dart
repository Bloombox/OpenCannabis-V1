///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestResults_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class TestResults_AromaFlavor extends ProtobufEnum {
  static const TestResults_AromaFlavor PINE = const TestResults_AromaFlavor._(0, 'PINE');
  static const TestResults_AromaFlavor LEMON = const TestResults_AromaFlavor._(1, 'LEMON');
  static const TestResults_AromaFlavor PEPPER = const TestResults_AromaFlavor._(2, 'PEPPER');
  static const TestResults_AromaFlavor LAVENDER = const TestResults_AromaFlavor._(3, 'LAVENDER');
  static const TestResults_AromaFlavor HOPS = const TestResults_AromaFlavor._(4, 'HOPS');

  static const List<TestResults_AromaFlavor> values = const <TestResults_AromaFlavor> [
    PINE,
    LEMON,
    PEPPER,
    LAVENDER,
    HOPS,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static TestResults_AromaFlavor valueOf(int value) => _byValue[value] as TestResults_AromaFlavor;
  static void $checkItem(TestResults_AromaFlavor v) {
    if (v is! TestResults_AromaFlavor) checkItemFailed(v, 'TestResults_AromaFlavor');
  }

  const TestResults_AromaFlavor._(int v, String n) : super(v, n);
}

class Subjective_Feeling extends ProtobufEnum {
  static const Subjective_Feeling GROUNDING = const Subjective_Feeling._(0, 'GROUNDING');
  static const Subjective_Feeling SLEEP = const Subjective_Feeling._(1, 'SLEEP');
  static const Subjective_Feeling CALMING = const Subjective_Feeling._(2, 'CALMING');
  static const Subjective_Feeling STIMULATING = const Subjective_Feeling._(3, 'STIMULATING');
  static const Subjective_Feeling FUNNY = const Subjective_Feeling._(4, 'FUNNY');
  static const Subjective_Feeling FOCUS = const Subjective_Feeling._(5, 'FOCUS');
  static const Subjective_Feeling PASSION = const Subjective_Feeling._(6, 'PASSION');

  static const List<Subjective_Feeling> values = const <Subjective_Feeling> [
    GROUNDING,
    SLEEP,
    CALMING,
    STIMULATING,
    FUNNY,
    FOCUS,
    PASSION,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Subjective_Feeling valueOf(int value) => _byValue[value] as Subjective_Feeling;
  static void $checkItem(Subjective_Feeling v) {
    if (v is! Subjective_Feeling) checkItemFailed(v, 'Subjective_Feeling');
  }

  const Subjective_Feeling._(int v, String n) : super(v, n);
}

class Subjective_TasteNote extends ProtobufEnum {
  static const Subjective_TasteNote SWEET = const Subjective_TasteNote._(0, 'SWEET');
  static const Subjective_TasteNote SOUR = const Subjective_TasteNote._(1, 'SOUR');
  static const Subjective_TasteNote SPICE = const Subjective_TasteNote._(2, 'SPICE');
  static const Subjective_TasteNote SMOOTH = const Subjective_TasteNote._(3, 'SMOOTH');
  static const Subjective_TasteNote CITRUS = const Subjective_TasteNote._(4, 'CITRUS');
  static const Subjective_TasteNote PINE = const Subjective_TasteNote._(5, 'PINE');
  static const Subjective_TasteNote FRUIT = const Subjective_TasteNote._(6, 'FRUIT');
  static const Subjective_TasteNote TROPICS = const Subjective_TasteNote._(7, 'TROPICS');
  static const Subjective_TasteNote FLORAL = const Subjective_TasteNote._(8, 'FLORAL');
  static const Subjective_TasteNote HERB = const Subjective_TasteNote._(9, 'HERB');
  static const Subjective_TasteNote EARTH = const Subjective_TasteNote._(10, 'EARTH');

  static const List<Subjective_TasteNote> values = const <Subjective_TasteNote> [
    SWEET,
    SOUR,
    SPICE,
    SMOOTH,
    CITRUS,
    PINE,
    FRUIT,
    TROPICS,
    FLORAL,
    HERB,
    EARTH,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Subjective_TasteNote valueOf(int value) => _byValue[value] as Subjective_TasteNote;
  static void $checkItem(Subjective_TasteNote v) {
    if (v is! Subjective_TasteNote) checkItemFailed(v, 'Subjective_TasteNote');
  }

  const Subjective_TasteNote._(int v, String n) : super(v, n);
}

class Subjective_PotencyEstimate extends ProtobufEnum {
  static const Subjective_PotencyEstimate LIGHT = const Subjective_PotencyEstimate._(0, 'LIGHT');
  static const Subjective_PotencyEstimate MEDIUM = const Subjective_PotencyEstimate._(1, 'MEDIUM');
  static const Subjective_PotencyEstimate HEAVY = const Subjective_PotencyEstimate._(2, 'HEAVY');
  static const Subjective_PotencyEstimate SUPER = const Subjective_PotencyEstimate._(3, 'SUPER');

  static const List<Subjective_PotencyEstimate> values = const <Subjective_PotencyEstimate> [
    LIGHT,
    MEDIUM,
    HEAVY,
    SUPER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Subjective_PotencyEstimate valueOf(int value) => _byValue[value] as Subjective_PotencyEstimate;
  static void $checkItem(Subjective_PotencyEstimate v) {
    if (v is! Subjective_PotencyEstimate) checkItemFailed(v, 'Subjective_PotencyEstimate');
  }

  const Subjective_PotencyEstimate._(int v, String n) : super(v, n);
}

class Terpenes_Terpene extends ProtobufEnum {
  static const Terpenes_Terpene CAMPHENE = const Terpenes_Terpene._(0, 'CAMPHENE');
  static const Terpenes_Terpene CARENE = const Terpenes_Terpene._(1, 'CARENE');
  static const Terpenes_Terpene BETA_CARYOPHYLLENE = const Terpenes_Terpene._(2, 'BETA_CARYOPHYLLENE');
  static const Terpenes_Terpene CARYOPHYLLENE_OXIDE = const Terpenes_Terpene._(3, 'CARYOPHYLLENE_OXIDE');
  static const Terpenes_Terpene EUCALYPTOL = const Terpenes_Terpene._(4, 'EUCALYPTOL');
  static const Terpenes_Terpene FENCHOL = const Terpenes_Terpene._(5, 'FENCHOL');
  static const Terpenes_Terpene ALPHA_HUMULENE = const Terpenes_Terpene._(6, 'ALPHA_HUMULENE');
  static const Terpenes_Terpene LIMONENE = const Terpenes_Terpene._(7, 'LIMONENE');
  static const Terpenes_Terpene LINALOOL = const Terpenes_Terpene._(8, 'LINALOOL');
  static const Terpenes_Terpene MYRCENE = const Terpenes_Terpene._(9, 'MYRCENE');
  static const Terpenes_Terpene ALPHA_OCIMENE = const Terpenes_Terpene._(10, 'ALPHA_OCIMENE');
  static const Terpenes_Terpene BETA_OCIMENE = const Terpenes_Terpene._(11, 'BETA_OCIMENE');
  static const Terpenes_Terpene ALPHA_PHELLANDRENE = const Terpenes_Terpene._(12, 'ALPHA_PHELLANDRENE');
  static const Terpenes_Terpene ALPHA_PINENE = const Terpenes_Terpene._(13, 'ALPHA_PINENE');
  static const Terpenes_Terpene BETA_PINENE = const Terpenes_Terpene._(14, 'BETA_PINENE');
  static const Terpenes_Terpene ALPHA_TERPINEOL = const Terpenes_Terpene._(15, 'ALPHA_TERPINEOL');
  static const Terpenes_Terpene ALPHA_TERPININE = const Terpenes_Terpene._(16, 'ALPHA_TERPININE');
  static const Terpenes_Terpene GAMMA_TERPININE = const Terpenes_Terpene._(17, 'GAMMA_TERPININE');
  static const Terpenes_Terpene TERPINOLENE = const Terpenes_Terpene._(18, 'TERPINOLENE');

  static const List<Terpenes_Terpene> values = const <Terpenes_Terpene> [
    CAMPHENE,
    CARENE,
    BETA_CARYOPHYLLENE,
    CARYOPHYLLENE_OXIDE,
    EUCALYPTOL,
    FENCHOL,
    ALPHA_HUMULENE,
    LIMONENE,
    LINALOOL,
    MYRCENE,
    ALPHA_OCIMENE,
    BETA_OCIMENE,
    ALPHA_PHELLANDRENE,
    ALPHA_PINENE,
    BETA_PINENE,
    ALPHA_TERPINEOL,
    ALPHA_TERPININE,
    GAMMA_TERPININE,
    TERPINOLENE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static Terpenes_Terpene valueOf(int value) => _byValue[value] as Terpenes_Terpene;
  static void $checkItem(Terpenes_Terpene v) {
    if (v is! Terpenes_Terpene) checkItemFailed(v, 'Terpenes_Terpene');
  }

  const Terpenes_Terpene._(int v, String n) : super(v, n);
}

