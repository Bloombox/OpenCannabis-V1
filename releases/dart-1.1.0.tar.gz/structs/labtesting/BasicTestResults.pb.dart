///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_BasicTestResults;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart';

import 'TestValue.pb.dart';
import 'TestResults.pb.dart';

class BasicTestResults extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('BasicTestResults')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<TestMedia>*/(2, 'media', PbFieldType.PM, TestMedia.$checkItem, TestMedia.create)
    ..a/*<Int64>*/(3, 'lastUpdated', PbFieldType.O6, Int64.ZERO)
    ..a/*<Cannabinoids>*/(20, 'cannabinoids', PbFieldType.OM, Cannabinoids.getDefault, Cannabinoids.create)
    ..a/*<Subjective>*/(30, 'subjective', PbFieldType.OM, Subjective.getDefault, Subjective.create)
    ..hasRequiredFields = false
  ;

  BasicTestResults() : super();
  BasicTestResults.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BasicTestResults.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BasicTestResults clone() => new BasicTestResults()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static BasicTestResults create() => new BasicTestResults();
  static PbList<BasicTestResults> createRepeated() => new PbList<BasicTestResults>();
  static BasicTestResults getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyBasicTestResults();
    return _defaultInstance;
  }
  static BasicTestResults _defaultInstance;
  static void $checkItem(BasicTestResults v) {
    if (v is! BasicTestResults) checkItemFailed(v, 'BasicTestResults');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<TestMedia> get media => $_get(1, 2, null);

  Int64 get lastUpdated => $_get(2, 3, null);
  set lastUpdated(Int64 v) { $_setInt64(2, 3, v); }
  bool hasLastUpdated() => $_has(2, 3);
  void clearLastUpdated() => clearField(3);

  Cannabinoids get cannabinoids => $_get(3, 20, null);
  set cannabinoids(Cannabinoids v) { setField(20, v); }
  bool hasCannabinoids() => $_has(3, 20);
  void clearCannabinoids() => clearField(20);

  Subjective get subjective => $_get(4, 30, null);
  set subjective(Subjective v) { setField(30, v); }
  bool hasSubjective() => $_has(4, 30);
  void clearSubjective() => clearField(30);
}

class _ReadonlyBasicTestResults extends BasicTestResults with ReadonlyMessageMixin {}

