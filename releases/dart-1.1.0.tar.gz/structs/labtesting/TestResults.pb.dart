///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestResults;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart';

import 'TestValue.pb.dart';
import '../../content/Content.pb.dart' as content;

import 'TestResults.pbenum.dart';

export 'TestResults.pbenum.dart';

class TestResults extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('TestResults')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<TestMedia>*/(2, 'media', PbFieldType.PM, TestMedia.$checkItem, TestMedia.create)
    ..a/*<Int64>*/(3, 'lastUpdated', PbFieldType.O6, Int64.ZERO)
    ..a/*<Cannabinoids>*/(30, 'cannabinoids', PbFieldType.OM, Cannabinoids.getDefault, Cannabinoids.create)
    ..a/*<Terpenes>*/(31, 'terpenes', PbFieldType.OM, Terpenes.getDefault, Terpenes.create)
    ..a/*<Pesticides>*/(32, 'pesticides', PbFieldType.OM, Pesticides.getDefault, Pesticides.create)
    ..a/*<Moisture>*/(33, 'moisture', PbFieldType.OM, Moisture.getDefault, Moisture.create)
    ..pp/*<TestResults_AromaFlavor>*/(34, 'aroma', PbFieldType.PE, TestResults_AromaFlavor.$checkItem, null, TestResults_AromaFlavor.valueOf)
    ..a/*<Subjective>*/(35, 'subjectiveTesting', PbFieldType.OM, Subjective.getDefault, Subjective.create)
    ..hasRequiredFields = false
  ;

  TestResults() : super();
  TestResults.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestResults.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestResults clone() => new TestResults()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static TestResults create() => new TestResults();
  static PbList<TestResults> createRepeated() => new PbList<TestResults>();
  static TestResults getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTestResults();
    return _defaultInstance;
  }
  static TestResults _defaultInstance;
  static void $checkItem(TestResults v) {
    if (v is! TestResults) checkItemFailed(v, 'TestResults');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<TestMedia> get media => $_get(1, 2, null);

  Int64 get lastUpdated => $_get(2, 3, null);
  set lastUpdated(Int64 v) { $_setInt64(2, 3, v); }
  bool hasLastUpdated() => $_has(2, 3);
  void clearLastUpdated() => clearField(3);

  Cannabinoids get cannabinoids => $_get(3, 30, null);
  set cannabinoids(Cannabinoids v) { setField(30, v); }
  bool hasCannabinoids() => $_has(3, 30);
  void clearCannabinoids() => clearField(30);

  Terpenes get terpenes => $_get(4, 31, null);
  set terpenes(Terpenes v) { setField(31, v); }
  bool hasTerpenes() => $_has(4, 31);
  void clearTerpenes() => clearField(31);

  Pesticides get pesticides => $_get(5, 32, null);
  set pesticides(Pesticides v) { setField(32, v); }
  bool hasPesticides() => $_has(5, 32);
  void clearPesticides() => clearField(32);

  Moisture get moisture => $_get(6, 33, null);
  set moisture(Moisture v) { setField(33, v); }
  bool hasMoisture() => $_has(6, 33);
  void clearMoisture() => clearField(33);

  List<TestResults_AromaFlavor> get aroma => $_get(7, 34, null);

  Subjective get subjectiveTesting => $_get(8, 35, null);
  set subjectiveTesting(Subjective v) { setField(35, v); }
  bool hasSubjectiveTesting() => $_has(8, 35);
  void clearSubjectiveTesting() => clearField(35);
}

class _ReadonlyTestResults extends TestResults with ReadonlyMessageMixin {}

class Cannabinoids extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Cannabinoids')
    ..a/*<TestValue>*/(1, 'thc', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(2, 'thca', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(3, 'thcv', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(4, 'cbd', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(5, 'cbda', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(6, 'cbdv', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(7, 'cbdva', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(8, 'cbc', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(9, 'cbg', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(10, 'cbga', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(11, 'cbn', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..hasRequiredFields = false
  ;

  Cannabinoids() : super();
  Cannabinoids.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Cannabinoids.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Cannabinoids clone() => new Cannabinoids()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Cannabinoids create() => new Cannabinoids();
  static PbList<Cannabinoids> createRepeated() => new PbList<Cannabinoids>();
  static Cannabinoids getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyCannabinoids();
    return _defaultInstance;
  }
  static Cannabinoids _defaultInstance;
  static void $checkItem(Cannabinoids v) {
    if (v is! Cannabinoids) checkItemFailed(v, 'Cannabinoids');
  }

  TestValue get thc => $_get(0, 1, null);
  set thc(TestValue v) { setField(1, v); }
  bool hasThc() => $_has(0, 1);
  void clearThc() => clearField(1);

  TestValue get thca => $_get(1, 2, null);
  set thca(TestValue v) { setField(2, v); }
  bool hasThca() => $_has(1, 2);
  void clearThca() => clearField(2);

  TestValue get thcv => $_get(2, 3, null);
  set thcv(TestValue v) { setField(3, v); }
  bool hasThcv() => $_has(2, 3);
  void clearThcv() => clearField(3);

  TestValue get cbd => $_get(3, 4, null);
  set cbd(TestValue v) { setField(4, v); }
  bool hasCbd() => $_has(3, 4);
  void clearCbd() => clearField(4);

  TestValue get cbda => $_get(4, 5, null);
  set cbda(TestValue v) { setField(5, v); }
  bool hasCbda() => $_has(4, 5);
  void clearCbda() => clearField(5);

  TestValue get cbdv => $_get(5, 6, null);
  set cbdv(TestValue v) { setField(6, v); }
  bool hasCbdv() => $_has(5, 6);
  void clearCbdv() => clearField(6);

  TestValue get cbdva => $_get(6, 7, null);
  set cbdva(TestValue v) { setField(7, v); }
  bool hasCbdva() => $_has(6, 7);
  void clearCbdva() => clearField(7);

  TestValue get cbc => $_get(7, 8, null);
  set cbc(TestValue v) { setField(8, v); }
  bool hasCbc() => $_has(7, 8);
  void clearCbc() => clearField(8);

  TestValue get cbg => $_get(8, 9, null);
  set cbg(TestValue v) { setField(9, v); }
  bool hasCbg() => $_has(8, 9);
  void clearCbg() => clearField(9);

  TestValue get cbga => $_get(9, 10, null);
  set cbga(TestValue v) { setField(10, v); }
  bool hasCbga() => $_has(9, 10);
  void clearCbga() => clearField(10);

  TestValue get cbn => $_get(10, 11, null);
  set cbn(TestValue v) { setField(11, v); }
  bool hasCbn() => $_has(10, 11);
  void clearCbn() => clearField(11);
}

class _ReadonlyCannabinoids extends Cannabinoids with ReadonlyMessageMixin {}

class Subjective extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Subjective')
    ..a/*<content.Content>*/(1, 'description', PbFieldType.OM, content.Content.getDefault, content.Content.create)
    ..a/*<content.Content>*/(2, 'taste', PbFieldType.OM, content.Content.getDefault, content.Content.create)
    ..e/*<Subjective_PotencyEstimate>*/(3, 'potency', PbFieldType.OE, Subjective_PotencyEstimate.LIGHT, Subjective_PotencyEstimate.valueOf)
    ..pp/*<Subjective_Feeling>*/(4, 'feelingTags', PbFieldType.PE, Subjective_Feeling.$checkItem, null, Subjective_Feeling.valueOf)
    ..pp/*<Subjective_TasteNote>*/(5, 'tastingNotes', PbFieldType.PE, Subjective_TasteNote.$checkItem, null, Subjective_TasteNote.valueOf)
    ..hasRequiredFields = false
  ;

  Subjective() : super();
  Subjective.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Subjective.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Subjective clone() => new Subjective()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Subjective create() => new Subjective();
  static PbList<Subjective> createRepeated() => new PbList<Subjective>();
  static Subjective getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlySubjective();
    return _defaultInstance;
  }
  static Subjective _defaultInstance;
  static void $checkItem(Subjective v) {
    if (v is! Subjective) checkItemFailed(v, 'Subjective');
  }

  content.Content get description => $_get(0, 1, null);
  set description(content.Content v) { setField(1, v); }
  bool hasDescription() => $_has(0, 1);
  void clearDescription() => clearField(1);

  content.Content get taste => $_get(1, 2, null);
  set taste(content.Content v) { setField(2, v); }
  bool hasTaste() => $_has(1, 2);
  void clearTaste() => clearField(2);

  Subjective_PotencyEstimate get potency => $_get(2, 3, null);
  set potency(Subjective_PotencyEstimate v) { setField(3, v); }
  bool hasPotency() => $_has(2, 3);
  void clearPotency() => clearField(3);

  List<Subjective_Feeling> get feelingTags => $_get(3, 4, null);

  List<Subjective_TasteNote> get tastingNotes => $_get(4, 5, null);
}

class _ReadonlySubjective extends Subjective with ReadonlyMessageMixin {}

class Terpenes_Result extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Terpenes_Result')
    ..e/*<Terpenes_Terpene>*/(1, 'terpene', PbFieldType.OE, Terpenes_Terpene.CAMPHENE, Terpenes_Terpene.valueOf)
    ..a/*<TestValue>*/(2, 'measurement', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..hasRequiredFields = false
  ;

  Terpenes_Result() : super();
  Terpenes_Result.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Terpenes_Result.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Terpenes_Result clone() => new Terpenes_Result()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Terpenes_Result create() => new Terpenes_Result();
  static PbList<Terpenes_Result> createRepeated() => new PbList<Terpenes_Result>();
  static Terpenes_Result getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTerpenes_Result();
    return _defaultInstance;
  }
  static Terpenes_Result _defaultInstance;
  static void $checkItem(Terpenes_Result v) {
    if (v is! Terpenes_Result) checkItemFailed(v, 'Terpenes_Result');
  }

  Terpenes_Terpene get terpene => $_get(0, 1, null);
  set terpene(Terpenes_Terpene v) { setField(1, v); }
  bool hasTerpene() => $_has(0, 1);
  void clearTerpene() => clearField(1);

  TestValue get measurement => $_get(1, 2, null);
  set measurement(TestValue v) { setField(2, v); }
  bool hasMeasurement() => $_has(1, 2);
  void clearMeasurement() => clearField(2);
}

class _ReadonlyTerpenes_Result extends Terpenes_Result with ReadonlyMessageMixin {}

class Terpenes extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Terpenes')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<Terpenes_Result>*/(10, 'terpenes', PbFieldType.PM, Terpenes_Result.$checkItem, Terpenes_Result.create)
    ..hasRequiredFields = false
  ;

  Terpenes() : super();
  Terpenes.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Terpenes.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Terpenes clone() => new Terpenes()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Terpenes create() => new Terpenes();
  static PbList<Terpenes> createRepeated() => new PbList<Terpenes>();
  static Terpenes getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyTerpenes();
    return _defaultInstance;
  }
  static Terpenes _defaultInstance;
  static void $checkItem(Terpenes v) {
    if (v is! Terpenes) checkItemFailed(v, 'Terpenes');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<Terpenes_Result> get terpenes => $_get(1, 10, null);
}

class _ReadonlyTerpenes extends Terpenes with ReadonlyMessageMixin {}

class Pesticides_MeasurementsEntry extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Pesticides_MeasurementsEntry')
    ..a/*<String>*/(1, 'key', PbFieldType.OS)
    ..a/*<TestValue>*/(2, 'value', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..hasRequiredFields = false
  ;

  Pesticides_MeasurementsEntry() : super();
  Pesticides_MeasurementsEntry.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Pesticides_MeasurementsEntry.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Pesticides_MeasurementsEntry clone() => new Pesticides_MeasurementsEntry()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Pesticides_MeasurementsEntry create() => new Pesticides_MeasurementsEntry();
  static PbList<Pesticides_MeasurementsEntry> createRepeated() => new PbList<Pesticides_MeasurementsEntry>();
  static Pesticides_MeasurementsEntry getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyPesticides_MeasurementsEntry();
    return _defaultInstance;
  }
  static Pesticides_MeasurementsEntry _defaultInstance;
  static void $checkItem(Pesticides_MeasurementsEntry v) {
    if (v is! Pesticides_MeasurementsEntry) checkItemFailed(v, 'Pesticides_MeasurementsEntry');
  }

  String get key => $_get(0, 1, '');
  set key(String v) { $_setString(0, 1, v); }
  bool hasKey() => $_has(0, 1);
  void clearKey() => clearField(1);

  TestValue get value => $_get(1, 2, null);
  set value(TestValue v) { setField(2, v); }
  bool hasValue() => $_has(1, 2);
  void clearValue() => clearField(2);
}

class _ReadonlyPesticides_MeasurementsEntry extends Pesticides_MeasurementsEntry with ReadonlyMessageMixin {}

class Pesticides extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Pesticides')
    ..a/*<bool>*/(1, 'pesticideFree', PbFieldType.OB)
    ..pp/*<Pesticides_MeasurementsEntry>*/(2, 'measurements', PbFieldType.PM, Pesticides_MeasurementsEntry.$checkItem, Pesticides_MeasurementsEntry.create)
    ..hasRequiredFields = false
  ;

  Pesticides() : super();
  Pesticides.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Pesticides.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Pesticides clone() => new Pesticides()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Pesticides create() => new Pesticides();
  static PbList<Pesticides> createRepeated() => new PbList<Pesticides>();
  static Pesticides getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyPesticides();
    return _defaultInstance;
  }
  static Pesticides _defaultInstance;
  static void $checkItem(Pesticides v) {
    if (v is! Pesticides) checkItemFailed(v, 'Pesticides');
  }

  bool get pesticideFree => $_get(0, 1, false);
  set pesticideFree(bool v) { $_setBool(0, 1, v); }
  bool hasPesticideFree() => $_has(0, 1);
  void clearPesticideFree() => clearField(1);

  List<Pesticides_MeasurementsEntry> get measurements => $_get(1, 2, null);
}

class _ReadonlyPesticides extends Pesticides with ReadonlyMessageMixin {}

class Moisture extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Moisture')
    ..a/*<TestValue>*/(1, 'measurement', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..hasRequiredFields = false
  ;

  Moisture() : super();
  Moisture.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Moisture.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Moisture clone() => new Moisture()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Moisture create() => new Moisture();
  static PbList<Moisture> createRepeated() => new PbList<Moisture>();
  static Moisture getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyMoisture();
    return _defaultInstance;
  }
  static Moisture _defaultInstance;
  static void $checkItem(Moisture v) {
    if (v is! Moisture) checkItemFailed(v, 'Moisture');
  }

  TestValue get measurement => $_get(0, 1, null);
  set measurement(TestValue v) { setField(1, v); }
  bool hasMeasurement() => $_has(0, 1);
  void clearMeasurement() => clearField(1);
}

class _ReadonlyMoisture extends Moisture with ReadonlyMessageMixin {}

