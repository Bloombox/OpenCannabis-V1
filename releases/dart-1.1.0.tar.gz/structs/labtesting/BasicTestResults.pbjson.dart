///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_BasicTestResults_pbjson;

const BasicTestResults$json = const {
  '1': 'BasicTestResults',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'media', '3': 2, '4': 3, '5': 11, '6': '.structs.labtesting.TestMedia', '10': 'media'},
    const {'1': 'last_updated', '3': 3, '4': 1, '5': 3, '10': 'lastUpdated'},
    const {'1': 'Cannabinoids', '3': 20, '4': 1, '5': 11, '6': '.structs.labtesting.Cannabinoids', '10': 'Cannabinoids'},
    const {'1': 'subjective', '3': 30, '4': 1, '5': 11, '6': '.structs.labtesting.Subjective', '10': 'subjective'},
  ],
};

