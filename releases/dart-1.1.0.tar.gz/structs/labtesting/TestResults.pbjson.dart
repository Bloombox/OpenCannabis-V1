///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_TestResults_pbjson;

const TestResults$json = const {
  '1': 'TestResults',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'media', '3': 2, '4': 3, '5': 11, '6': '.structs.labtesting.TestMedia', '10': 'media'},
    const {'1': 'last_updated', '3': 3, '4': 1, '5': 3, '10': 'lastUpdated'},
    const {'1': 'cannabinoids', '3': 30, '4': 1, '5': 11, '6': '.structs.labtesting.Cannabinoids', '10': 'cannabinoids'},
    const {'1': 'terpenes', '3': 31, '4': 1, '5': 11, '6': '.structs.labtesting.Terpenes', '10': 'terpenes'},
    const {'1': 'pesticides', '3': 32, '4': 1, '5': 11, '6': '.structs.labtesting.Pesticides', '10': 'pesticides'},
    const {'1': 'moisture', '3': 33, '4': 1, '5': 11, '6': '.structs.labtesting.Moisture', '10': 'moisture'},
    const {'1': 'aroma', '3': 34, '4': 3, '5': 14, '6': '.structs.labtesting.TestResults.AromaFlavor', '10': 'aroma'},
    const {'1': 'subjective_testing', '3': 35, '4': 1, '5': 11, '6': '.structs.labtesting.Subjective', '10': 'subjectiveTesting'},
  ],
  '4': const [TestResults_AromaFlavor$json],
};

const TestResults_AromaFlavor$json = const {
  '1': 'AromaFlavor',
  '2': const [
    const {'1': 'PINE', '2': 0},
    const {'1': 'LEMON', '2': 1},
    const {'1': 'PEPPER', '2': 2},
    const {'1': 'LAVENDER', '2': 3},
    const {'1': 'HOPS', '2': 4},
  ],
};

const Cannabinoids$json = const {
  '1': 'Cannabinoids',
  '2': const [
    const {'1': 'thc', '3': 1, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'thc'},
    const {'1': 'thca', '3': 2, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'thca'},
    const {'1': 'thcv', '3': 3, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'thcv'},
    const {'1': 'cbd', '3': 4, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbd'},
    const {'1': 'cbda', '3': 5, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbda'},
    const {'1': 'cbdv', '3': 6, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbdv'},
    const {'1': 'cbdva', '3': 7, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbdva'},
    const {'1': 'cbc', '3': 8, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbc'},
    const {'1': 'cbg', '3': 9, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbg'},
    const {'1': 'cbga', '3': 10, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbga'},
    const {'1': 'cbn', '3': 11, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbn'},
  ],
};

const Subjective$json = const {
  '1': 'Subjective',
  '2': const [
    const {'1': 'description', '3': 1, '4': 1, '5': 11, '6': '.content.Content', '10': 'description'},
    const {'1': 'taste', '3': 2, '4': 1, '5': 11, '6': '.content.Content', '10': 'taste'},
    const {'1': 'potency', '3': 3, '4': 1, '5': 14, '6': '.structs.labtesting.Subjective.PotencyEstimate', '10': 'potency'},
    const {'1': 'feeling_tags', '3': 4, '4': 3, '5': 14, '6': '.structs.labtesting.Subjective.Feeling', '10': 'feelingTags'},
    const {'1': 'tasting_notes', '3': 5, '4': 3, '5': 14, '6': '.structs.labtesting.Subjective.TasteNote', '10': 'tastingNotes'},
  ],
  '4': const [Subjective_Feeling$json, Subjective_TasteNote$json, Subjective_PotencyEstimate$json],
};

const Subjective_Feeling$json = const {
  '1': 'Feeling',
  '2': const [
    const {'1': 'GROUNDING', '2': 0},
    const {'1': 'SLEEP', '2': 1},
    const {'1': 'CALMING', '2': 2},
    const {'1': 'STIMULATING', '2': 3},
    const {'1': 'FUNNY', '2': 4},
    const {'1': 'FOCUS', '2': 5},
    const {'1': 'PASSION', '2': 6},
  ],
};

const Subjective_TasteNote$json = const {
  '1': 'TasteNote',
  '2': const [
    const {'1': 'SWEET', '2': 0},
    const {'1': 'SOUR', '2': 1},
    const {'1': 'SPICE', '2': 2},
    const {'1': 'SMOOTH', '2': 3},
    const {'1': 'CITRUS', '2': 4},
    const {'1': 'PINE', '2': 5},
    const {'1': 'FRUIT', '2': 6},
    const {'1': 'TROPICS', '2': 7},
    const {'1': 'FLORAL', '2': 8},
    const {'1': 'HERB', '2': 9},
    const {'1': 'EARTH', '2': 10},
  ],
};

const Subjective_PotencyEstimate$json = const {
  '1': 'PotencyEstimate',
  '2': const [
    const {'1': 'LIGHT', '2': 0},
    const {'1': 'MEDIUM', '2': 1},
    const {'1': 'HEAVY', '2': 2},
    const {'1': 'SUPER', '2': 3},
  ],
};

const Terpenes$json = const {
  '1': 'Terpenes',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'terpenes', '3': 10, '4': 3, '5': 11, '6': '.structs.labtesting.Terpenes.Result', '10': 'terpenes'},
  ],
  '3': const [Terpenes_Result$json],
  '4': const [Terpenes_Terpene$json],
};

const Terpenes_Result$json = const {
  '1': 'Result',
  '2': const [
    const {'1': 'terpene', '3': 1, '4': 1, '5': 14, '6': '.structs.labtesting.Terpenes.Terpene', '10': 'terpene'},
    const {'1': 'measurement', '3': 2, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

const Terpenes_Terpene$json = const {
  '1': 'Terpene',
  '2': const [
    const {'1': 'CAMPHENE', '2': 0},
    const {'1': 'CARENE', '2': 1},
    const {'1': 'BETA_CARYOPHYLLENE', '2': 2},
    const {'1': 'CARYOPHYLLENE_OXIDE', '2': 3},
    const {'1': 'EUCALYPTOL', '2': 4},
    const {'1': 'FENCHOL', '2': 5},
    const {'1': 'ALPHA_HUMULENE', '2': 6},
    const {'1': 'LIMONENE', '2': 7},
    const {'1': 'LINALOOL', '2': 8},
    const {'1': 'MYRCENE', '2': 9},
    const {'1': 'ALPHA_OCIMENE', '2': 10},
    const {'1': 'BETA_OCIMENE', '2': 11},
    const {'1': 'ALPHA_PHELLANDRENE', '2': 12},
    const {'1': 'ALPHA_PINENE', '2': 13},
    const {'1': 'BETA_PINENE', '2': 14},
    const {'1': 'ALPHA_TERPINEOL', '2': 15},
    const {'1': 'ALPHA_TERPININE', '2': 16},
    const {'1': 'GAMMA_TERPININE', '2': 17},
    const {'1': 'TERPINOLENE', '2': 18},
  ],
};

const Pesticides$json = const {
  '1': 'Pesticides',
  '2': const [
    const {'1': 'pesticide_free', '3': 1, '4': 1, '5': 8, '10': 'pesticideFree'},
    const {'1': 'measurements', '3': 2, '4': 3, '5': 11, '6': '.structs.labtesting.Pesticides.MeasurementsEntry', '10': 'measurements'},
  ],
  '3': const [Pesticides_MeasurementsEntry$json],
};

const Pesticides_MeasurementsEntry$json = const {
  '1': 'MeasurementsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'value'},
  ],
  '7': const {'7': true},
};

const Moisture$json = const {
  '1': 'Moisture',
  '2': const [
    const {'1': 'measurement', '3': 1, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

