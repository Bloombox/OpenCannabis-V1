///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_Shelf_pbjson;

const Shelf$json = const {
  '1': 'Shelf',
  '2': const [
    const {'1': 'ECONOMY', '2': 0},
    const {'1': 'MIDSHELF', '2': 1},
    const {'1': 'TOPSHELF', '2': 2},
  ],
};

