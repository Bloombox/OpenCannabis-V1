///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library oauth_Scope;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class Scope extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Scope')
    ..a/*<String>*/(1, 'label', PbFieldType.OS)
    ..a/*<String>*/(2, 'uri', PbFieldType.OS)
    ..hasRequiredFields = false
  ;

  Scope() : super();
  Scope.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Scope.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Scope clone() => new Scope()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Scope create() => new Scope();
  static PbList<Scope> createRepeated() => new PbList<Scope>();
  static Scope getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyScope();
    return _defaultInstance;
  }
  static Scope _defaultInstance;
  static void $checkItem(Scope v) {
    if (v is! Scope) checkItemFailed(v, 'Scope');
  }

  String get label => $_get(0, 1, '');
  set label(String v) { $_setString(0, 1, v); }
  bool hasLabel() => $_has(0, 1);
  void clearLabel() => clearField(1);

  String get uri => $_get(1, 2, '');
  set uri(String v) { $_setString(1, 2, v); }
  bool hasUri() => $_has(1, 2);
  void clearUri() => clearField(2);
}

class _ReadonlyScope extends Scope with ReadonlyMessageMixin {}

