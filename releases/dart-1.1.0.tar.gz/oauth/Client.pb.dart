///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library oauth_Client;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class Client extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Client')
    ..a/*<String>*/(1, 'clientId', PbFieldType.OS)
    ..a/*<String>*/(2, 'clientSecret', PbFieldType.OS)
    ..hasRequiredFields = false
  ;

  Client() : super();
  Client.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Client.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Client clone() => new Client()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Client create() => new Client();
  static PbList<Client> createRepeated() => new PbList<Client>();
  static Client getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyClient();
    return _defaultInstance;
  }
  static Client _defaultInstance;
  static void $checkItem(Client v) {
    if (v is! Client) checkItemFailed(v, 'Client');
  }

  String get clientId => $_get(0, 1, '');
  set clientId(String v) { $_setString(0, 1, v); }
  bool hasClientId() => $_has(0, 1);
  void clearClientId() => clearField(1);

  String get clientSecret => $_get(1, 2, '');
  set clientSecret(String v) { $_setString(1, 2, v); }
  bool hasClientSecret() => $_has(1, 2);
  void clearClientSecret() => clearField(2);
}

class _ReadonlyClient extends Client with ReadonlyMessageMixin {}

class ClientID extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('ClientID')
    ..a/*<String>*/(1, 'id', PbFieldType.OS)
    ..hasRequiredFields = false
  ;

  ClientID() : super();
  ClientID.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ClientID.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ClientID clone() => new ClientID()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static ClientID create() => new ClientID();
  static PbList<ClientID> createRepeated() => new PbList<ClientID>();
  static ClientID getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyClientID();
    return _defaultInstance;
  }
  static ClientID _defaultInstance;
  static void $checkItem(ClientID v) {
    if (v is! ClientID) checkItemFailed(v, 'ClientID');
  }

  String get id => $_get(0, 1, '');
  set id(String v) { $_setString(0, 1, v); }
  bool hasId() => $_has(0, 1);
  void clearId() => clearField(1);
}

class _ReadonlyClientID extends ClientID with ReadonlyMessageMixin {}

class ClientSecret extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('ClientSecret')
    ..a/*<String>*/(1, 'secret', PbFieldType.OS)
    ..hasRequiredFields = false
  ;

  ClientSecret() : super();
  ClientSecret.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ClientSecret.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ClientSecret clone() => new ClientSecret()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static ClientSecret create() => new ClientSecret();
  static PbList<ClientSecret> createRepeated() => new PbList<ClientSecret>();
  static ClientSecret getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyClientSecret();
    return _defaultInstance;
  }
  static ClientSecret _defaultInstance;
  static void $checkItem(ClientSecret v) {
    if (v is! ClientSecret) checkItemFailed(v, 'ClientSecret');
  }

  String get secret => $_get(0, 1, '');
  set secret(String v) { $_setString(0, 1, v); }
  bool hasSecret() => $_has(0, 1);
  void clearSecret() => clearField(1);
}

class _ReadonlyClientSecret extends ClientSecret with ReadonlyMessageMixin {}

