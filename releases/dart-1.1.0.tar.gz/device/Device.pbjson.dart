///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library device_Device_pbjson;

const DeviceType$json = const {
  '1': 'DeviceType',
  '2': const [
    const {'1': 'WEB', '2': 0},
    const {'1': 'MOBILE', '2': 1},
    const {'1': 'DESKTOP', '2': 2},
    const {'1': 'SERVER', '2': 3},
  ],
};

const Device$json = const {
  '1': 'Device',
  '2': const [
    const {'1': 'metadata', '3': 1, '4': 1, '5': 11, '6': '.device.DeviceMetadata', '10': 'metadata'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.device.DeviceType', '10': 'type'},
    const {'1': 'flags', '3': 3, '4': 1, '5': 11, '6': '.device.DeviceFlags', '10': 'flags'},
    const {'1': 'key', '3': 4, '4': 1, '5': 11, '6': '.device.DeviceKey', '10': 'key'},
  ],
};

const DeviceMetadata$json = const {
  '1': 'DeviceMetadata',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '10': 'uuid'},
    const {'1': 'fingerprint', '3': 2, '4': 1, '5': 9, '10': 'fingerprint'},
  ],
};

const DeviceFlags$json = const {
  '1': 'DeviceFlags',
  '2': const [
    const {'1': 'ephemeral', '3': 1, '4': 1, '5': 8, '10': 'ephemeral'},
    const {'1': 'managed', '3': 2, '4': 1, '5': 8, '10': 'managed'},
  ],
};

const DeviceKey$json = const {
  '1': 'DeviceKey',
  '2': const [
    const {'1': 'public', '3': 1, '4': 1, '5': 12, '10': 'public'},
    const {'1': 'sha256', '3': 2, '4': 1, '5': 12, '10': 'sha256'},
    const {'1': 'private', '3': 3, '4': 1, '5': 12, '10': 'private'},
  ],
};

