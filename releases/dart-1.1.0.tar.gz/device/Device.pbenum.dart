///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library device_Device_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class DeviceType extends ProtobufEnum {
  static const DeviceType WEB = const DeviceType._(0, 'WEB');
  static const DeviceType MOBILE = const DeviceType._(1, 'MOBILE');
  static const DeviceType DESKTOP = const DeviceType._(2, 'DESKTOP');
  static const DeviceType SERVER = const DeviceType._(3, 'SERVER');

  static const List<DeviceType> values = const <DeviceType> [
    WEB,
    MOBILE,
    DESKTOP,
    SERVER,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static DeviceType valueOf(int value) => _byValue[value] as DeviceType;
  static void $checkItem(DeviceType v) {
    if (v is! DeviceType) checkItemFailed(v, 'DeviceType');
  }

  const DeviceType._(int v, String n) : super(v, n);
}

