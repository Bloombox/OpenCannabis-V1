///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library device_Device;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import 'Device.pbenum.dart';

export 'Device.pbenum.dart';

class Device extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Device')
    ..a/*<DeviceMetadata>*/(1, 'metadata', PbFieldType.OM, DeviceMetadata.getDefault, DeviceMetadata.create)
    ..e/*<DeviceType>*/(2, 'type', PbFieldType.OE, DeviceType.WEB, DeviceType.valueOf)
    ..a/*<DeviceFlags>*/(3, 'flags', PbFieldType.OM, DeviceFlags.getDefault, DeviceFlags.create)
    ..a/*<DeviceKey>*/(4, 'key', PbFieldType.OM, DeviceKey.getDefault, DeviceKey.create)
    ..hasRequiredFields = false
  ;

  Device() : super();
  Device.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Device.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Device clone() => new Device()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Device create() => new Device();
  static PbList<Device> createRepeated() => new PbList<Device>();
  static Device getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyDevice();
    return _defaultInstance;
  }
  static Device _defaultInstance;
  static void $checkItem(Device v) {
    if (v is! Device) checkItemFailed(v, 'Device');
  }

  DeviceMetadata get metadata => $_get(0, 1, null);
  set metadata(DeviceMetadata v) { setField(1, v); }
  bool hasMetadata() => $_has(0, 1);
  void clearMetadata() => clearField(1);

  DeviceType get type => $_get(1, 2, null);
  set type(DeviceType v) { setField(2, v); }
  bool hasType() => $_has(1, 2);
  void clearType() => clearField(2);

  DeviceFlags get flags => $_get(2, 3, null);
  set flags(DeviceFlags v) { setField(3, v); }
  bool hasFlags() => $_has(2, 3);
  void clearFlags() => clearField(3);

  DeviceKey get key => $_get(3, 4, null);
  set key(DeviceKey v) { setField(4, v); }
  bool hasKey() => $_has(3, 4);
  void clearKey() => clearField(4);
}

class _ReadonlyDevice extends Device with ReadonlyMessageMixin {}

class DeviceMetadata extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('DeviceMetadata')
    ..a/*<String>*/(1, 'uuid', PbFieldType.OS)
    ..a/*<String>*/(2, 'fingerprint', PbFieldType.OS)
    ..hasRequiredFields = false
  ;

  DeviceMetadata() : super();
  DeviceMetadata.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeviceMetadata.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeviceMetadata clone() => new DeviceMetadata()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static DeviceMetadata create() => new DeviceMetadata();
  static PbList<DeviceMetadata> createRepeated() => new PbList<DeviceMetadata>();
  static DeviceMetadata getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyDeviceMetadata();
    return _defaultInstance;
  }
  static DeviceMetadata _defaultInstance;
  static void $checkItem(DeviceMetadata v) {
    if (v is! DeviceMetadata) checkItemFailed(v, 'DeviceMetadata');
  }

  String get uuid => $_get(0, 1, '');
  set uuid(String v) { $_setString(0, 1, v); }
  bool hasUuid() => $_has(0, 1);
  void clearUuid() => clearField(1);

  String get fingerprint => $_get(1, 2, '');
  set fingerprint(String v) { $_setString(1, 2, v); }
  bool hasFingerprint() => $_has(1, 2);
  void clearFingerprint() => clearField(2);
}

class _ReadonlyDeviceMetadata extends DeviceMetadata with ReadonlyMessageMixin {}

class DeviceFlags extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('DeviceFlags')
    ..a/*<bool>*/(1, 'ephemeral', PbFieldType.OB)
    ..a/*<bool>*/(2, 'managed', PbFieldType.OB)
    ..hasRequiredFields = false
  ;

  DeviceFlags() : super();
  DeviceFlags.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeviceFlags.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeviceFlags clone() => new DeviceFlags()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static DeviceFlags create() => new DeviceFlags();
  static PbList<DeviceFlags> createRepeated() => new PbList<DeviceFlags>();
  static DeviceFlags getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyDeviceFlags();
    return _defaultInstance;
  }
  static DeviceFlags _defaultInstance;
  static void $checkItem(DeviceFlags v) {
    if (v is! DeviceFlags) checkItemFailed(v, 'DeviceFlags');
  }

  bool get ephemeral => $_get(0, 1, false);
  set ephemeral(bool v) { $_setBool(0, 1, v); }
  bool hasEphemeral() => $_has(0, 1);
  void clearEphemeral() => clearField(1);

  bool get managed => $_get(1, 2, false);
  set managed(bool v) { $_setBool(1, 2, v); }
  bool hasManaged() => $_has(1, 2);
  void clearManaged() => clearField(2);
}

class _ReadonlyDeviceFlags extends DeviceFlags with ReadonlyMessageMixin {}

class DeviceKey extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('DeviceKey')
    ..a/*<List<int>>*/(1, 'public', PbFieldType.OY)
    ..a/*<List<int>>*/(2, 'sha256', PbFieldType.OY)
    ..a/*<List<int>>*/(3, 'private', PbFieldType.OY)
    ..hasRequiredFields = false
  ;

  DeviceKey() : super();
  DeviceKey.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeviceKey.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeviceKey clone() => new DeviceKey()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static DeviceKey create() => new DeviceKey();
  static PbList<DeviceKey> createRepeated() => new PbList<DeviceKey>();
  static DeviceKey getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyDeviceKey();
    return _defaultInstance;
  }
  static DeviceKey _defaultInstance;
  static void $checkItem(DeviceKey v) {
    if (v is! DeviceKey) checkItemFailed(v, 'DeviceKey');
  }

  List<int> get public => $_get(0, 1, null);
  set public(List<int> v) { $_setBytes(0, 1, v); }
  bool hasPublic() => $_has(0, 1);
  void clearPublic() => clearField(1);

  List<int> get sha256 => $_get(1, 2, null);
  set sha256(List<int> v) { $_setBytes(1, 2, v); }
  bool hasSha256() => $_has(1, 2);
  void clearSha256() => clearField(2);

  List<int> get private => $_get(2, 3, null);
  set private(List<int> v) { $_setBytes(2, 3, v); }
  bool hasPrivate() => $_has(2, 3);
  void clearPrivate() => clearField(3);
}

class _ReadonlyDeviceKey extends DeviceKey with ReadonlyMessageMixin {}

