///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library geo_Location_pbjson;

const Location$json = const {
  '1': 'Location',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.content.Name', '10': 'name'},
    const {'1': 'address', '3': 2, '4': 1, '5': 11, '6': '.geo.Address', '10': 'address'},
    const {'1': 'point', '3': 3, '4': 1, '5': 11, '6': '.geo.Point', '10': 'point'},
  ],
};

