///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library geo_Point_pbjson;

const Point$json = const {
  '1': 'Point',
  '2': const [
    const {'1': 'latitude', '3': 1, '4': 1, '5': 1, '10': 'latitude'},
    const {'1': 'longitude', '3': 2, '4': 1, '5': 1, '10': 'longitude'},
    const {'1': 'elevation', '3': 3, '4': 1, '5': 1, '10': 'elevation'},
    const {'1': 'accuracy', '3': 4, '4': 1, '5': 1, '10': 'accuracy'},
  ],
};

