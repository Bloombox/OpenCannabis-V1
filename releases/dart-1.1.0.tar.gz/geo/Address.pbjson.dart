///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library geo_Address_pbjson;

const Address$json = const {
  '1': 'Address',
  '2': const [
    const {'1': 'first_line', '3': 1, '4': 1, '5': 9, '10': 'firstLine'},
    const {'1': 'second_line', '3': 2, '4': 1, '5': 9, '10': 'secondLine'},
    const {'1': 'city', '3': 3, '4': 1, '5': 9, '10': 'city'},
    const {'1': 'state', '3': 4, '4': 1, '5': 9, '10': 'state'},
    const {'1': 'zipcode', '3': 5, '4': 1, '5': 9, '10': 'zipcode'},
    const {'1': 'country', '3': 6, '4': 1, '5': 9, '10': 'country'},
  ],
};

