///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library geo_Location;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../content/Name.pb.dart' as content;
import 'Address.pb.dart';
import 'Point.pb.dart';

class Location extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Location')
    ..a/*<content.Name>*/(1, 'name', PbFieldType.OM, content.Name.getDefault, content.Name.create)
    ..a/*<Address>*/(2, 'address', PbFieldType.OM, Address.getDefault, Address.create)
    ..a/*<Point>*/(3, 'point', PbFieldType.OM, Point.getDefault, Point.create)
    ..hasRequiredFields = false
  ;

  Location() : super();
  Location.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Location.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Location clone() => new Location()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Location create() => new Location();
  static PbList<Location> createRepeated() => new PbList<Location>();
  static Location getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyLocation();
    return _defaultInstance;
  }
  static Location _defaultInstance;
  static void $checkItem(Location v) {
    if (v is! Location) checkItemFailed(v, 'Location');
  }

  content.Name get name => $_get(0, 1, null);
  set name(content.Name v) { setField(1, v); }
  bool hasName() => $_has(0, 1);
  void clearName() => clearField(1);

  Address get address => $_get(1, 2, null);
  set address(Address v) { setField(2, v); }
  bool hasAddress() => $_has(1, 2);
  void clearAddress() => clearField(2);

  Point get point => $_get(2, 3, null);
  set point(Point v) { setField(3, v); }
  bool hasPoint() => $_has(2, 3);
  void clearPoint() => clearField(3);
}

class _ReadonlyLocation extends Location with ReadonlyMessageMixin {}

