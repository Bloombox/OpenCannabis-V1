///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library geo_Point;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class Point extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Point')
    ..a/*<double>*/(1, 'latitude', PbFieldType.OD)
    ..a/*<double>*/(2, 'longitude', PbFieldType.OD)
    ..a/*<double>*/(3, 'elevation', PbFieldType.OD)
    ..a/*<double>*/(4, 'accuracy', PbFieldType.OD)
    ..hasRequiredFields = false
  ;

  Point() : super();
  Point.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Point.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Point clone() => new Point()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Point create() => new Point();
  static PbList<Point> createRepeated() => new PbList<Point>();
  static Point getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyPoint();
    return _defaultInstance;
  }
  static Point _defaultInstance;
  static void $checkItem(Point v) {
    if (v is! Point) checkItemFailed(v, 'Point');
  }

  double get latitude => $_get(0, 1, null);
  set latitude(double v) { $_setDouble(0, 1, v); }
  bool hasLatitude() => $_has(0, 1);
  void clearLatitude() => clearField(1);

  double get longitude => $_get(1, 2, null);
  set longitude(double v) { $_setDouble(1, 2, v); }
  bool hasLongitude() => $_has(1, 2);
  void clearLongitude() => clearField(2);

  double get elevation => $_get(2, 3, null);
  set elevation(double v) { $_setDouble(2, 3, v); }
  bool hasElevation() => $_has(2, 3);
  void clearElevation() => clearField(3);

  double get accuracy => $_get(3, 4, null);
  set accuracy(double v) { $_setDouble(3, 4, v); }
  bool hasAccuracy() => $_has(3, 4);
  void clearAccuracy() => clearField(4);
}

class _ReadonlyPoint extends Point with ReadonlyMessageMixin {}

