///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library proximity_BluetoothBeacon;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

class BluetoothBeacon extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('BluetoothBeacon')
    ..a/*<String>*/(1, 'uuid', PbFieldType.OS)
    ..a/*<int>*/(2, 'major', PbFieldType.OU3)
    ..a/*<int>*/(3, 'minor', PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  BluetoothBeacon() : super();
  BluetoothBeacon.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BluetoothBeacon.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BluetoothBeacon clone() => new BluetoothBeacon()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static BluetoothBeacon create() => new BluetoothBeacon();
  static PbList<BluetoothBeacon> createRepeated() => new PbList<BluetoothBeacon>();
  static BluetoothBeacon getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyBluetoothBeacon();
    return _defaultInstance;
  }
  static BluetoothBeacon _defaultInstance;
  static void $checkItem(BluetoothBeacon v) {
    if (v is! BluetoothBeacon) checkItemFailed(v, 'BluetoothBeacon');
  }

  String get uuid => $_get(0, 1, '');
  set uuid(String v) { $_setString(0, 1, v); }
  bool hasUuid() => $_has(0, 1);
  void clearUuid() => clearField(1);

  int get major => $_get(1, 2, 0);
  set major(int v) { $_setUnsignedInt32(1, 2, v); }
  bool hasMajor() => $_has(1, 2);
  void clearMajor() => clearField(2);

  int get minor => $_get(2, 3, 0);
  set minor(int v) { $_setUnsignedInt32(2, 3, v); }
  bool hasMinor() => $_has(2, 3);
  void clearMinor() => clearField(3);
}

class _ReadonlyBluetoothBeacon extends BluetoothBeacon with ReadonlyMessageMixin {}

