///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library proximity_BluetoothBeacon_pbjson;

const BluetoothBeacon$json = const {
  '1': 'BluetoothBeacon',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '10': 'uuid'},
    const {'1': 'major', '3': 2, '4': 1, '5': 13, '10': 'major'},
    const {'1': 'minor', '3': 3, '4': 1, '5': 13, '10': 'minor'},
  ],
};

