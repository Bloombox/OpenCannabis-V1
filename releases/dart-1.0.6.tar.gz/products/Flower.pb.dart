///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library Flower;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../base/ProductKey.pb.dart' as base;
import '../content/ProductContent.pb.dart' as content;
import '../content/MaterialsData.pb.dart' as content;
import '../structs/FlagsDescriptor.pb.dart' as structs;
import '../structs/pricing/PricingDescriptor.pb.dart' as structs$pricing;
import '../structs/labtesting/RichTesting.pb.dart' as structs$labtesting;

class Flower extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('Flower')
    ..a/*<base.ProductKey>*/(1, 'key', PbFieldType.OM, base.ProductKey.getDefault, base.ProductKey.create)
    ..a/*<content.ProductContent>*/(20, 'product', PbFieldType.OM, content.ProductContent.getDefault, content.ProductContent.create)
    ..a/*<content.MaterialsData>*/(21, 'material', PbFieldType.OM, content.MaterialsData.getDefault, content.MaterialsData.create)
    ..pp/*<structs.ProductFlag>*/(22, 'flags', PbFieldType.PM, structs.ProductFlag.$checkItem, structs.ProductFlag.create)
    ..a/*<structs$pricing.ProductPricing>*/(23, 'pricing', PbFieldType.OM, structs$pricing.ProductPricing.getDefault, structs$pricing.ProductPricing.create)
    ..a/*<structs$labtesting.RichTesting>*/(24, 'testing', PbFieldType.OM, structs$labtesting.RichTesting.getDefault, structs$labtesting.RichTesting.create)
    ..hasRequiredFields = false
  ;

  Flower() : super();
  Flower.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Flower.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Flower clone() => new Flower()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static Flower create() => new Flower();
  static PbList<Flower> createRepeated() => new PbList<Flower>();
  static Flower getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyFlower();
    return _defaultInstance;
  }
  static Flower _defaultInstance;
  static void $checkItem(Flower v) {
    if (v is! Flower) checkItemFailed(v, 'Flower');
  }

  base.ProductKey get key => $_get(0, 1, null);
  set key(base.ProductKey v) { setField(1, v); }
  bool hasKey() => $_has(0, 1);
  void clearKey() => clearField(1);

  content.ProductContent get product => $_get(1, 20, null);
  set product(content.ProductContent v) { setField(20, v); }
  bool hasProduct() => $_has(1, 20);
  void clearProduct() => clearField(20);

  content.MaterialsData get material => $_get(2, 21, null);
  set material(content.MaterialsData v) { setField(21, v); }
  bool hasMaterial() => $_has(2, 21);
  void clearMaterial() => clearField(21);

  List<structs.ProductFlag> get flags => $_get(3, 22, null);

  structs$pricing.ProductPricing get pricing => $_get(4, 23, null);
  set pricing(structs$pricing.ProductPricing v) { setField(23, v); }
  bool hasPricing() => $_has(4, 23);
  void clearPricing() => clearField(23);

  structs$labtesting.RichTesting get testing => $_get(5, 24, null);
  set testing(structs$labtesting.RichTesting v) { setField(24, v); }
  bool hasTesting() => $_has(5, 24);
  void clearTesting() => clearField(24);
}

class _ReadonlyFlower extends Flower with ReadonlyMessageMixin {}

