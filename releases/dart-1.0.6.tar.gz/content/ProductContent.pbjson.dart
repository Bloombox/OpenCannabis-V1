///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library content_ProductContent_pbjson;

const ProductContent$json = const {
  '1': 'ProductContent',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.content.Name', '10': 'name'},
    const {'1': 'summary', '3': 2, '4': 1, '5': 11, '6': '.content.Content', '10': 'summary'},
    const {'1': 'brand', '3': 3, '4': 1, '5': 11, '6': '.content.Brand', '10': 'brand'},
    const {'1': 'media', '3': 20, '4': 3, '5': 11, '6': '.media.MediaItem', '10': 'media'},
    const {'1': 'usage', '3': 30, '4': 1, '5': 11, '6': '.content.Content', '10': 'usage'},
    const {'1': 'dosage', '3': 31, '4': 1, '5': 11, '6': '.content.Content', '10': 'dosage'},
    const {'1': 'advice', '3': 32, '4': 1, '5': 11, '6': '.content.Content', '10': 'advice'},
    const {'1': 'modified', '3': 40, '4': 1, '5': 3, '10': 'modified'},
    const {'1': 'created', '3': 41, '4': 1, '5': 3, '10': 'created'},
  ],
};

