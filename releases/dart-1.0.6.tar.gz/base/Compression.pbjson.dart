///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library base_Compression_pbjson;

const Compression$json = const {
  '1': 'Compression',
  '2': const [
    const {'1': 'enabled', '3': 1, '4': 1, '5': 8, '10': 'enabled'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.base.Compression.Type', '10': 'type'},
  ],
  '4': const [Compression_Type$json],
};

const Compression_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'GZIP', '2': 0},
  ],
};

