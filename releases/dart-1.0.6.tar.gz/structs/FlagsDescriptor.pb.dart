///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_FlagsDescriptor;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import 'FlagsDescriptor.pbenum.dart';

export 'FlagsDescriptor.pbenum.dart';

class ProductFlag extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('ProductFlag')
    ..e/*<FlagType>*/(1, 'type', PbFieldType.OE, FlagType.VISIBLE, FlagType.valueOf)
    ..a/*<bool>*/(2, 'value', PbFieldType.OB)
    ..hasRequiredFields = false
  ;

  ProductFlag() : super();
  ProductFlag.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductFlag.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductFlag clone() => new ProductFlag()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static ProductFlag create() => new ProductFlag();
  static PbList<ProductFlag> createRepeated() => new PbList<ProductFlag>();
  static ProductFlag getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyProductFlag();
    return _defaultInstance;
  }
  static ProductFlag _defaultInstance;
  static void $checkItem(ProductFlag v) {
    if (v is! ProductFlag) checkItemFailed(v, 'ProductFlag');
  }

  FlagType get type => $_get(0, 1, null);
  set type(FlagType v) { setField(1, v); }
  bool hasType() => $_has(0, 1);
  void clearType() => clearField(1);

  bool get value => $_get(1, 2, false);
  set value(bool v) { $_setBool(1, 2, v); }
  bool hasValue() => $_has(1, 2);
  void clearValue() => clearField(2);
}

class _ReadonlyProductFlag extends ProductFlag with ReadonlyMessageMixin {}

