///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_SubjectiveTesting;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:protobuf/protobuf.dart';

import '../../content/Content.pb.dart' as content;

import 'SubjectiveTesting.pbenum.dart';

export 'SubjectiveTesting.pbenum.dart';

class SubjectiveTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('SubjectiveTesting')
    ..a/*<content.Content>*/(1, 'description', PbFieldType.OM, content.Content.getDefault, content.Content.create)
    ..e/*<PotencyEstimate>*/(2, 'potency', PbFieldType.OE, PotencyEstimate.LIGHT, PotencyEstimate.valueOf)
    ..pp/*<Feeling>*/(3, 'feelingTags', PbFieldType.PE, Feeling.$checkItem, null, Feeling.valueOf)
    ..hasRequiredFields = false
  ;

  SubjectiveTesting() : super();
  SubjectiveTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SubjectiveTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SubjectiveTesting clone() => new SubjectiveTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static SubjectiveTesting create() => new SubjectiveTesting();
  static PbList<SubjectiveTesting> createRepeated() => new PbList<SubjectiveTesting>();
  static SubjectiveTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlySubjectiveTesting();
    return _defaultInstance;
  }
  static SubjectiveTesting _defaultInstance;
  static void $checkItem(SubjectiveTesting v) {
    if (v is! SubjectiveTesting) checkItemFailed(v, 'SubjectiveTesting');
  }

  content.Content get description => $_get(0, 1, null);
  set description(content.Content v) { setField(1, v); }
  bool hasDescription() => $_has(0, 1);
  void clearDescription() => clearField(1);

  PotencyEstimate get potency => $_get(1, 2, null);
  set potency(PotencyEstimate v) { setField(2, v); }
  bool hasPotency() => $_has(1, 2);
  void clearPotency() => clearField(2);

  List<Feeling> get feelingTags => $_get(2, 3, null);
}

class _ReadonlySubjectiveTesting extends SubjectiveTesting with ReadonlyMessageMixin {}

