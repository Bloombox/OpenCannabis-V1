///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_BasicTesting_pbjson;

const BasicTesting$json = const {
  '1': 'BasicTesting',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'media', '3': 2, '4': 3, '5': 11, '6': '.structs.labtesting.TestMedia', '10': 'media'},
    const {'1': 'last_updated', '3': 3, '4': 1, '5': 3, '10': 'lastUpdated'},
    const {'1': 'thc', '3': 10, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'thc'},
    const {'1': 'cbd', '3': 11, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbd'},
    const {'1': 'cbn', '3': 12, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbn'},
    const {'1': 'cbg', '3': 13, '4': 1, '5': 11, '6': '.structs.labtesting.TestValue', '10': 'cbg'},
    const {'1': 'subjective_testing', '3': 30, '4': 1, '5': 11, '6': '.structs.labtesting.SubjectiveTesting', '10': 'subjectiveTesting'},
  ],
};

