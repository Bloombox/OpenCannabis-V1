///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs.labtesting_BasicTesting;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, bool, double, String, List, override;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart';

import 'TestValue.pb.dart';
import 'SubjectiveTesting.pb.dart';

class BasicTesting extends GeneratedMessage {
  static final BuilderInfo _i = new BuilderInfo('BasicTesting')
    ..a/*<bool>*/(1, 'available', PbFieldType.OB)
    ..pp/*<TestMedia>*/(2, 'media', PbFieldType.PM, TestMedia.$checkItem, TestMedia.create)
    ..a/*<Int64>*/(3, 'lastUpdated', PbFieldType.O6, Int64.ZERO)
    ..a/*<TestValue>*/(10, 'thc', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(11, 'cbd', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(12, 'cbn', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<TestValue>*/(13, 'cbg', PbFieldType.OM, TestValue.getDefault, TestValue.create)
    ..a/*<SubjectiveTesting>*/(30, 'subjectiveTesting', PbFieldType.OM, SubjectiveTesting.getDefault, SubjectiveTesting.create)
    ..hasRequiredFields = false
  ;

  BasicTesting() : super();
  BasicTesting.fromBuffer(List<int> i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BasicTesting.fromJson(String i, [ExtensionRegistry r = ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BasicTesting clone() => new BasicTesting()..mergeFromMessage(this);
  BuilderInfo get info_ => _i;
  static BasicTesting create() => new BasicTesting();
  static PbList<BasicTesting> createRepeated() => new PbList<BasicTesting>();
  static BasicTesting getDefault() {
    if (_defaultInstance == null) _defaultInstance = new _ReadonlyBasicTesting();
    return _defaultInstance;
  }
  static BasicTesting _defaultInstance;
  static void $checkItem(BasicTesting v) {
    if (v is! BasicTesting) checkItemFailed(v, 'BasicTesting');
  }

  bool get available => $_get(0, 1, false);
  set available(bool v) { $_setBool(0, 1, v); }
  bool hasAvailable() => $_has(0, 1);
  void clearAvailable() => clearField(1);

  List<TestMedia> get media => $_get(1, 2, null);

  Int64 get lastUpdated => $_get(2, 3, null);
  set lastUpdated(Int64 v) { $_setInt64(2, 3, v); }
  bool hasLastUpdated() => $_has(2, 3);
  void clearLastUpdated() => clearField(3);

  TestValue get thc => $_get(3, 10, null);
  set thc(TestValue v) { setField(10, v); }
  bool hasThc() => $_has(3, 10);
  void clearThc() => clearField(10);

  TestValue get cbd => $_get(4, 11, null);
  set cbd(TestValue v) { setField(11, v); }
  bool hasCbd() => $_has(4, 11);
  void clearCbd() => clearField(11);

  TestValue get cbn => $_get(5, 12, null);
  set cbn(TestValue v) { setField(12, v); }
  bool hasCbn() => $_has(5, 12);
  void clearCbn() => clearField(12);

  TestValue get cbg => $_get(6, 13, null);
  set cbg(TestValue v) { setField(13, v); }
  bool hasCbg() => $_has(6, 13);
  void clearCbg() => clearField(13);

  SubjectiveTesting get subjectiveTesting => $_get(7, 30, null);
  set subjectiveTesting(SubjectiveTesting v) { setField(30, v); }
  bool hasSubjectiveTesting() => $_has(7, 30);
  void clearSubjectiveTesting() => clearField(30);
}

class _ReadonlyBasicTesting extends BasicTesting with ReadonlyMessageMixin {}

