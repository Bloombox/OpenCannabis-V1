///
//  Generated code. Do not modify.
///
// ignore_for_file: non_constant_identifier_names
// ignore_for_file: library_prefixes
library structs_FlagsDescriptor_pbenum;

// ignore: UNUSED_SHOWN_NAME
import 'dart:core' show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart';

class FlagType extends ProtobufEnum {
  static const FlagType VISIBLE = const FlagType._(0, 'VISIBLE');
  static const FlagType PREMIUM = const FlagType._(1, 'PREMIUM');
  static const FlagType FEATURED = const FlagType._(2, 'FEATURED');
  static const FlagType LASTCHANCE = const FlagType._(3, 'LASTCHANCE');
  static const FlagType INHOUSE = const FlagType._(4, 'INHOUSE');

  static const List<FlagType> values = const <FlagType> [
    VISIBLE,
    PREMIUM,
    FEATURED,
    LASTCHANCE,
    INHOUSE,
  ];

  static final Map<int, dynamic> _byValue = ProtobufEnum.initByValue(values);
  static FlagType valueOf(int value) => _byValue[value] as FlagType;
  static void $checkItem(FlagType v) {
    if (v is! FlagType) checkItemFailed(v, 'FlagType');
  }

  const FlagType._(int v, String n) : super(v, n);
}

