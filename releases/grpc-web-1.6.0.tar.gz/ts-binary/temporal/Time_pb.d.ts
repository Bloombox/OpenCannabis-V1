import * as jspb from "google-protobuf"

export class Time extends jspb.Message {
  getIso8601(): string;
  setIso8601(value: string): void;
  hasIso8601(): boolean;

  getSpecCase(): Time.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Time.AsObject;
  static toObject(includeInstance: boolean, msg: Time): Time.AsObject;
  static serializeBinaryToWriter(message: Time, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Time;
  static deserializeBinaryFromReader(message: Time, reader: jspb.BinaryReader): Time;
}

export namespace Time {
  export type AsObject = {
    iso8601: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    ISO8601 = 1,
  }
}

