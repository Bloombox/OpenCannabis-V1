import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class Timehash extends jspb.Message {
  getComponentList(): Array<string>;
  setComponentList(value: Array<string>): void;
  clearComponentList(): void;
  addComponent(value: string, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Timehash.AsObject;
  static toObject(includeInstance: boolean, msg: Timehash): Timehash.AsObject;
  static serializeBinaryToWriter(message: Timehash, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Timehash;
  static deserializeBinaryFromReader(message: Timehash, reader: jspb.BinaryReader): Timehash;
}

export namespace Timehash {
  export type AsObject = {
    componentList: Array<string>,
  }
}

