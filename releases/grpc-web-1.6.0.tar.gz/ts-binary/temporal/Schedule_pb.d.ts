import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';
import * as temporal_Time_pb from '../temporal/Time_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';
import * as temporal_Interval_pb from '../temporal/Interval_pb';

export class Schedule extends jspb.Message {
  getAbsolute(): temporal_Instant_pb.Instant | undefined;
  setAbsolute(value?: temporal_Instant_pb.Instant): void;
  hasAbsolute(): boolean;
  clearAbsolute(): void;
  hasAbsolute(): boolean;

  getTime(): temporal_Time_pb.Time | undefined;
  setTime(value?: temporal_Time_pb.Time): void;
  hasTime(): boolean;
  clearTime(): void;
  hasTime(): boolean;

  getInterval(): temporal_Interval_pb.Interval;
  setInterval(value: temporal_Interval_pb.Interval): void;
  hasInterval(): boolean;

  getSpecCase(): Schedule.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Schedule.AsObject;
  static toObject(includeInstance: boolean, msg: Schedule): Schedule.AsObject;
  static serializeBinaryToWriter(message: Schedule, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Schedule;
  static deserializeBinaryFromReader(message: Schedule, reader: jspb.BinaryReader): Schedule;
}

export namespace Schedule {
  export type AsObject = {
    absolute?: temporal_Instant_pb.Instant.AsObject,
    time?: temporal_Time_pb.Time.AsObject,
    interval: temporal_Interval_pb.Interval,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    ABSOLUTE = 1,
    TIME = 2,
    INTERVAL = 3,
  }
}

