import * as jspb from "google-protobuf"

import * as base_Compression_pb from '../base/Compression_pb';
import * as content_Content_pb from '../content/Content_pb';
import * as crypto_primitives_Keys_pb from '../crypto/primitives/Keys_pb';
import * as crypto_primitives_Integrity_pb from '../crypto/primitives/Integrity_pb';

export class EncryptedData extends jspb.Message {
  getData(): Uint8Array | string;
  getData_asU8(): Uint8Array;
  getData_asB64(): string;
  setData(value: Uint8Array | string): void;

  getEncoding(): content_Content_pb.Encoding;
  setEncoding(value: content_Content_pb.Encoding): void;

  getCompression(): base_Compression_pb.Compression | undefined;
  setCompression(value?: base_Compression_pb.Compression): void;
  hasCompression(): boolean;
  clearCompression(): void;

  getFingerprint(): crypto_primitives_Integrity_pb.Hash | undefined;
  setFingerprint(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasFingerprint(): boolean;
  clearFingerprint(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EncryptedData.AsObject;
  static toObject(includeInstance: boolean, msg: EncryptedData): EncryptedData.AsObject;
  static serializeBinaryToWriter(message: EncryptedData, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EncryptedData;
  static deserializeBinaryFromReader(message: EncryptedData, reader: jspb.BinaryReader): EncryptedData;
}

export namespace EncryptedData {
  export type AsObject = {
    data: Uint8Array | string,
    encoding: content_Content_pb.Encoding,
    compression?: base_Compression_pb.Compression.AsObject,
    fingerprint?: crypto_primitives_Integrity_pb.Hash.AsObject,
  }
}

export class EncryptedContainer extends jspb.Message {
  getPayload(): EncryptedData | undefined;
  setPayload(value?: EncryptedData): void;
  hasPayload(): boolean;
  clearPayload(): void;

  getKeying(): crypto_primitives_Keys_pb.KeyType;
  setKeying(value: crypto_primitives_Keys_pb.KeyType): void;

  getVector(): crypto_primitives_Keys_pb.InitializationVector | undefined;
  setVector(value?: crypto_primitives_Keys_pb.InitializationVector): void;
  hasVector(): boolean;
  clearVector(): void;

  getKey(): crypto_primitives_Keys_pb.SymmetricKeyParameters | undefined;
  setKey(value?: crypto_primitives_Keys_pb.SymmetricKeyParameters): void;
  hasKey(): boolean;
  clearKey(): void;
  hasKey(): boolean;

  getKeypair(): crypto_primitives_Keys_pb.AsymmetricKeypairParameters | undefined;
  setKeypair(value?: crypto_primitives_Keys_pb.AsymmetricKeypairParameters): void;
  hasKeypair(): boolean;
  clearKeypair(): void;
  hasKeypair(): boolean;

  getParametersCase(): EncryptedContainer.ParametersCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EncryptedContainer.AsObject;
  static toObject(includeInstance: boolean, msg: EncryptedContainer): EncryptedContainer.AsObject;
  static serializeBinaryToWriter(message: EncryptedContainer, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EncryptedContainer;
  static deserializeBinaryFromReader(message: EncryptedContainer, reader: jspb.BinaryReader): EncryptedContainer;
}

export namespace EncryptedContainer {
  export type AsObject = {
    payload?: EncryptedData.AsObject,
    keying: crypto_primitives_Keys_pb.KeyType,
    vector?: crypto_primitives_Keys_pb.InitializationVector.AsObject,
    key?: crypto_primitives_Keys_pb.SymmetricKeyParameters.AsObject,
    keypair?: crypto_primitives_Keys_pb.AsymmetricKeypairParameters.AsObject,
  }

  export enum ParametersCase { 
    PARAMETERS_NOT_SET = 0,
    KEY = 4,
    KEYPAIR = 5,
  }
}

