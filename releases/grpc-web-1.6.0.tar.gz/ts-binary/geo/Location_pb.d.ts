import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';
import * as geo_Point_pb from '../geo/Point_pb';
import * as geo_Address_pb from '../geo/Address_pb';
import * as geo_Distance_pb from '../geo/Distance_pb';
import * as content_Name_pb from '../content/Name_pb';

export class Location extends jspb.Message {
  getName(): content_Name_pb.Name | undefined;
  setName(value?: content_Name_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getAddress(): geo_Address_pb.Address | undefined;
  setAddress(value?: geo_Address_pb.Address): void;
  hasAddress(): boolean;
  clearAddress(): void;

  getPoint(): geo_Point_pb.Point | undefined;
  setPoint(value?: geo_Point_pb.Point): void;
  hasPoint(): boolean;
  clearPoint(): void;

  getAccuracy(): geo_Distance_pb.LocationAccuracy | undefined;
  setAccuracy(value?: geo_Distance_pb.LocationAccuracy): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Location.AsObject;
  static toObject(includeInstance: boolean, msg: Location): Location.AsObject;
  static serializeBinaryToWriter(message: Location, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Location;
  static deserializeBinaryFromReader(message: Location, reader: jspb.BinaryReader): Location;
}

export namespace Location {
  export type AsObject = {
    name?: content_Name_pb.Name.AsObject,
    address?: geo_Address_pb.Address.AsObject,
    point?: geo_Point_pb.Point.AsObject,
    accuracy?: geo_Distance_pb.LocationAccuracy.AsObject,
  }
}

