import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';
import * as geo_Distance_pb from '../geo/Distance_pb';

export class Point extends jspb.Message {
  getLatitude(): number;
  setLatitude(value: number): void;

  getLongitude(): number;
  setLongitude(value: number): void;

  getElevation(): geo_Distance_pb.Distance | undefined;
  setElevation(value?: geo_Distance_pb.Distance): void;
  hasElevation(): boolean;
  clearElevation(): void;

  getAccuracy(): geo_Distance_pb.Distance | undefined;
  setAccuracy(value?: geo_Distance_pb.Distance): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Point.AsObject;
  static toObject(includeInstance: boolean, msg: Point): Point.AsObject;
  static serializeBinaryToWriter(message: Point, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Point;
  static deserializeBinaryFromReader(message: Point, reader: jspb.BinaryReader): Point;
}

export namespace Point {
  export type AsObject = {
    latitude: number,
    longitude: number,
    elevation?: geo_Distance_pb.Distance.AsObject,
    accuracy?: geo_Distance_pb.Distance.AsObject,
  }
}

