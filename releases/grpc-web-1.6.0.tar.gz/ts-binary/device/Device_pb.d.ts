import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class Device extends jspb.Message {
  getUuid(): string;
  setUuid(value: string): void;

  getType(): DeviceType;
  setType(value: DeviceType): void;

  getFlags(): DeviceFlags | undefined;
  setFlags(value?: DeviceFlags): void;
  hasFlags(): boolean;
  clearFlags(): void;

  getKey(): DeviceCredentials | undefined;
  setKey(value?: DeviceCredentials): void;
  hasKey(): boolean;
  clearKey(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Device.AsObject;
  static toObject(includeInstance: boolean, msg: Device): Device.AsObject;
  static serializeBinaryToWriter(message: Device, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Device;
  static deserializeBinaryFromReader(message: Device, reader: jspb.BinaryReader): Device;
}

export namespace Device {
  export type AsObject = {
    uuid: string,
    type: DeviceType,
    flags?: DeviceFlags.AsObject,
    key?: DeviceCredentials.AsObject,
  }
}

export class DeviceFlags extends jspb.Message {
  getEphemeral(): boolean;
  setEphemeral(value: boolean): void;

  getManaged(): boolean;
  setManaged(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeviceFlags.AsObject;
  static toObject(includeInstance: boolean, msg: DeviceFlags): DeviceFlags.AsObject;
  static serializeBinaryToWriter(message: DeviceFlags, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeviceFlags;
  static deserializeBinaryFromReader(message: DeviceFlags, reader: jspb.BinaryReader): DeviceFlags;
}

export namespace DeviceFlags {
  export type AsObject = {
    ephemeral: boolean,
    managed: boolean,
  }
}

export class DeviceCredentials extends jspb.Message {
  getPublicKey(): Uint8Array | string;
  getPublicKey_asU8(): Uint8Array;
  getPublicKey_asB64(): string;
  setPublicKey(value: Uint8Array | string): void;

  getPrivateKey(): Uint8Array | string;
  getPrivateKey_asU8(): Uint8Array;
  getPrivateKey_asB64(): string;
  setPrivateKey(value: Uint8Array | string): void;

  getSha256(): string;
  setSha256(value: string): void;

  getIdentity(): string;
  setIdentity(value: string): void;

  getAuthoritiesList(): Array<Uint8Array | string>;
  setAuthoritiesList(value: Array<Uint8Array | string>): void;
  clearAuthoritiesList(): void;
  addAuthorities(value: Uint8Array | string, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeviceCredentials.AsObject;
  static toObject(includeInstance: boolean, msg: DeviceCredentials): DeviceCredentials.AsObject;
  static serializeBinaryToWriter(message: DeviceCredentials, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeviceCredentials;
  static deserializeBinaryFromReader(message: DeviceCredentials, reader: jspb.BinaryReader): DeviceCredentials;
}

export namespace DeviceCredentials {
  export type AsObject = {
    publicKey: Uint8Array | string,
    privateKey: Uint8Array | string,
    sha256: string,
    identity: string,
    authoritiesList: Array<Uint8Array | string>,
  }
}

export enum DeviceType { 
  UNKNOWN_DEVICE_TYPE = 0,
  DESKTOP = 1,
  PHONE = 2,
  TABLET = 3,
  TV = 4,
  EMBEDDED = 5,
  SERVER = 6,
}
