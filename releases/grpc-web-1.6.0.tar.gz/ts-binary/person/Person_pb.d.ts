import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';
import * as temporal_Date_pb from '../temporal/Date_pb';
import * as contact_ContactInfo_pb from '../contact/ContactInfo_pb';
import * as person_PersonName_pb from '../person/PersonName_pb';

export class Person extends jspb.Message {
  getName(): person_PersonName_pb.Name | undefined;
  setName(value?: person_PersonName_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getLegalName(): person_PersonName_pb.Name | undefined;
  setLegalName(value?: person_PersonName_pb.Name): void;
  hasLegalName(): boolean;
  clearLegalName(): void;

  getAlternateName(): person_PersonName_pb.Name | undefined;
  setAlternateName(value?: person_PersonName_pb.Name): void;
  hasAlternateName(): boolean;
  clearAlternateName(): void;

  getContact(): contact_ContactInfo_pb.ContactInfo | undefined;
  setContact(value?: contact_ContactInfo_pb.ContactInfo): void;
  hasContact(): boolean;
  clearContact(): void;

  getDateOfBirth(): temporal_Date_pb.Date | undefined;
  setDateOfBirth(value?: temporal_Date_pb.Date): void;
  hasDateOfBirth(): boolean;
  clearDateOfBirth(): void;

  getGender(): Gender;
  setGender(value: Gender): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Person.AsObject;
  static toObject(includeInstance: boolean, msg: Person): Person.AsObject;
  static serializeBinaryToWriter(message: Person, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Person;
  static deserializeBinaryFromReader(message: Person, reader: jspb.BinaryReader): Person;
}

export namespace Person {
  export type AsObject = {
    name?: person_PersonName_pb.Name.AsObject,
    legalName?: person_PersonName_pb.Name.AsObject,
    alternateName?: person_PersonName_pb.Name.AsObject,
    contact?: contact_ContactInfo_pb.ContactInfo.AsObject,
    dateOfBirth?: temporal_Date_pb.Date.AsObject,
    gender: Gender,
  }
}

export enum Gender { 
  UNSPECIFIED = 0,
  MALE = 1,
  FEMALE = 2,
  OTHER = 3,
}
