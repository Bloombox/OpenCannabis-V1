import * as jspb from "google-protobuf"

export enum CaliforniaAgency { 
  UNKNOWN_AGENCY = 0,
  CDFA = 1,
  CBCC = 2,
  CDCA = 3,
  CDPH = 4,
}
