import * as jspb from "google-protobuf"

export enum Language { 
  LANGUAGE_UNSPECIFIED = 0,
  ENGLISH = 1,
  SPANISH = 2,
  FRENCH = 3,
}
