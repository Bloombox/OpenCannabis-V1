import * as jspb from "google-protobuf"

export class Compression extends jspb.Message {
  getEnabled(): boolean;
  setEnabled(value: boolean): void;

  getType(): Compression.Type;
  setType(value: Compression.Type): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Compression.AsObject;
  static toObject(includeInstance: boolean, msg: Compression): Compression.AsObject;
  static serializeBinaryToWriter(message: Compression, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Compression;
  static deserializeBinaryFromReader(message: Compression, reader: jspb.BinaryReader): Compression;
}

export namespace Compression {
  export type AsObject = {
    enabled: boolean,
    type: Compression.Type,
  }

  export enum Type { 
    NO_COMPRESSION = 0,
    GZIP = 1,
    BROTLI = 2,
    SNAPPY = 3,
  }
}

