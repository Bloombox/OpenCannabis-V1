import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';
import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as content_Name_pb from '../content/Name_pb';
import * as base_ProductKind_pb from '../base/ProductKind_pb';

export class ProductReference extends jspb.Message {
  getName(): content_Name_pb.Name | undefined;
  setName(value?: content_Name_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getKey(): ProductKey | undefined;
  setKey(value?: ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductReference.AsObject;
  static toObject(includeInstance: boolean, msg: ProductReference): ProductReference.AsObject;
  static serializeBinaryToWriter(message: ProductReference, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductReference;
  static deserializeBinaryFromReader(message: ProductReference, reader: jspb.BinaryReader): ProductReference;
}

export namespace ProductReference {
  export type AsObject = {
    name?: content_Name_pb.Name.AsObject,
    key?: ProductKey.AsObject,
  }
}

export class ProductKey extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getType(): base_ProductKind_pb.ProductKind;
  setType(value: base_ProductKind_pb.ProductKind): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductKey.AsObject;
  static toObject(includeInstance: boolean, msg: ProductKey): ProductKey.AsObject;
  static serializeBinaryToWriter(message: ProductKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductKey;
  static deserializeBinaryFromReader(message: ProductKey, reader: jspb.BinaryReader): ProductKey;
}

export namespace ProductKey {
  export type AsObject = {
    id: string,
    type: base_ProductKind_pb.ProductKind,
  }
}

