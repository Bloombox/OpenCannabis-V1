import * as jspb from "google-protobuf"

import * as content_Name_pb from '../content/Name_pb';
import * as content_Content_pb from '../content/Content_pb';
import * as content_Brand_pb from '../content/Brand_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';
import * as media_MediaKey_pb from '../media/MediaKey_pb';
import * as structs_ProductFlags_pb from '../structs/ProductFlags_pb';
import * as structs_labtesting_TestResults_pb from '../structs/labtesting/TestResults_pb';
import * as structs_pricing_PricingDescriptor_pb from '../structs/pricing/PricingDescriptor_pb';

export class ProductTimestamps extends jspb.Message {
  getCreated(): temporal_Instant_pb.Instant | undefined;
  setCreated(value?: temporal_Instant_pb.Instant): void;
  hasCreated(): boolean;
  clearCreated(): void;

  getModified(): temporal_Instant_pb.Instant | undefined;
  setModified(value?: temporal_Instant_pb.Instant): void;
  hasModified(): boolean;
  clearModified(): void;

  getPublished(): temporal_Instant_pb.Instant | undefined;
  setPublished(value?: temporal_Instant_pb.Instant): void;
  hasPublished(): boolean;
  clearPublished(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductTimestamps.AsObject;
  static toObject(includeInstance: boolean, msg: ProductTimestamps): ProductTimestamps.AsObject;
  static serializeBinaryToWriter(message: ProductTimestamps, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductTimestamps;
  static deserializeBinaryFromReader(message: ProductTimestamps, reader: jspb.BinaryReader): ProductTimestamps;
}

export namespace ProductTimestamps {
  export type AsObject = {
    created?: temporal_Instant_pb.Instant.AsObject,
    modified?: temporal_Instant_pb.Instant.AsObject,
    published?: temporal_Instant_pb.Instant.AsObject,
  }
}

export class ProductContent extends jspb.Message {
  getName(): content_Name_pb.Name | undefined;
  setName(value?: content_Name_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getBrand(): content_Brand_pb.Brand | undefined;
  setBrand(value?: content_Brand_pb.Brand): void;
  hasBrand(): boolean;
  clearBrand(): void;

  getSummary(): content_Content_pb.Content | undefined;
  setSummary(value?: content_Content_pb.Content): void;
  hasSummary(): boolean;
  clearSummary(): void;

  getUsage(): content_Content_pb.Content | undefined;
  setUsage(value?: content_Content_pb.Content): void;
  hasUsage(): boolean;
  clearUsage(): void;

  getDosage(): content_Content_pb.Content | undefined;
  setDosage(value?: content_Content_pb.Content): void;
  hasDosage(): boolean;
  clearDosage(): void;

  getMediaList(): Array<media_MediaKey_pb.MediaReference>;
  setMediaList(value: Array<media_MediaKey_pb.MediaReference>): void;
  clearMediaList(): void;
  addMedia(value?: media_MediaKey_pb.MediaReference, index?: number): media_MediaKey_pb.MediaReference;

  getPricing(): structs_pricing_PricingDescriptor_pb.ProductPricing | undefined;
  setPricing(value?: structs_pricing_PricingDescriptor_pb.ProductPricing): void;
  hasPricing(): boolean;
  clearPricing(): void;

  getTests(): structs_labtesting_TestResults_pb.TestResults | undefined;
  setTests(value?: structs_labtesting_TestResults_pb.TestResults): void;
  hasTests(): boolean;
  clearTests(): void;

  getFlagsList(): Array<structs_ProductFlags_pb.ProductFlag>;
  setFlagsList(value: Array<structs_ProductFlags_pb.ProductFlag>): void;
  clearFlagsList(): void;
  addFlags(value: structs_ProductFlags_pb.ProductFlag, index?: number): void;

  getTs(): ProductTimestamps | undefined;
  setTs(value?: ProductTimestamps): void;
  hasTs(): boolean;
  clearTs(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductContent.AsObject;
  static toObject(includeInstance: boolean, msg: ProductContent): ProductContent.AsObject;
  static serializeBinaryToWriter(message: ProductContent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductContent;
  static deserializeBinaryFromReader(message: ProductContent, reader: jspb.BinaryReader): ProductContent;
}

export namespace ProductContent {
  export type AsObject = {
    name?: content_Name_pb.Name.AsObject,
    brand?: content_Brand_pb.Brand.AsObject,
    summary?: content_Content_pb.Content.AsObject,
    usage?: content_Content_pb.Content.AsObject,
    dosage?: content_Content_pb.Content.AsObject,
    mediaList: Array<media_MediaKey_pb.MediaReference.AsObject>,
    pricing?: structs_pricing_PricingDescriptor_pb.ProductPricing.AsObject,
    tests?: structs_labtesting_TestResults_pb.TestResults.AsObject,
    flagsList: Array<structs_ProductFlags_pb.ProductFlag>,
    ts?: ProductTimestamps.AsObject,
  }
}

