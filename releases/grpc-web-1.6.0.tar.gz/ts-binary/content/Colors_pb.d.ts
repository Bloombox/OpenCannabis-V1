import * as jspb from "google-protobuf"

export class RGBAColorSpec extends jspb.Message {
  getR(): number;
  setR(value: number): void;

  getG(): number;
  setG(value: number): void;

  getB(): number;
  setB(value: number): void;

  getA(): number;
  setA(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RGBAColorSpec.AsObject;
  static toObject(includeInstance: boolean, msg: RGBAColorSpec): RGBAColorSpec.AsObject;
  static serializeBinaryToWriter(message: RGBAColorSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RGBAColorSpec;
  static deserializeBinaryFromReader(message: RGBAColorSpec, reader: jspb.BinaryReader): RGBAColorSpec;
}

export namespace RGBAColorSpec {
  export type AsObject = {
    r: number,
    g: number,
    b: number,
    a: number,
  }
}

export class HSBColorSpec extends jspb.Message {
  getH(): number;
  setH(value: number): void;

  getS(): number;
  setS(value: number): void;

  getB(): number;
  setB(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HSBColorSpec.AsObject;
  static toObject(includeInstance: boolean, msg: HSBColorSpec): HSBColorSpec.AsObject;
  static serializeBinaryToWriter(message: HSBColorSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HSBColorSpec;
  static deserializeBinaryFromReader(message: HSBColorSpec, reader: jspb.BinaryReader): HSBColorSpec;
}

export namespace HSBColorSpec {
  export type AsObject = {
    h: number,
    s: number,
    b: number,
  }
}

export class CMYKColorSpec extends jspb.Message {
  getC(): number;
  setC(value: number): void;

  getM(): number;
  setM(value: number): void;

  getY(): number;
  setY(value: number): void;

  getK(): number;
  setK(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CMYKColorSpec.AsObject;
  static toObject(includeInstance: boolean, msg: CMYKColorSpec): CMYKColorSpec.AsObject;
  static serializeBinaryToWriter(message: CMYKColorSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CMYKColorSpec;
  static deserializeBinaryFromReader(message: CMYKColorSpec, reader: jspb.BinaryReader): CMYKColorSpec;
}

export namespace CMYKColorSpec {
  export type AsObject = {
    c: number,
    m: number,
    y: number,
    k: number,
  }
}

export class Color extends jspb.Message {
  getStandard(): StandardColor;
  setStandard(value: StandardColor): void;
  hasStandard(): boolean;

  getHex(): string;
  setHex(value: string): void;
  hasHex(): boolean;

  getRgba(): RGBAColorSpec | undefined;
  setRgba(value?: RGBAColorSpec): void;
  hasRgba(): boolean;
  clearRgba(): void;
  hasRgba(): boolean;

  getHsb(): HSBColorSpec | undefined;
  setHsb(value?: HSBColorSpec): void;
  hasHsb(): boolean;
  clearHsb(): void;
  hasHsb(): boolean;

  getCmyk(): CMYKColorSpec | undefined;
  setCmyk(value?: CMYKColorSpec): void;
  hasCmyk(): boolean;
  clearCmyk(): void;
  hasCmyk(): boolean;

  getSpecCase(): Color.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Color.AsObject;
  static toObject(includeInstance: boolean, msg: Color): Color.AsObject;
  static serializeBinaryToWriter(message: Color, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Color;
  static deserializeBinaryFromReader(message: Color, reader: jspb.BinaryReader): Color;
}

export namespace Color {
  export type AsObject = {
    standard: StandardColor,
    hex: string,
    rgba?: RGBAColorSpec.AsObject,
    hsb?: HSBColorSpec.AsObject,
    cmyk?: CMYKColorSpec.AsObject,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    STANDARD = 1,
    HEX = 2,
    RGBA = 3,
    HSB = 4,
    CMYK = 5,
  }
}

export class ColorScheme extends jspb.Message {
  getPrimary(): Color | undefined;
  setPrimary(value?: Color): void;
  hasPrimary(): boolean;
  clearPrimary(): void;

  getSecondary(): Color | undefined;
  setSecondary(value?: Color): void;
  hasSecondary(): boolean;
  clearSecondary(): void;

  getAlert(): Color | undefined;
  setAlert(value?: Color): void;
  hasAlert(): boolean;
  clearAlert(): void;

  getShadesList(): Array<Color>;
  setShadesList(value: Array<Color>): void;
  clearShadesList(): void;
  addShades(value?: Color, index?: number): Color;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ColorScheme.AsObject;
  static toObject(includeInstance: boolean, msg: ColorScheme): ColorScheme.AsObject;
  static serializeBinaryToWriter(message: ColorScheme, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ColorScheme;
  static deserializeBinaryFromReader(message: ColorScheme, reader: jspb.BinaryReader): ColorScheme;
}

export namespace ColorScheme {
  export type AsObject = {
    primary?: Color.AsObject,
    secondary?: Color.AsObject,
    alert?: Color.AsObject,
    shadesList: Array<Color.AsObject>,
  }
}

export enum StandardColor { 
  UNSPECIFIED_COLOR = 0,
  RED = 1,
  GREEN = 2,
  BLUE = 3,
  YELLOW = 4,
  PURPLE = 5,
  ORANGE = 6,
  PINK = 7,
  GRAY = 8,
  BROWN = 9,
}
