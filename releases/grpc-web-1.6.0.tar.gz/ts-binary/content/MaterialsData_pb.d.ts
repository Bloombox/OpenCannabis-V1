import * as jspb from "google-protobuf"

import * as structs_Grow_pb from '../structs/Grow_pb';
import * as structs_Shelf_pb from '../structs/Shelf_pb';
import * as structs_Species_pb from '../structs/Species_pb';
import * as structs_Genetics_pb from '../structs/Genetics_pb';
import * as products_distribution_DistributionChannel_pb from '../products/distribution/DistributionChannel_pb';

export class MaterialsData extends jspb.Message {
  getSpecies(): structs_Species_pb.Species;
  setSpecies(value: structs_Species_pb.Species): void;

  getGenetics(): structs_Genetics_pb.Genetics | undefined;
  setGenetics(value?: structs_Genetics_pb.Genetics): void;
  hasGenetics(): boolean;
  clearGenetics(): void;

  getGrow(): structs_Grow_pb.Grow;
  setGrow(value: structs_Grow_pb.Grow): void;

  getShelf(): structs_Shelf_pb.Shelf;
  setShelf(value: structs_Shelf_pb.Shelf): void;

  getChannelList(): Array<products_distribution_DistributionChannel_pb.DistributionPolicy>;
  setChannelList(value: Array<products_distribution_DistributionChannel_pb.DistributionPolicy>): void;
  clearChannelList(): void;
  addChannel(value?: products_distribution_DistributionChannel_pb.DistributionPolicy, index?: number): products_distribution_DistributionChannel_pb.DistributionPolicy;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MaterialsData.AsObject;
  static toObject(includeInstance: boolean, msg: MaterialsData): MaterialsData.AsObject;
  static serializeBinaryToWriter(message: MaterialsData, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MaterialsData;
  static deserializeBinaryFromReader(message: MaterialsData, reader: jspb.BinaryReader): MaterialsData;
}

export namespace MaterialsData {
  export type AsObject = {
    species: structs_Species_pb.Species,
    genetics?: structs_Genetics_pb.Genetics.AsObject,
    grow: structs_Grow_pb.Grow,
    shelf: structs_Shelf_pb.Shelf,
    channelList: Array<products_distribution_DistributionChannel_pb.DistributionPolicy.AsObject>,
  }
}

