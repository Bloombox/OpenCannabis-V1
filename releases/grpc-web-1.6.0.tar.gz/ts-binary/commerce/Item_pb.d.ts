import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as structs_pricing_PricingDescriptor_pb from '../structs/pricing/PricingDescriptor_pb';

export class VariantSpec extends jspb.Message {
  getVariant(): ProductVariant;
  setVariant(value: ProductVariant): void;

  getWeight(): structs_pricing_PricingDescriptor_pb.PricingWeightTier;
  setWeight(value: structs_pricing_PricingDescriptor_pb.PricingWeightTier): void;
  hasWeight(): boolean;

  getSize(): string;
  setSize(value: string): void;
  hasSize(): boolean;

  getColor(): string;
  setColor(value: string): void;
  hasColor(): boolean;

  getSpecCase(): VariantSpec.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VariantSpec.AsObject;
  static toObject(includeInstance: boolean, msg: VariantSpec): VariantSpec.AsObject;
  static serializeBinaryToWriter(message: VariantSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VariantSpec;
  static deserializeBinaryFromReader(message: VariantSpec, reader: jspb.BinaryReader): VariantSpec;
}

export namespace VariantSpec {
  export type AsObject = {
    variant: ProductVariant,
    weight: structs_pricing_PricingDescriptor_pb.PricingWeightTier,
    size: string,
    color: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    WEIGHT = 2,
    SIZE = 3,
    COLOR = 4,
  }
}

export class Item extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getVariantList(): Array<VariantSpec>;
  setVariantList(value: Array<VariantSpec>): void;
  clearVariantList(): void;
  addVariant(value?: VariantSpec, index?: number): VariantSpec;

  getCount(): number;
  setCount(value: number): void;

  getUri(): string;
  setUri(value: string): void;

  getImageUri(): string;
  setImageUri(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Item.AsObject;
  static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
  static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Item;
  static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
}

export namespace Item {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    variantList: Array<VariantSpec.AsObject>,
    count: number,
    uri: string,
    imageUri: string,
  }
}

export enum ProductVariant { 
  WEIGHT = 0,
  COLOR = 1,
  SIZE = 2,
}
