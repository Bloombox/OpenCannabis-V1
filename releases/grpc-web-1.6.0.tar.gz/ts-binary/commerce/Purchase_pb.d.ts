import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as accounting_Taxes_pb from '../accounting/Taxes_pb';
import * as commerce_Item_pb from '../commerce/Item_pb';
import * as commerce_Currency_pb from '../commerce/Currency_pb';
import * as commerce_Discounts_pb from '../commerce/Discounts_pb';
import * as commerce_payments_Payment_pb from '../commerce/payments/Payment_pb';
import * as inventory_InventoryProduct_pb from '../inventory/InventoryProduct_pb';
import * as crypto_Signature_pb from '../crypto/Signature_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';

export class PurchaseLogEntry extends jspb.Message {
  getStatus(): PurchaseStatus;
  setStatus(value: PurchaseStatus): void;

  getEvent(): PurchaseEvent;
  setEvent(value: PurchaseEvent): void;

  getInstant(): temporal_Instant_pb.Instant | undefined;
  setInstant(value?: temporal_Instant_pb.Instant): void;
  hasInstant(): boolean;
  clearInstant(): void;

  getSku(): string;
  setSku(value: string): void;

  getMessage(): string;
  setMessage(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseLogEntry.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseLogEntry): PurchaseLogEntry.AsObject;
  static serializeBinaryToWriter(message: PurchaseLogEntry, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseLogEntry;
  static deserializeBinaryFromReader(message: PurchaseLogEntry, reader: jspb.BinaryReader): PurchaseLogEntry;
}

export namespace PurchaseLogEntry {
  export type AsObject = {
    status: PurchaseStatus,
    event: PurchaseEvent,
    instant?: temporal_Instant_pb.Instant.AsObject,
    sku: string,
    message: string,
  }
}

export class BillOfCharges extends jspb.Message {
  getStatus(): commerce_payments_Payment_pb.BillStatus;
  setStatus(value: commerce_payments_Payment_pb.BillStatus): void;

  getTaxList(): Array<accounting_Taxes_pb.Tax>;
  setTaxList(value: Array<accounting_Taxes_pb.Tax>): void;
  clearTaxList(): void;
  addTax(value?: accounting_Taxes_pb.Tax, index?: number): accounting_Taxes_pb.Tax;

  getDiscountList(): Array<commerce_Discounts_pb.Discount>;
  setDiscountList(value: Array<commerce_Discounts_pb.Discount>): void;
  clearDiscountList(): void;
  addDiscount(value?: commerce_Discounts_pb.Discount, index?: number): commerce_Discounts_pb.Discount;

  getPrice(): number;
  setPrice(value: number): void;

  getTaxes(): number;
  setTaxes(value: number): void;

  getDiscounts(): number;
  setDiscounts(value: number): void;

  getSubtotal(): number;
  setSubtotal(value: number): void;

  getTotal(): number;
  setTotal(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BillOfCharges.AsObject;
  static toObject(includeInstance: boolean, msg: BillOfCharges): BillOfCharges.AsObject;
  static serializeBinaryToWriter(message: BillOfCharges, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BillOfCharges;
  static deserializeBinaryFromReader(message: BillOfCharges, reader: jspb.BinaryReader): BillOfCharges;
}

export namespace BillOfCharges {
  export type AsObject = {
    status: commerce_payments_Payment_pb.BillStatus,
    taxList: Array<accounting_Taxes_pb.Tax.AsObject>,
    discountList: Array<commerce_Discounts_pb.Discount.AsObject>,
    price: number,
    taxes: number,
    discounts: number,
    subtotal: number,
    total: number,
  }
}

export class TicketItem extends jspb.Message {
  getKey(): inventory_InventoryProduct_pb.InventoryKey | undefined;
  setKey(value?: inventory_InventoryProduct_pb.InventoryKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getSku(): string;
  setSku(value: string): void;

  getItem(): commerce_Item_pb.Item | undefined;
  setItem(value?: commerce_Item_pb.Item): void;
  hasItem(): boolean;
  clearItem(): void;

  getLine(): BillOfCharges | undefined;
  setLine(value?: BillOfCharges): void;
  hasLine(): boolean;
  clearLine(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TicketItem.AsObject;
  static toObject(includeInstance: boolean, msg: TicketItem): TicketItem.AsObject;
  static serializeBinaryToWriter(message: TicketItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TicketItem;
  static deserializeBinaryFromReader(message: TicketItem, reader: jspb.BinaryReader): TicketItem;
}

export namespace TicketItem {
  export type AsObject = {
    key?: inventory_InventoryProduct_pb.InventoryKey.AsObject,
    sku: string,
    item?: commerce_Item_pb.Item.AsObject,
    line?: BillOfCharges.AsObject,
  }
}

export class PurchaseTimestamps extends jspb.Message {
  getEstablished(): temporal_Instant_pb.Instant | undefined;
  setEstablished(value?: temporal_Instant_pb.Instant): void;
  hasEstablished(): boolean;
  clearEstablished(): void;

  getCreated(): temporal_Instant_pb.Instant | undefined;
  setCreated(value?: temporal_Instant_pb.Instant): void;
  hasCreated(): boolean;
  clearCreated(): void;

  getModified(): temporal_Instant_pb.Instant | undefined;
  setModified(value?: temporal_Instant_pb.Instant): void;
  hasModified(): boolean;
  clearModified(): void;

  getExecuted(): temporal_Instant_pb.Instant | undefined;
  setExecuted(value?: temporal_Instant_pb.Instant): void;
  hasExecuted(): boolean;
  clearExecuted(): void;

  getFinalized(): temporal_Instant_pb.Instant | undefined;
  setFinalized(value?: temporal_Instant_pb.Instant): void;
  hasFinalized(): boolean;
  clearFinalized(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseTimestamps.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseTimestamps): PurchaseTimestamps.AsObject;
  static serializeBinaryToWriter(message: PurchaseTimestamps, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseTimestamps;
  static deserializeBinaryFromReader(message: PurchaseTimestamps, reader: jspb.BinaryReader): PurchaseTimestamps;
}

export namespace PurchaseTimestamps {
  export type AsObject = {
    established?: temporal_Instant_pb.Instant.AsObject,
    created?: temporal_Instant_pb.Instant.AsObject,
    modified?: temporal_Instant_pb.Instant.AsObject,
    executed?: temporal_Instant_pb.Instant.AsObject,
    finalized?: temporal_Instant_pb.Instant.AsObject,
  }
}

export class PurchaseKey extends jspb.Message {
  getUuid(): string;
  setUuid(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseKey.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseKey): PurchaseKey.AsObject;
  static serializeBinaryToWriter(message: PurchaseKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseKey;
  static deserializeBinaryFromReader(message: PurchaseKey, reader: jspb.BinaryReader): PurchaseKey;
}

export namespace PurchaseKey {
  export type AsObject = {
    uuid: string,
  }
}

export class PurchaseSignature extends jspb.Message {
  getNonce(): string;
  setNonce(value: string): void;

  getFacilitator(): crypto_Signature_pb.Signature | undefined;
  setFacilitator(value?: crypto_Signature_pb.Signature): void;
  hasFacilitator(): boolean;
  clearFacilitator(): void;

  getCustomer(): crypto_Signature_pb.Signature | undefined;
  setCustomer(value?: crypto_Signature_pb.Signature): void;
  hasCustomer(): boolean;
  clearCustomer(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseSignature.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseSignature): PurchaseSignature.AsObject;
  static serializeBinaryToWriter(message: PurchaseSignature, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseSignature;
  static deserializeBinaryFromReader(message: PurchaseSignature, reader: jspb.BinaryReader): PurchaseSignature;
}

export namespace PurchaseSignature {
  export type AsObject = {
    nonce: string,
    facilitator?: crypto_Signature_pb.Signature.AsObject,
    customer?: crypto_Signature_pb.Signature.AsObject,
  }
}

export class PurchaseCustomer extends jspb.Message {
  getUniqueId(): string;
  setUniqueId(value: string): void;

  getSignature(): PurchaseSignature | undefined;
  setSignature(value?: PurchaseSignature): void;
  hasSignature(): boolean;
  clearSignature(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseCustomer.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseCustomer): PurchaseCustomer.AsObject;
  static serializeBinaryToWriter(message: PurchaseCustomer, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseCustomer;
  static deserializeBinaryFromReader(message: PurchaseCustomer, reader: jspb.BinaryReader): PurchaseCustomer;
}

export namespace PurchaseCustomer {
  export type AsObject = {
    uniqueId: string,
    signature?: PurchaseSignature.AsObject,
  }
}

export class PurchaseFacilitator extends jspb.Message {
  getAuthority(): PurchaseAuthority;
  setAuthority(value: PurchaseAuthority): void;

  getAgent(): string;
  setAgent(value: string): void;

  getDevice(): string;
  setDevice(value: string): void;

  getSignature(): PurchaseSignature | undefined;
  setSignature(value?: PurchaseSignature): void;
  hasSignature(): boolean;
  clearSignature(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PurchaseFacilitator.AsObject;
  static toObject(includeInstance: boolean, msg: PurchaseFacilitator): PurchaseFacilitator.AsObject;
  static serializeBinaryToWriter(message: PurchaseFacilitator, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PurchaseFacilitator;
  static deserializeBinaryFromReader(message: PurchaseFacilitator, reader: jspb.BinaryReader): PurchaseFacilitator;
}

export namespace PurchaseFacilitator {
  export type AsObject = {
    authority: PurchaseAuthority,
    agent: string,
    device: string,
    signature?: PurchaseSignature.AsObject,
  }
}

export class PaymentKey extends jspb.Message {
  getUuid(): string;
  setUuid(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PaymentKey.AsObject;
  static toObject(includeInstance: boolean, msg: PaymentKey): PaymentKey.AsObject;
  static serializeBinaryToWriter(message: PaymentKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PaymentKey;
  static deserializeBinaryFromReader(message: PaymentKey, reader: jspb.BinaryReader): PaymentKey;
}

export namespace PaymentKey {
  export type AsObject = {
    uuid: string,
  }
}

export class Payment extends jspb.Message {
  getKey(): PaymentKey | undefined;
  setKey(value?: PaymentKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getMethod(): commerce_payments_Payment_pb.PaymentMethod;
  setMethod(value: commerce_payments_Payment_pb.PaymentMethod): void;

  getStatus(): commerce_payments_Payment_pb.PaymentStatus;
  setStatus(value: commerce_payments_Payment_pb.PaymentStatus): void;

  getAmount(): number;
  setAmount(value: number): void;

  getFull(): boolean;
  setFull(value: boolean): void;

  getCash(): Payment.CashPayment | undefined;
  setCash(value?: Payment.CashPayment): void;
  hasCash(): boolean;
  clearCash(): void;
  hasCash(): boolean;

  getCheck(): Payment.CheckPayment | undefined;
  setCheck(value?: Payment.CheckPayment): void;
  hasCheck(): boolean;
  clearCheck(): void;
  hasCheck(): boolean;

  getCard(): Payment.CardPayment | undefined;
  setCard(value?: Payment.CardPayment): void;
  hasCard(): boolean;
  clearCard(): void;
  hasCard(): boolean;

  getBank(): Payment.BankPayment | undefined;
  setBank(value?: Payment.BankPayment): void;
  hasBank(): boolean;
  clearBank(): void;
  hasBank(): boolean;

  getDigital(): Payment.DigitalPayment | undefined;
  setDigital(value?: Payment.DigitalPayment): void;
  hasDigital(): boolean;
  clearDigital(): void;
  hasDigital(): boolean;

  getSpecCase(): Payment.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Payment.AsObject;
  static toObject(includeInstance: boolean, msg: Payment): Payment.AsObject;
  static serializeBinaryToWriter(message: Payment, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Payment;
  static deserializeBinaryFromReader(message: Payment, reader: jspb.BinaryReader): Payment;
}

export namespace Payment {
  export type AsObject = {
    key?: PaymentKey.AsObject,
    method: commerce_payments_Payment_pb.PaymentMethod,
    status: commerce_payments_Payment_pb.PaymentStatus,
    amount: number,
    full: boolean,
    cash?: Payment.CashPayment.AsObject,
    check?: Payment.CheckPayment.AsObject,
    card?: Payment.CardPayment.AsObject,
    bank?: Payment.BankPayment.AsObject,
    digital?: Payment.DigitalPayment.AsObject,
  }

  export class CashPayment extends jspb.Message {
    getTendered(): commerce_Currency_pb.CurrencyValue | undefined;
    setTendered(value?: commerce_Currency_pb.CurrencyValue): void;
    hasTendered(): boolean;
    clearTendered(): void;

    getChange(): commerce_Currency_pb.CurrencyValue | undefined;
    setChange(value?: commerce_Currency_pb.CurrencyValue): void;
    hasChange(): boolean;
    clearChange(): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CashPayment.AsObject;
    static toObject(includeInstance: boolean, msg: CashPayment): CashPayment.AsObject;
    static serializeBinaryToWriter(message: CashPayment, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CashPayment;
    static deserializeBinaryFromReader(message: CashPayment, reader: jspb.BinaryReader): CashPayment;
  }

  export namespace CashPayment {
    export type AsObject = {
      tendered?: commerce_Currency_pb.CurrencyValue.AsObject,
      change?: commerce_Currency_pb.CurrencyValue.AsObject,
    }
  }


  export class CheckPayment extends jspb.Message {
    getCheckNumber(): string;
    setCheckNumber(value: string): void;

    getRoutingNumber(): string;
    setRoutingNumber(value: string): void;

    getAccountNumber(): string;
    setAccountNumber(value: string): void;

    getInstitution(): string;
    setInstitution(value: string): void;

    getCertified(): boolean;
    setCertified(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CheckPayment.AsObject;
    static toObject(includeInstance: boolean, msg: CheckPayment): CheckPayment.AsObject;
    static serializeBinaryToWriter(message: CheckPayment, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CheckPayment;
    static deserializeBinaryFromReader(message: CheckPayment, reader: jspb.BinaryReader): CheckPayment;
  }

  export namespace CheckPayment {
    export type AsObject = {
      checkNumber: string,
      routingNumber: string,
      accountNumber: string,
      institution: string,
      certified: boolean,
    }
  }


  export class CardPayment extends jspb.Message {
    getCardType(): commerce_payments_Payment_pb.PaymentCardType;
    setCardType(value: commerce_payments_Payment_pb.PaymentCardType): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CardPayment.AsObject;
    static toObject(includeInstance: boolean, msg: CardPayment): CardPayment.AsObject;
    static serializeBinaryToWriter(message: CardPayment, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CardPayment;
    static deserializeBinaryFromReader(message: CardPayment, reader: jspb.BinaryReader): CardPayment;
  }

  export namespace CardPayment {
    export type AsObject = {
      cardType: commerce_payments_Payment_pb.PaymentCardType,
    }
  }


  export class BankPayment extends jspb.Message {
    getRoutingNumber(): string;
    setRoutingNumber(value: string): void;

    getAccountNumber(): string;
    setAccountNumber(value: string): void;

    getReference(): string;
    setReference(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): BankPayment.AsObject;
    static toObject(includeInstance: boolean, msg: BankPayment): BankPayment.AsObject;
    static serializeBinaryToWriter(message: BankPayment, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): BankPayment;
    static deserializeBinaryFromReader(message: BankPayment, reader: jspb.BinaryReader): BankPayment;
  }

  export namespace BankPayment {
    export type AsObject = {
      routingNumber: string,
      accountNumber: string,
      reference: string,
    }
  }


  export class DigitalPayment extends jspb.Message {
    getNetwork(): commerce_payments_Payment_pb.DigitalPaymentNetwork;
    setNetwork(value: commerce_payments_Payment_pb.DigitalPaymentNetwork): void;

    getUsername(): string;
    setUsername(value: string): void;

    getReference(): string;
    setReference(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DigitalPayment.AsObject;
    static toObject(includeInstance: boolean, msg: DigitalPayment): DigitalPayment.AsObject;
    static serializeBinaryToWriter(message: DigitalPayment, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DigitalPayment;
    static deserializeBinaryFromReader(message: DigitalPayment, reader: jspb.BinaryReader): DigitalPayment;
  }

  export namespace DigitalPayment {
    export type AsObject = {
      network: commerce_payments_Payment_pb.DigitalPaymentNetwork,
      username: string,
      reference: string,
    }
  }


  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    CASH = 10,
    CHECK = 11,
    CARD = 12,
    BANK = 13,
    DIGITAL = 14,
  }
}

export enum PurchaseStatus { 
  FRESH = 0,
  OPEN = 1,
  CLOSED = 2,
  VOIDED = 3,
  FINALIZED = 4,
  RECONCILED = 5,
}
export enum PurchaseAuthority { 
  STANDARD = 0,
  MEDICAL = 1,
  ADULT_USE = 2,
}
export enum PurchaseEvent { 
  STATUS = 0,
  SAVE = 1,
  LOAD = 2,
  ITEM_ADDED = 10,
  ITEM_REMOVED = 11,
  ITEM_QUANTITY_CHANGED = 12,
  ITEM_DISCOUNT_ADDED = 13,
  ITEM_DISCOUNT_REMOVED = 14,
  PURCHASE_VOID = 20,
  PURCHASE_FINALIZE = 21,
}
