import * as jspb from "google-protobuf"

import * as temporal_Instant_pb from '../temporal/Instant_pb';

export class DiscountSpec extends jspb.Message {
  getType(): DiscountType;
  setType(value: DiscountType): void;

  getBasis(): DiscountBasis;
  setBasis(value: DiscountBasis): void;

  getPercentage(): number;
  setPercentage(value: number): void;
  hasPercentage(): boolean;

  getStaticValue(): number;
  setStaticValue(value: number): void;
  hasStaticValue(): boolean;

  getRateCase(): DiscountSpec.RateCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DiscountSpec.AsObject;
  static toObject(includeInstance: boolean, msg: DiscountSpec): DiscountSpec.AsObject;
  static serializeBinaryToWriter(message: DiscountSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DiscountSpec;
  static deserializeBinaryFromReader(message: DiscountSpec, reader: jspb.BinaryReader): DiscountSpec;
}

export namespace DiscountSpec {
  export type AsObject = {
    type: DiscountType,
    basis: DiscountBasis,
    percentage: number,
    staticValue: number,
  }

  export enum RateCase { 
    RATE_NOT_SET = 0,
    PERCENTAGE = 3,
    STATIC_VALUE = 4,
  }
}

export class Discount extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getSpec(): DiscountSpec | undefined;
  setSpec(value?: DiscountSpec): void;
  hasSpec(): boolean;
  clearSpec(): void;

  getName(): string;
  setName(value: string): void;

  getLabel(): string;
  setLabel(value: string): void;

  getDescription(): string;
  setDescription(value: string): void;

  getModifiedAt(): temporal_Instant_pb.Instant | undefined;
  setModifiedAt(value?: temporal_Instant_pb.Instant): void;
  hasModifiedAt(): boolean;
  clearModifiedAt(): void;

  getCreatedAt(): temporal_Instant_pb.Instant | undefined;
  setCreatedAt(value?: temporal_Instant_pb.Instant): void;
  hasCreatedAt(): boolean;
  clearCreatedAt(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Discount.AsObject;
  static toObject(includeInstance: boolean, msg: Discount): Discount.AsObject;
  static serializeBinaryToWriter(message: Discount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Discount;
  static deserializeBinaryFromReader(message: Discount, reader: jspb.BinaryReader): Discount;
}

export namespace Discount {
  export type AsObject = {
    id: string,
    spec?: DiscountSpec.AsObject,
    name: string,
    label: string,
    description: string,
    modifiedAt?: temporal_Instant_pb.Instant.AsObject,
    createdAt?: temporal_Instant_pb.Instant.AsObject,
  }
}

export enum DiscountType { 
  CUSTOM = 0,
  STATUTORY = 1,
  COMMERCIAL = 2,
}
export enum DiscountBasis { 
  ITEM = 0,
  ORDER_SUBTOTAL = 1,
  ORDER_TOTAL = 2,
}
