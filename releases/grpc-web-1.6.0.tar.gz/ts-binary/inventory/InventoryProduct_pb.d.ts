import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';
import * as commerce_Item_pb from '../commerce/Item_pb';
import * as products_menu_Menu_pb from '../products/menu/Menu_pb';
import * as structs_pricing_PricingDescriptor_pb from '../structs/pricing/PricingDescriptor_pb';

export class InventoryKey extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getUuid(): string;
  setUuid(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryKey.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryKey): InventoryKey.AsObject;
  static serializeBinaryToWriter(message: InventoryKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryKey;
  static deserializeBinaryFromReader(message: InventoryKey, reader: jspb.BinaryReader): InventoryKey;
}

export namespace InventoryKey {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    uuid: string,
  }
}

export class InventoryCoordinates extends jspb.Message {
  getLocation(): string;
  setLocation(value: string): void;

  getZone(): string;
  setZone(value: string): void;

  getRack(): string;
  setRack(value: string): void;

  getShelf(): string;
  setShelf(value: string): void;

  getBin(): string;
  setBin(value: string): void;

  getBatch(): string;
  setBatch(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryCoordinates.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryCoordinates): InventoryCoordinates.AsObject;
  static serializeBinaryToWriter(message: InventoryCoordinates, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryCoordinates;
  static deserializeBinaryFromReader(message: InventoryCoordinates, reader: jspb.BinaryReader): InventoryCoordinates;
}

export namespace InventoryCoordinates {
  export type AsObject = {
    location: string,
    zone: string,
    rack: string,
    shelf: string,
    bin: string,
    batch: string,
  }
}

export class InventoryAmount extends jspb.Message {
  getType(): structs_pricing_PricingDescriptor_pb.PricingType;
  setType(value: structs_pricing_PricingDescriptor_pb.PricingType): void;

  getUnit(): boolean;
  setUnit(value: boolean): void;
  hasUnit(): boolean;

  getWeight(): structs_pricing_PricingDescriptor_pb.PricingWeightTier;
  setWeight(value: structs_pricing_PricingDescriptor_pb.PricingWeightTier): void;
  hasWeight(): boolean;

  getQuantity(): number;
  setQuantity(value: number): void;

  getBasisCase(): InventoryAmount.BasisCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryAmount.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryAmount): InventoryAmount.AsObject;
  static serializeBinaryToWriter(message: InventoryAmount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryAmount;
  static deserializeBinaryFromReader(message: InventoryAmount, reader: jspb.BinaryReader): InventoryAmount;
}

export namespace InventoryAmount {
  export type AsObject = {
    type: structs_pricing_PricingDescriptor_pb.PricingType,
    unit: boolean,
    weight: structs_pricing_PricingDescriptor_pb.PricingWeightTier,
    quantity: number,
  }

  export enum BasisCase { 
    BASIS_NOT_SET = 0,
    UNIT = 2,
    WEIGHT = 3,
  }
}

export class InventoryState extends jspb.Message {
  getStatus(): InventoryState.Status;
  setStatus(value: InventoryState.Status): void;

  getCoordinates(): InventoryCoordinates | undefined;
  setCoordinates(value?: InventoryCoordinates): void;
  hasCoordinates(): boolean;
  clearCoordinates(): void;

  getFitForSale(): boolean;
  setFitForSale(value: boolean): void;

  getAmount(): InventoryAmount | undefined;
  setAmount(value?: InventoryAmount): void;
  hasAmount(): boolean;
  clearAmount(): void;

  getCreated(): temporal_Instant_pb.Instant | undefined;
  setCreated(value?: temporal_Instant_pb.Instant): void;
  hasCreated(): boolean;
  clearCreated(): void;

  getModified(): temporal_Instant_pb.Instant | undefined;
  setModified(value?: temporal_Instant_pb.Instant): void;
  hasModified(): boolean;
  clearModified(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryState.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryState): InventoryState.AsObject;
  static serializeBinaryToWriter(message: InventoryState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryState;
  static deserializeBinaryFromReader(message: InventoryState, reader: jspb.BinaryReader): InventoryState;
}

export namespace InventoryState {
  export type AsObject = {
    status: InventoryState.Status,
    coordinates?: InventoryCoordinates.AsObject,
    fitForSale: boolean,
    amount?: InventoryAmount.AsObject,
    created?: temporal_Instant_pb.Instant.AsObject,
    modified?: temporal_Instant_pb.Instant.AsObject,
  }

  export enum Status { 
    UNRECONCILED = 0,
    RECEIVING = 1,
    QUARANTINE = 2,
    ON_HAND = 3,
    FOR_SALE = 4,
    CLAIMED = 5,
    COMMITTED = 6,
  }
}

export class InventoryProduct extends jspb.Message {
  getKey(): InventoryKey | undefined;
  setKey(value?: InventoryKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getSkuList(): Array<string>;
  setSkuList(value: Array<string>): void;
  clearSkuList(): void;
  addSku(value: string, index?: number): void;

  getVariantList(): Array<commerce_Item_pb.VariantSpec>;
  setVariantList(value: Array<commerce_Item_pb.VariantSpec>): void;
  clearVariantList(): void;
  addVariant(value?: commerce_Item_pb.VariantSpec, index?: number): commerce_Item_pb.VariantSpec;

  getState(): InventoryState | undefined;
  setState(value?: InventoryState): void;
  hasState(): boolean;
  clearState(): void;

  getHistoryList(): Array<InventoryState>;
  setHistoryList(value: Array<InventoryState>): void;
  clearHistoryList(): void;
  addHistory(value?: InventoryState, index?: number): InventoryState;

  getItem(): products_menu_Menu_pb.MenuProduct | undefined;
  setItem(value?: products_menu_Menu_pb.MenuProduct): void;
  hasItem(): boolean;
  clearItem(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryProduct.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryProduct): InventoryProduct.AsObject;
  static serializeBinaryToWriter(message: InventoryProduct, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryProduct;
  static deserializeBinaryFromReader(message: InventoryProduct, reader: jspb.BinaryReader): InventoryProduct;
}

export namespace InventoryProduct {
  export type AsObject = {
    key?: InventoryKey.AsObject,
    skuList: Array<string>,
    variantList: Array<commerce_Item_pb.VariantSpec.AsObject>,
    state?: InventoryState.AsObject,
    historyList: Array<InventoryState.AsObject>,
    item?: products_menu_Menu_pb.MenuProduct.AsObject,
  }
}

