import * as jspb from "google-protobuf"

import * as bq_field_pb from '../../bq_field_pb';
import * as bq_table_pb from '../../bq_table_pb';
import * as core_Datamodel_pb from '../../core/Datamodel_pb';
import * as temporal_Instant_pb from '../../temporal/Instant_pb';
import * as inventory_rfid_RFID_pb from '../../inventory/rfid/RFID_pb';

export class BoundaryConfig extends jspb.Message {
  getStart(): BoundaryConfig.StartTrigger | undefined;
  setStart(value?: BoundaryConfig.StartTrigger): void;
  hasStart(): boolean;
  clearStart(): void;

  getStop(): BoundaryConfig.StopTrigger | undefined;
  setStop(value?: BoundaryConfig.StopTrigger): void;
  hasStop(): boolean;
  clearStop(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BoundaryConfig.AsObject;
  static toObject(includeInstance: boolean, msg: BoundaryConfig): BoundaryConfig.AsObject;
  static serializeBinaryToWriter(message: BoundaryConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BoundaryConfig;
  static deserializeBinaryFromReader(message: BoundaryConfig, reader: jspb.BinaryReader): BoundaryConfig;
}

export namespace BoundaryConfig {
  export type AsObject = {
    start?: BoundaryConfig.StartTrigger.AsObject,
    stop?: BoundaryConfig.StopTrigger.AsObject,
  }

  export class StartTrigger extends jspb.Message {
    getType(): StartTriggerType;
    setType(value: StartTriggerType): void;

    getSchedule(): number;
    setSchedule(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StartTrigger.AsObject;
    static toObject(includeInstance: boolean, msg: StartTrigger): StartTrigger.AsObject;
    static serializeBinaryToWriter(message: StartTrigger, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StartTrigger;
    static deserializeBinaryFromReader(message: StartTrigger, reader: jspb.BinaryReader): StartTrigger;
  }

  export namespace StartTrigger {
    export type AsObject = {
      type: StartTriggerType,
      schedule: number,
    }
  }


  export class StopTrigger extends jspb.Message {
    getType(): StopTriggerType;
    setType(value: StopTriggerType): void;

    getSchedule(): number;
    setSchedule(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StopTrigger.AsObject;
    static toObject(includeInstance: boolean, msg: StopTrigger): StopTrigger.AsObject;
    static serializeBinaryToWriter(message: StopTrigger, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StopTrigger;
    static deserializeBinaryFromReader(message: StopTrigger, reader: jspb.BinaryReader): StopTrigger;
  }

  export namespace StopTrigger {
    export type AsObject = {
      type: StopTriggerType,
      schedule: number,
    }
  }

}

export class ReportingConfig extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReportingConfig.AsObject;
  static toObject(includeInstance: boolean, msg: ReportingConfig): ReportingConfig.AsObject;
  static serializeBinaryToWriter(message: ReportingConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReportingConfig;
  static deserializeBinaryFromReader(message: ReportingConfig, reader: jspb.BinaryReader): ReportingConfig;
}

export namespace ReportingConfig {
  export type AsObject = {
  }
}

export class ROSpec extends jspb.Message {
  getId(): number;
  setId(value: number): void;

  getPriority(): number;
  setPriority(value: number): void;

  getBoundary(): BoundaryConfig | undefined;
  setBoundary(value?: BoundaryConfig): void;
  hasBoundary(): boolean;
  clearBoundary(): void;

  getReporting(): ReportingConfig | undefined;
  setReporting(value?: ReportingConfig): void;
  hasReporting(): boolean;
  clearReporting(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ROSpec.AsObject;
  static toObject(includeInstance: boolean, msg: ROSpec): ROSpec.AsObject;
  static serializeBinaryToWriter(message: ROSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ROSpec;
  static deserializeBinaryFromReader(message: ROSpec, reader: jspb.BinaryReader): ROSpec;
}

export namespace ROSpec {
  export type AsObject = {
    id: number,
    priority: number,
    boundary?: BoundaryConfig.AsObject,
    reporting?: ReportingConfig.AsObject,
  }
}

export class TagReportOrigin extends jspb.Message {
  getReader(): inventory_rfid_RFID_pb.Reader | undefined;
  setReader(value?: inventory_rfid_RFID_pb.Reader): void;
  hasReader(): boolean;
  clearReader(): void;

  getPartner(): string;
  setPartner(value: string): void;

  getLocation(): string;
  setLocation(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TagReportOrigin.AsObject;
  static toObject(includeInstance: boolean, msg: TagReportOrigin): TagReportOrigin.AsObject;
  static serializeBinaryToWriter(message: TagReportOrigin, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TagReportOrigin;
  static deserializeBinaryFromReader(message: TagReportOrigin, reader: jspb.BinaryReader): TagReportOrigin;
}

export namespace TagReportOrigin {
  export type AsObject = {
    reader?: inventory_rfid_RFID_pb.Reader.AsObject,
    partner: string,
    location: string,
  }
}

export class TagReport extends jspb.Message {
  getAntenna(): inventory_rfid_RFID_pb.Antenna | undefined;
  setAntenna(value?: inventory_rfid_RFID_pb.Antenna): void;
  hasAntenna(): boolean;
  clearAntenna(): void;

  getTag(): inventory_rfid_RFID_pb.Tag | undefined;
  setTag(value?: inventory_rfid_RFID_pb.Tag): void;
  hasTag(): boolean;
  clearTag(): void;

  getRssi(): number;
  setRssi(value: number): void;

  getFirstSeen(): temporal_Instant_pb.Instant | undefined;
  setFirstSeen(value?: temporal_Instant_pb.Instant): void;
  hasFirstSeen(): boolean;
  clearFirstSeen(): void;

  getLastSeen(): temporal_Instant_pb.Instant | undefined;
  setLastSeen(value?: temporal_Instant_pb.Instant): void;
  hasLastSeen(): boolean;
  clearLastSeen(): void;

  getReceived(): temporal_Instant_pb.Instant | undefined;
  setReceived(value?: temporal_Instant_pb.Instant): void;
  hasReceived(): boolean;
  clearReceived(): void;

  getPeers(): number;
  setPeers(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TagReport.AsObject;
  static toObject(includeInstance: boolean, msg: TagReport): TagReport.AsObject;
  static serializeBinaryToWriter(message: TagReport, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TagReport;
  static deserializeBinaryFromReader(message: TagReport, reader: jspb.BinaryReader): TagReport;
}

export namespace TagReport {
  export type AsObject = {
    antenna?: inventory_rfid_RFID_pb.Antenna.AsObject,
    tag?: inventory_rfid_RFID_pb.Tag.AsObject,
    rssi: number,
    firstSeen?: temporal_Instant_pb.Instant.AsObject,
    lastSeen?: temporal_Instant_pb.Instant.AsObject,
    received?: temporal_Instant_pb.Instant.AsObject,
    peers: number,
  }
}

export class TagReportSet extends jspb.Message {
  getOrigin(): TagReportOrigin | undefined;
  setOrigin(value?: TagReportOrigin): void;
  hasOrigin(): boolean;
  clearOrigin(): void;

  getReportList(): Array<TagReport>;
  setReportList(value: Array<TagReport>): void;
  clearReportList(): void;
  addReport(value?: TagReport, index?: number): TagReport;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TagReportSet.AsObject;
  static toObject(includeInstance: boolean, msg: TagReportSet): TagReportSet.AsObject;
  static serializeBinaryToWriter(message: TagReportSet, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TagReportSet;
  static deserializeBinaryFromReader(message: TagReportSet, reader: jspb.BinaryReader): TagReportSet;
}

export namespace TagReportSet {
  export type AsObject = {
    origin?: TagReportOrigin.AsObject,
    reportList: Array<TagReport.AsObject>,
  }
}

export enum RegulatoryCapability { 
  UNSPECIFIED_REGULATORY_REGION = 0,
  US_FCC = 1,
  ETSI_302_208 = 2,
  ETSI_300_220 = 3,
  AUSTRALIA_LIPD_1W = 4,
  AUSTRALIA_LIPD_4W = 5,
  JAPAN_ARIB_STD_T89 = 6,
  HONGKONG_OFTA_1049 = 7,
  TAIWAN_DGT_LP0002 = 8,
  KOREA_MIC_ARTICLE_5_2 = 9,
}
export enum StartTriggerType { 
  NO_START_TRIGGER = 0,
  IMMEDIATE = 1,
  PERIODIC = 2,
  GPIO_START = 3,
}
export enum StopTriggerType { 
  NO_STOP_TRIGGER = 0,
  DURATION = 1,
  GPIO_STOP = 2,
}
