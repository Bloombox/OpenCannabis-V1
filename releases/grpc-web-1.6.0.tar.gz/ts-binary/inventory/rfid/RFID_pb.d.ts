import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../../core/Datamodel_pb';
import * as bq_field_pb from '../../bq_field_pb';
import * as bq_table_pb from '../../bq_table_pb';

export class Reader extends jspb.Message {
  getName(): string;
  setName(value: string): void;

  getMac(): string;
  setMac(value: string): void;

  getIp(): string;
  setIp(value: string): void;

  getVendor(): ReaderVendor;
  setVendor(value: ReaderVendor): void;

  getModel(): ReaderModel;
  setModel(value: ReaderModel): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Reader.AsObject;
  static toObject(includeInstance: boolean, msg: Reader): Reader.AsObject;
  static serializeBinaryToWriter(message: Reader, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Reader;
  static deserializeBinaryFromReader(message: Reader, reader: jspb.BinaryReader): Reader;
}

export namespace Reader {
  export type AsObject = {
    name: string,
    mac: string,
    ip: string,
    vendor: ReaderVendor,
    model: ReaderModel,
  }
}

export class Antenna extends jspb.Message {
  getIndex(): number;
  setIndex(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Antenna.AsObject;
  static toObject(includeInstance: boolean, msg: Antenna): Antenna.AsObject;
  static serializeBinaryToWriter(message: Antenna, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Antenna;
  static deserializeBinaryFromReader(message: Antenna, reader: jspb.BinaryReader): Antenna;
}

export namespace Antenna {
  export type AsObject = {
    index: number,
  }
}

export class Tag extends jspb.Message {
  getTid(): string;
  setTid(value: string): void;

  getPayload(): Uint8Array | string;
  getPayload_asU8(): Uint8Array;
  getPayload_asB64(): string;
  setPayload(value: Uint8Array | string): void;

  getEpc(): string;
  setEpc(value: string): void;
  hasEpc(): boolean;

  getContentCase(): Tag.ContentCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Tag.AsObject;
  static toObject(includeInstance: boolean, msg: Tag): Tag.AsObject;
  static serializeBinaryToWriter(message: Tag, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Tag;
  static deserializeBinaryFromReader(message: Tag, reader: jspb.BinaryReader): Tag;
}

export namespace Tag {
  export type AsObject = {
    tid: string,
    payload: Uint8Array | string,
    epc: string,
  }

  export enum ContentCase { 
    CONTENT_NOT_SET = 0,
    EPC = 10,
  }
}

export enum ReaderVendor { 
  UNRECOGNIZED_VENDOR = 0,
  IMPINJ = 25882,
  ALIEN = 2,
}
export enum ReaderModel { 
  UNRECOGNIZED_READER = 0,
  SPEEDWAY_R120 = 1,
  SPEEDWAY_R220 = 2,
  SPEEDWAY_R420 = 2001002,
  SPEEDWAY_XPORTAL = 4,
  ALIEN_ALRH450 = 5,
  ALIEN_F800 = 6,
  ALIEN_ALR9680 = 7,
}
