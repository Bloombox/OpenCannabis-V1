import * as jspb from "google-protobuf"

import * as commerce_Currency_pb from '../../commerce/Currency_pb';
import * as structs_pricing_SaleDescriptor_pb from '../../structs/pricing/SaleDescriptor_pb';

export class PricingTierAvailability extends jspb.Message {
  getOffered(): boolean;
  setOffered(value: boolean): void;

  getAvailable(): boolean;
  setAvailable(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PricingTierAvailability.AsObject;
  static toObject(includeInstance: boolean, msg: PricingTierAvailability): PricingTierAvailability.AsObject;
  static serializeBinaryToWriter(message: PricingTierAvailability, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PricingTierAvailability;
  static deserializeBinaryFromReader(message: PricingTierAvailability, reader: jspb.BinaryReader): PricingTierAvailability;
}

export namespace PricingTierAvailability {
  export type AsObject = {
    offered: boolean,
    available: boolean,
  }
}

export class UnitPricingDescriptor extends jspb.Message {
  getPrice(): commerce_Currency_pb.CurrencyValue | undefined;
  setPrice(value?: commerce_Currency_pb.CurrencyValue): void;
  hasPrice(): boolean;
  clearPrice(): void;

  getStatus(): PricingTierAvailability | undefined;
  setStatus(value?: PricingTierAvailability): void;
  hasStatus(): boolean;
  clearStatus(): void;

  getDiscountsList(): Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor>;
  setDiscountsList(value: Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor>): void;
  clearDiscountsList(): void;
  addDiscounts(value?: structs_pricing_SaleDescriptor_pb.SaleDescriptor, index?: number): structs_pricing_SaleDescriptor_pb.SaleDescriptor;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UnitPricingDescriptor.AsObject;
  static toObject(includeInstance: boolean, msg: UnitPricingDescriptor): UnitPricingDescriptor.AsObject;
  static serializeBinaryToWriter(message: UnitPricingDescriptor, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UnitPricingDescriptor;
  static deserializeBinaryFromReader(message: UnitPricingDescriptor, reader: jspb.BinaryReader): UnitPricingDescriptor;
}

export namespace UnitPricingDescriptor {
  export type AsObject = {
    price?: commerce_Currency_pb.CurrencyValue.AsObject,
    status?: PricingTierAvailability.AsObject,
    discountsList: Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor.AsObject>,
  }
}

export class WeightedPricingDescriptor extends jspb.Message {
  getWeight(): PricingWeightTier;
  setWeight(value: PricingWeightTier): void;

  getTier(): UnitPricingDescriptor | undefined;
  setTier(value?: UnitPricingDescriptor): void;
  hasTier(): boolean;
  clearTier(): void;

  getWeightInGrams(): number;
  setWeightInGrams(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WeightedPricingDescriptor.AsObject;
  static toObject(includeInstance: boolean, msg: WeightedPricingDescriptor): WeightedPricingDescriptor.AsObject;
  static serializeBinaryToWriter(message: WeightedPricingDescriptor, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WeightedPricingDescriptor;
  static deserializeBinaryFromReader(message: WeightedPricingDescriptor, reader: jspb.BinaryReader): WeightedPricingDescriptor;
}

export namespace WeightedPricingDescriptor {
  export type AsObject = {
    weight: PricingWeightTier,
    tier?: UnitPricingDescriptor.AsObject,
    weightInGrams: number,
  }
}

export class PricingDescriptor extends jspb.Message {
  getType(): PricingType;
  setType(value: PricingType): void;

  getUnit(): UnitPricingDescriptor | undefined;
  setUnit(value?: UnitPricingDescriptor): void;
  hasUnit(): boolean;
  clearUnit(): void;
  hasUnit(): boolean;

  getWeighted(): WeightedPricingDescriptor | undefined;
  setWeighted(value?: WeightedPricingDescriptor): void;
  hasWeighted(): boolean;
  clearWeighted(): void;
  hasWeighted(): boolean;

  getTierCase(): PricingDescriptor.TierCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PricingDescriptor.AsObject;
  static toObject(includeInstance: boolean, msg: PricingDescriptor): PricingDescriptor.AsObject;
  static serializeBinaryToWriter(message: PricingDescriptor, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PricingDescriptor;
  static deserializeBinaryFromReader(message: PricingDescriptor, reader: jspb.BinaryReader): PricingDescriptor;
}

export namespace PricingDescriptor {
  export type AsObject = {
    type: PricingType,
    unit?: UnitPricingDescriptor.AsObject,
    weighted?: WeightedPricingDescriptor.AsObject,
  }

  export enum TierCase { 
    TIER_NOT_SET = 0,
    UNIT = 20,
    WEIGHTED = 21,
  }
}

export class ProductPricing extends jspb.Message {
  getDiscountsList(): Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor>;
  setDiscountsList(value: Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor>): void;
  clearDiscountsList(): void;
  addDiscounts(value?: structs_pricing_SaleDescriptor_pb.SaleDescriptor, index?: number): structs_pricing_SaleDescriptor_pb.SaleDescriptor;

  getManifestList(): Array<PricingDescriptor>;
  setManifestList(value: Array<PricingDescriptor>): void;
  clearManifestList(): void;
  addManifest(value?: PricingDescriptor, index?: number): PricingDescriptor;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductPricing.AsObject;
  static toObject(includeInstance: boolean, msg: ProductPricing): ProductPricing.AsObject;
  static serializeBinaryToWriter(message: ProductPricing, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductPricing;
  static deserializeBinaryFromReader(message: ProductPricing, reader: jspb.BinaryReader): ProductPricing;
}

export namespace ProductPricing {
  export type AsObject = {
    discountsList: Array<structs_pricing_SaleDescriptor_pb.SaleDescriptor.AsObject>,
    manifestList: Array<PricingDescriptor.AsObject>,
  }
}

export enum PricingType { 
  UNIT = 0,
  WEIGHTED = 1,
}
export enum PricingWeightTier { 
  NO_WEIGHT = 0,
  GRAM = 1,
  HALFGRAM = 2,
  QUARTERGRAM = 3,
  DUB = 4,
  EIGHTH = 5,
  QUARTER = 6,
  HALF = 7,
  OUNCE = 8,
  QUARTERPOUND = 9,
  HALFPOUND = 10,
  POUND = 11,
  KILO = 12,
  TON = 13,
  OTHER = 99,
}
