import * as jspb from "google-protobuf"

import * as content_Content_pb from '../../content/Content_pb';
import * as temporal_Instant_pb from '../../temporal/Instant_pb';
import * as structs_labtesting_TestValue_pb from '../../structs/labtesting/TestValue_pb';

export class Contaminants extends jspb.Message {
  getPesticides(): Pesticides | undefined;
  setPesticides(value?: Pesticides): void;
  hasPesticides(): boolean;
  clearPesticides(): void;

  getMetals(): Metals | undefined;
  setMetals(value?: Metals): void;
  hasMetals(): boolean;
  clearMetals(): void;

  getMoldMildew(): MoldMildew | undefined;
  setMoldMildew(value?: MoldMildew): void;
  hasMoldMildew(): boolean;
  clearMoldMildew(): void;

  getOtherContaminants(): OtherContaminants | undefined;
  setOtherContaminants(value?: OtherContaminants): void;
  hasOtherContaminants(): boolean;
  clearOtherContaminants(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Contaminants.AsObject;
  static toObject(includeInstance: boolean, msg: Contaminants): Contaminants.AsObject;
  static serializeBinaryToWriter(message: Contaminants, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Contaminants;
  static deserializeBinaryFromReader(message: Contaminants, reader: jspb.BinaryReader): Contaminants;
}

export namespace Contaminants {
  export type AsObject = {
    pesticides?: Pesticides.AsObject,
    metals?: Metals.AsObject,
    moldMildew?: MoldMildew.AsObject,
    otherContaminants?: OtherContaminants.AsObject,
  }
}

export class TestSuite extends jspb.Message {
  getMethod(): TestMethod;
  setMethod(value: TestMethod): void;

  getResults(): TestResults | undefined;
  setResults(value?: TestResults): void;
  hasResults(): boolean;
  clearResults(): void;

  getComments(): string;
  setComments(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TestSuite.AsObject;
  static toObject(includeInstance: boolean, msg: TestSuite): TestSuite.AsObject;
  static serializeBinaryToWriter(message: TestSuite, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TestSuite;
  static deserializeBinaryFromReader(message: TestSuite, reader: jspb.BinaryReader): TestSuite;
}

export namespace TestSuite {
  export type AsObject = {
    method: TestMethod,
    results?: TestResults.AsObject,
    comments: string,
  }
}

export class TestResults extends jspb.Message {
  getAvailable(): boolean;
  setAvailable(value: boolean): void;

  getMediaList(): Array<structs_labtesting_TestValue_pb.TestMedia>;
  setMediaList(value: Array<structs_labtesting_TestValue_pb.TestMedia>): void;
  clearMediaList(): void;
  addMedia(value?: structs_labtesting_TestValue_pb.TestMedia, index?: number): structs_labtesting_TestValue_pb.TestMedia;

  getLastUpdated(): temporal_Instant_pb.Instant | undefined;
  setLastUpdated(value?: temporal_Instant_pb.Instant): void;
  hasLastUpdated(): boolean;
  clearLastUpdated(): void;

  getSealed(): temporal_Instant_pb.Instant | undefined;
  setSealed(value?: temporal_Instant_pb.Instant): void;
  hasSealed(): boolean;
  clearSealed(): void;

  getCoordinates(): TestCoordinates | undefined;
  setCoordinates(value?: TestCoordinates): void;
  hasCoordinates(): boolean;
  clearCoordinates(): void;

  getCannabinoids(): Cannabinoids | undefined;
  setCannabinoids(value?: Cannabinoids): void;
  hasCannabinoids(): boolean;
  clearCannabinoids(): void;

  getTerpenes(): Terpenes | undefined;
  setTerpenes(value?: Terpenes): void;
  hasTerpenes(): boolean;
  clearTerpenes(): void;

  getContaminants(): Contaminants | undefined;
  setContaminants(value?: Contaminants): void;
  hasContaminants(): boolean;
  clearContaminants(): void;

  getMoisture(): Moisture | undefined;
  setMoisture(value?: Moisture): void;
  hasMoisture(): boolean;
  clearMoisture(): void;

  getSubjective(): Subjective | undefined;
  setSubjective(value?: Subjective): void;
  hasSubjective(): boolean;
  clearSubjective(): void;

  getAromaList(): Array<TasteNote>;
  setAromaList(value: Array<TasteNote>): void;
  clearAromaList(): void;
  addAroma(value: TasteNote, index?: number): void;

  getDataList(): Array<TestResults>;
  setDataList(value: Array<TestResults>): void;
  clearDataList(): void;
  addData(value?: TestResults, index?: number): TestResults;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TestResults.AsObject;
  static toObject(includeInstance: boolean, msg: TestResults): TestResults.AsObject;
  static serializeBinaryToWriter(message: TestResults, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TestResults;
  static deserializeBinaryFromReader(message: TestResults, reader: jspb.BinaryReader): TestResults;
}

export namespace TestResults {
  export type AsObject = {
    available: boolean,
    mediaList: Array<structs_labtesting_TestValue_pb.TestMedia.AsObject>,
    lastUpdated?: temporal_Instant_pb.Instant.AsObject,
    sealed?: temporal_Instant_pb.Instant.AsObject,
    coordinates?: TestCoordinates.AsObject,
    cannabinoids?: Cannabinoids.AsObject,
    terpenes?: Terpenes.AsObject,
    contaminants?: Contaminants.AsObject,
    moisture?: Moisture.AsObject,
    subjective?: Subjective.AsObject,
    aromaList: Array<TasteNote>,
    dataList: Array<TestResults.AsObject>,
  }
}

export class TestCoordinates extends jspb.Message {
  getZone(): string;
  setZone(value: string): void;

  getLot(): string;
  setLot(value: string): void;

  getBatch(): string;
  setBatch(value: string): void;

  getSampleId(): string;
  setSampleId(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TestCoordinates.AsObject;
  static toObject(includeInstance: boolean, msg: TestCoordinates): TestCoordinates.AsObject;
  static serializeBinaryToWriter(message: TestCoordinates, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TestCoordinates;
  static deserializeBinaryFromReader(message: TestCoordinates, reader: jspb.BinaryReader): TestCoordinates;
}

export namespace TestCoordinates {
  export type AsObject = {
    zone: string,
    lot: string,
    batch: string,
    sampleId: string,
  }
}

export class Cannabinoids extends jspb.Message {
  getThc(): structs_labtesting_TestValue_pb.TestValue | undefined;
  setThc(value?: structs_labtesting_TestValue_pb.TestValue): void;
  hasThc(): boolean;
  clearThc(): void;

  getCbd(): structs_labtesting_TestValue_pb.TestValue | undefined;
  setCbd(value?: structs_labtesting_TestValue_pb.TestValue): void;
  hasCbd(): boolean;
  clearCbd(): void;

  getResultsList(): Array<Cannabinoids.Result>;
  setResultsList(value: Array<Cannabinoids.Result>): void;
  clearResultsList(): void;
  addResults(value?: Cannabinoids.Result, index?: number): Cannabinoids.Result;

  getRatio(): CannabinoidRatio;
  setRatio(value: CannabinoidRatio): void;

  getPotency(): PotencyEstimate;
  setPotency(value: PotencyEstimate): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Cannabinoids.AsObject;
  static toObject(includeInstance: boolean, msg: Cannabinoids): Cannabinoids.AsObject;
  static serializeBinaryToWriter(message: Cannabinoids, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Cannabinoids;
  static deserializeBinaryFromReader(message: Cannabinoids, reader: jspb.BinaryReader): Cannabinoids;
}

export namespace Cannabinoids {
  export type AsObject = {
    thc?: structs_labtesting_TestValue_pb.TestValue.AsObject,
    cbd?: structs_labtesting_TestValue_pb.TestValue.AsObject,
    resultsList: Array<Cannabinoids.Result.AsObject>,
    ratio: CannabinoidRatio,
    potency: PotencyEstimate,
  }

  export class Result extends jspb.Message {
    getCannabinoid(): Cannabinoid;
    setCannabinoid(value: Cannabinoid): void;

    getMeasurement(): structs_labtesting_TestValue_pb.TestValue | undefined;
    setMeasurement(value?: structs_labtesting_TestValue_pb.TestValue): void;
    hasMeasurement(): boolean;
    clearMeasurement(): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Result.AsObject;
    static toObject(includeInstance: boolean, msg: Result): Result.AsObject;
    static serializeBinaryToWriter(message: Result, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Result;
    static deserializeBinaryFromReader(message: Result, reader: jspb.BinaryReader): Result;
  }

  export namespace Result {
    export type AsObject = {
      cannabinoid: Cannabinoid,
      measurement?: structs_labtesting_TestValue_pb.TestValue.AsObject,
    }
  }

}

export class Subjective extends jspb.Message {
  getDescription(): content_Content_pb.Content | undefined;
  setDescription(value?: content_Content_pb.Content): void;
  hasDescription(): boolean;
  clearDescription(): void;

  getTaste(): content_Content_pb.Content | undefined;
  setTaste(value?: content_Content_pb.Content): void;
  hasTaste(): boolean;
  clearTaste(): void;

  getPotency(): PotencyEstimate;
  setPotency(value: PotencyEstimate): void;

  getFeelingList(): Array<Feeling>;
  setFeelingList(value: Array<Feeling>): void;
  clearFeelingList(): void;
  addFeeling(value: Feeling, index?: number): void;

  getAromaList(): Array<TasteNote>;
  setAromaList(value: Array<TasteNote>): void;
  clearAromaList(): void;
  addAroma(value: TasteNote, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Subjective.AsObject;
  static toObject(includeInstance: boolean, msg: Subjective): Subjective.AsObject;
  static serializeBinaryToWriter(message: Subjective, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Subjective;
  static deserializeBinaryFromReader(message: Subjective, reader: jspb.BinaryReader): Subjective;
}

export namespace Subjective {
  export type AsObject = {
    description?: content_Content_pb.Content.AsObject,
    taste?: content_Content_pb.Content.AsObject,
    potency: PotencyEstimate,
    feelingList: Array<Feeling>,
    aromaList: Array<TasteNote>,
  }
}

export class Pesticides extends jspb.Message {
  getPesticideFree(): boolean;
  setPesticideFree(value: boolean): void;

  getMeasurementsMap(): jspb.Map<string, structs_labtesting_TestValue_pb.TestValue>;
  clearMeasurementsMap(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Pesticides.AsObject;
  static toObject(includeInstance: boolean, msg: Pesticides): Pesticides.AsObject;
  static serializeBinaryToWriter(message: Pesticides, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Pesticides;
  static deserializeBinaryFromReader(message: Pesticides, reader: jspb.BinaryReader): Pesticides;
}

export namespace Pesticides {
  export type AsObject = {
    pesticideFree: boolean,
    measurementsMap: Array<[string, structs_labtesting_TestValue_pb.TestValue.AsObject]>,
  }
}

export class Metals extends jspb.Message {
  getMetalFree(): boolean;
  setMetalFree(value: boolean): void;

  getMeasurementsMap(): jspb.Map<string, structs_labtesting_TestValue_pb.TestValue>;
  clearMeasurementsMap(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Metals.AsObject;
  static toObject(includeInstance: boolean, msg: Metals): Metals.AsObject;
  static serializeBinaryToWriter(message: Metals, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Metals;
  static deserializeBinaryFromReader(message: Metals, reader: jspb.BinaryReader): Metals;
}

export namespace Metals {
  export type AsObject = {
    metalFree: boolean,
    measurementsMap: Array<[string, structs_labtesting_TestValue_pb.TestValue.AsObject]>,
  }
}

export class MoldMildew extends jspb.Message {
  getMoldMildewFree(): boolean;
  setMoldMildewFree(value: boolean): void;

  getMeasurementsMap(): jspb.Map<string, structs_labtesting_TestValue_pb.TestValue>;
  clearMeasurementsMap(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MoldMildew.AsObject;
  static toObject(includeInstance: boolean, msg: MoldMildew): MoldMildew.AsObject;
  static serializeBinaryToWriter(message: MoldMildew, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MoldMildew;
  static deserializeBinaryFromReader(message: MoldMildew, reader: jspb.BinaryReader): MoldMildew;
}

export namespace MoldMildew {
  export type AsObject = {
    moldMildewFree: boolean,
    measurementsMap: Array<[string, structs_labtesting_TestValue_pb.TestValue.AsObject]>,
  }
}

export class OtherContaminants extends jspb.Message {
  getMeasurementsMap(): jspb.Map<string, structs_labtesting_TestValue_pb.TestValue>;
  clearMeasurementsMap(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OtherContaminants.AsObject;
  static toObject(includeInstance: boolean, msg: OtherContaminants): OtherContaminants.AsObject;
  static serializeBinaryToWriter(message: OtherContaminants, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OtherContaminants;
  static deserializeBinaryFromReader(message: OtherContaminants, reader: jspb.BinaryReader): OtherContaminants;
}

export namespace OtherContaminants {
  export type AsObject = {
    measurementsMap: Array<[string, structs_labtesting_TestValue_pb.TestValue.AsObject]>,
  }
}

export class Moisture extends jspb.Message {
  getMeasurement(): structs_labtesting_TestValue_pb.TestValue | undefined;
  setMeasurement(value?: structs_labtesting_TestValue_pb.TestValue): void;
  hasMeasurement(): boolean;
  clearMeasurement(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Moisture.AsObject;
  static toObject(includeInstance: boolean, msg: Moisture): Moisture.AsObject;
  static serializeBinaryToWriter(message: Moisture, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Moisture;
  static deserializeBinaryFromReader(message: Moisture, reader: jspb.BinaryReader): Moisture;
}

export namespace Moisture {
  export type AsObject = {
    measurement?: structs_labtesting_TestValue_pb.TestValue.AsObject,
  }
}

export class Terpenes extends jspb.Message {
  getAvailable(): boolean;
  setAvailable(value: boolean): void;

  getTerpeneList(): Array<Terpenes.Result>;
  setTerpeneList(value: Array<Terpenes.Result>): void;
  clearTerpeneList(): void;
  addTerpene(value?: Terpenes.Result, index?: number): Terpenes.Result;

  getFeelingList(): Array<Feeling>;
  setFeelingList(value: Array<Feeling>): void;
  clearFeelingList(): void;
  addFeeling(value: Feeling, index?: number): void;

  getAromaList(): Array<TasteNote>;
  setAromaList(value: Array<TasteNote>): void;
  clearAromaList(): void;
  addAroma(value: TasteNote, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Terpenes.AsObject;
  static toObject(includeInstance: boolean, msg: Terpenes): Terpenes.AsObject;
  static serializeBinaryToWriter(message: Terpenes, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Terpenes;
  static deserializeBinaryFromReader(message: Terpenes, reader: jspb.BinaryReader): Terpenes;
}

export namespace Terpenes {
  export type AsObject = {
    available: boolean,
    terpeneList: Array<Terpenes.Result.AsObject>,
    feelingList: Array<Feeling>,
    aromaList: Array<TasteNote>,
  }

  export class Result extends jspb.Message {
    getTerpene(): Terpene;
    setTerpene(value: Terpene): void;

    getMeasurement(): structs_labtesting_TestValue_pb.TestValue | undefined;
    setMeasurement(value?: structs_labtesting_TestValue_pb.TestValue): void;
    hasMeasurement(): boolean;
    clearMeasurement(): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Result.AsObject;
    static toObject(includeInstance: boolean, msg: Result): Result.AsObject;
    static serializeBinaryToWriter(message: Result, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Result;
    static deserializeBinaryFromReader(message: Result, reader: jspb.BinaryReader): Result;
  }

  export namespace Result {
    export type AsObject = {
      terpene: Terpene,
      measurement?: structs_labtesting_TestValue_pb.TestValue.AsObject,
    }
  }

}

export enum TestMethod { 
  UNSPECIFIED_METHOD = 0,
  GCMS = 1,
  LCMS = 2,
  CLASSIC_PCR = 3,
  qPCR = 4,
  ELISA = 5,
}
export enum Cannabinoid { 
  THC = 0,
  THC_A = 1,
  THC_V = 2,
  CBD = 10,
  CBD_A = 11,
  CBD_V = 12,
  CBD_VA = 13,
  CBC = 20,
  CBG = 30,
  CBG_A = 31,
  CBN = 40,
  CBV = 50,
  CBV_A = 51,
}
export enum CannabinoidRatio { 
  NO_CANNABINOID_PREFERENCE = 0,
  THC_ONLY = 1,
  THC_OVER_CBD = 2,
  EQUAL = 3,
  CBD_OVER_THC = 4,
  CBD_ONLY = 5,
}
export enum Feeling { 
  NO_FEELING_PREFERENCE = 0,
  GROUNDING = 1,
  SLEEP = 2,
  CALMING = 3,
  STIMULATING = 4,
  FUNNY = 5,
  FOCUS = 6,
  PASSION = 7,
}
export enum TasteNote { 
  NO_TASTE_PREFERENCE = 0,
  SWEET = 1,
  SOUR = 2,
  SPICE = 3,
  SMOOTH = 4,
  CITRUS = 5,
  PINE = 6,
  FRUIT = 7,
  TROPICS = 8,
  FLORAL = 9,
  HERB = 10,
  EARTH = 11,
}
export enum PotencyEstimate { 
  LIGHT = 0,
  MEDIUM = 1,
  HEAVY = 2,
  SUPER = 3,
}
export enum Terpene { 
  CAMPHENE = 0,
  CARENE = 1,
  BETA_CARYOPHYLLENE = 2,
  CARYOPHYLLENE_OXIDE = 3,
  EUCALYPTOL = 4,
  FENCHOL = 5,
  ALPHA_HUMULENE = 6,
  LIMONENE = 7,
  LINALOOL = 8,
  MYRCENE = 9,
  ALPHA_OCIMENE = 10,
  BETA_OCIMENE = 11,
  ALPHA_PHELLANDRENE = 12,
  ALPHA_PINENE = 13,
  BETA_PINENE = 14,
  ALPHA_TERPINEOL = 15,
  ALPHA_TERPININE = 16,
  GAMMA_TERPININE = 17,
  TERPINOLENE = 18,
  VALENCENE = 19,
  GERANIOL = 20,
  PHELLANDRENE = 21,
  BORNEOL = 22,
  ISOBORNEOL = 23,
  BISABOLOL = 24,
  PHYTOL = 25,
  SABINENE = 26,
  CAMPHOR = 27,
  MENTHOL = 28,
  CEDRENE = 29,
  NEROL = 30,
  NEROLIDOL = 31,
  GUAIOL = 32,
  ISOPULEGOL = 33,
  GERANYL_ACETATE = 34,
  CYMENE = 35,
  PULEGONE = 36,
  CINEOLE = 37,
  FENCHONE = 38,
  TERPINENE = 39,
  CITRONELLOL = 40,
  DELTA_3_CARENE = 41,
}
