import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class VersionSpec extends jspb.Message {
  getName(): string;
  setName(value: string): void;
  hasName(): boolean;

  getSpecCase(): VersionSpec.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VersionSpec.AsObject;
  static toObject(includeInstance: boolean, msg: VersionSpec): VersionSpec.AsObject;
  static serializeBinaryToWriter(message: VersionSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VersionSpec;
  static deserializeBinaryFromReader(message: VersionSpec, reader: jspb.BinaryReader): VersionSpec;
}

export namespace VersionSpec {
  export type AsObject = {
    name: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    NAME = 1,
  }
}

