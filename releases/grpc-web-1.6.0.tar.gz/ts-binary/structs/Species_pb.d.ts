import * as jspb from "google-protobuf"

export enum Species { 
  UNSPECIFIED = 0,
  SATIVA = 1,
  HYBRID_SATIVA = 2,
  HYBRID = 3,
  HYBRID_INDICA = 4,
  INDICA = 5,
}
