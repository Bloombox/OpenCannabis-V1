import * as jspb from "google-protobuf"

export enum ProductFlag { 
  VISIBLE = 0,
  HIDDEN = 1,
  PREMIUM = 2,
  FEATURED = 3,
  EXCLUSIVE = 4,
  IN_HOUSE = 5,
  LAST_CHANCE = 6,
  LIMITED_TIME = 7,
  LOCAL = 8,
  ON_SALE = 20,
}
