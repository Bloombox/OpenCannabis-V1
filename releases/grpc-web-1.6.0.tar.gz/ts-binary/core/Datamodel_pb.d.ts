import * as jspb from "google-protobuf"

import * as google_protobuf_descriptor_pb from 'google-protobuf/google/protobuf/descriptor_pb';
import * as content_Colors_pb from '../content/Colors_pb';

export class DatapointOptions extends jspb.Message {
  getVisibility(): Visibility;
  setVisibility(value: Visibility): void;

  getRequired(): boolean;
  setRequired(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DatapointOptions.AsObject;
  static toObject(includeInstance: boolean, msg: DatapointOptions): DatapointOptions.AsObject;
  static serializeBinaryToWriter(message: DatapointOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DatapointOptions;
  static deserializeBinaryFromReader(message: DatapointOptions, reader: jspb.BinaryReader): DatapointOptions;
}

export namespace DatapointOptions {
  export type AsObject = {
    visibility: Visibility,
    required: boolean,
  }
}

export class PersistenceOptions extends jspb.Message {
  getMode(): CollectionMode;
  setMode(value: CollectionMode): void;

  getPath(): string;
  setPath(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PersistenceOptions.AsObject;
  static toObject(includeInstance: boolean, msg: PersistenceOptions): PersistenceOptions.AsObject;
  static serializeBinaryToWriter(message: PersistenceOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PersistenceOptions;
  static deserializeBinaryFromReader(message: PersistenceOptions, reader: jspb.BinaryReader): PersistenceOptions;
}

export namespace PersistenceOptions {
  export type AsObject = {
    mode: CollectionMode,
    path: string,
  }
}

export class TableOptions extends jspb.Message {
  getName(): string;
  setName(value: string): void;

  getDescription(): string;
  setDescription(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TableOptions.AsObject;
  static toObject(includeInstance: boolean, msg: TableOptions): TableOptions.AsObject;
  static serializeBinaryToWriter(message: TableOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TableOptions;
  static deserializeBinaryFromReader(message: TableOptions, reader: jspb.BinaryReader): TableOptions;
}

export namespace TableOptions {
  export type AsObject = {
    name: string,
    description: string,
  }
}

export class SubmessageOptions extends jspb.Message {
  getMode(): CollectionMode;
  setMode(value: CollectionMode): void;

  getPath(): string;
  setPath(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SubmessageOptions.AsObject;
  static toObject(includeInstance: boolean, msg: SubmessageOptions): SubmessageOptions.AsObject;
  static serializeBinaryToWriter(message: SubmessageOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SubmessageOptions;
  static deserializeBinaryFromReader(message: SubmessageOptions, reader: jspb.BinaryReader): SubmessageOptions;
}

export namespace SubmessageOptions {
  export type AsObject = {
    mode: CollectionMode,
    path: string,
  }
}

export class FieldPersistenceOptions extends jspb.Message {
  getType(): FieldType;
  setType(value: FieldType): void;

  getDescription(): string;
  setDescription(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FieldPersistenceOptions.AsObject;
  static toObject(includeInstance: boolean, msg: FieldPersistenceOptions): FieldPersistenceOptions.AsObject;
  static serializeBinaryToWriter(message: FieldPersistenceOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FieldPersistenceOptions;
  static deserializeBinaryFromReader(message: FieldPersistenceOptions, reader: jspb.BinaryReader): FieldPersistenceOptions;
}

export namespace FieldPersistenceOptions {
  export type AsObject = {
    type: FieldType,
    description: string,
  }
}

export class TableFieldOptions extends jspb.Message {
  getRequire(): boolean;
  setRequire(value: boolean): void;

  getIgnore(): boolean;
  setIgnore(value: boolean): void;

  getBqtype(): string;
  setBqtype(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TableFieldOptions.AsObject;
  static toObject(includeInstance: boolean, msg: TableFieldOptions): TableFieldOptions.AsObject;
  static serializeBinaryToWriter(message: TableFieldOptions, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TableFieldOptions;
  static deserializeBinaryFromReader(message: TableFieldOptions, reader: jspb.BinaryReader): TableFieldOptions;
}

export namespace TableFieldOptions {
  export type AsObject = {
    require: boolean,
    ignore: boolean,
    bqtype: string,
  }
}

export class ObjectMapping extends jspb.Message {
  getInstanceList(): Array<string>;
  setInstanceList(value: Array<string>): void;
  clearInstanceList(): void;
  addInstance(value: string, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ObjectMapping.AsObject;
  static toObject(includeInstance: boolean, msg: ObjectMapping): ObjectMapping.AsObject;
  static serializeBinaryToWriter(message: ObjectMapping, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ObjectMapping;
  static deserializeBinaryFromReader(message: ObjectMapping, reader: jspb.BinaryReader): ObjectMapping;
}

export namespace ObjectMapping {
  export type AsObject = {
    instanceList: Array<string>,
  }
}

export enum Visibility { 
  PUBLIC = 0,
  PRIVATE = 1,
  PROTECTED = 2,
  PACKAGE = 3,
  EXPORT = 4,
}
export enum CollectionMode { 
  NESTED = 0,
  COLLECTION = 1,
  GROUP = 2,
}
export enum FieldType { 
  STANDARD = 0,
  KEY = 1,
  ID = 2,
  TAGS = 3,
  FLAGS = 4,
}
