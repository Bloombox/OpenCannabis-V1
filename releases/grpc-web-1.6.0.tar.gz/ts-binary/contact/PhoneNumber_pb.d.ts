import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class PhoneNumber extends jspb.Message {
  getE164(): string;
  setE164(value: string): void;

  getValidated(): boolean;
  setValidated(value: boolean): void;

  getDisplay(): string;
  setDisplay(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PhoneNumber.AsObject;
  static toObject(includeInstance: boolean, msg: PhoneNumber): PhoneNumber.AsObject;
  static serializeBinaryToWriter(message: PhoneNumber, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PhoneNumber;
  static deserializeBinaryFromReader(message: PhoneNumber, reader: jspb.BinaryReader): PhoneNumber;
}

export namespace PhoneNumber {
  export type AsObject = {
    e164: string,
    validated: boolean,
    display: string,
  }
}

