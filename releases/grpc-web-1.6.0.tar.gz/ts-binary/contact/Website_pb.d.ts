import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class Website extends jspb.Message {
  getUri(): string;
  setUri(value: string): void;

  getTitle(): string;
  setTitle(value: string): void;

  getIcon(): Uint8Array | string;
  getIcon_asU8(): Uint8Array;
  getIcon_asB64(): string;
  setIcon(value: Uint8Array | string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Website.AsObject;
  static toObject(includeInstance: boolean, msg: Website): Website.AsObject;
  static serializeBinaryToWriter(message: Website, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Website;
  static deserializeBinaryFromReader(message: Website, reader: jspb.BinaryReader): Website;
}

export namespace Website {
  export type AsObject = {
    uri: string,
    title: string,
    icon: Uint8Array | string,
  }
}

