import * as jspb from "google-protobuf"

export enum MediaOrientation { 
  UP = 0,
  DOWN = 1,
  LEFT = 2,
  RIGHT = 3,
  UP_MIRRORED = 4,
  DOWN_MIRRORED = 5,
  LEFT_MIRRORED = 6,
  RIGHT_MIRRORED = 7,
}
