import * as jspb from "google-protobuf"

import * as bq_field_pb from '../bq_field_pb';

export class MediaType extends jspb.Message {
  getKind(): MediaType.Kind;
  setKind(value: MediaType.Kind): void;

  getImageType(): MediaType.ImageKind;
  setImageType(value: MediaType.ImageKind): void;
  hasImageType(): boolean;

  getDocumentType(): MediaType.DocumentKind;
  setDocumentType(value: MediaType.DocumentKind): void;
  hasDocumentType(): boolean;

  getVideoType(): MediaType.VideoKind;
  setVideoType(value: MediaType.VideoKind): void;
  hasVideoType(): boolean;

  getContentCase(): MediaType.ContentCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaType.AsObject;
  static toObject(includeInstance: boolean, msg: MediaType): MediaType.AsObject;
  static serializeBinaryToWriter(message: MediaType, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaType;
  static deserializeBinaryFromReader(message: MediaType, reader: jspb.BinaryReader): MediaType;
}

export namespace MediaType {
  export type AsObject = {
    kind: MediaType.Kind,
    imageType: MediaType.ImageKind,
    documentType: MediaType.DocumentKind,
    videoType: MediaType.VideoKind,
  }

  export enum Kind { 
    LINK = 0,
    IMAGE = 1,
    DOCUMENT = 2,
    VIDEO = 3,
  }

  export enum ImageKind { 
    UNSPECIFIED_IMAGE_TYPE = 0,
    PNG = 1,
    JPG = 2,
    GIF = 3,
    SVG = 4,
    WEBP = 5,
  }

  export enum ImageDPI { 
    X1 = 0,
    X2 = 1,
    X3 = 2,
  }

  export enum DocumentKind { 
    UNSPECIFIED_DOCUMENT_TYPE = 0,
    TXT = 1,
    HTML = 2,
    PDF = 3,
    MARKDOWN = 4,
  }

  export enum VideoKind { 
    UNSPECIFIED_VIDEO_TYPE = 0,
    MP4 = 1,
    FLV = 2,
    HLS = 3,
  }

  export enum ContentCase { 
    CONTENT_NOT_SET = 0,
    IMAGE_TYPE = 101,
    DOCUMENT_TYPE = 201,
    VIDEO_TYPE = 301,
  }
}

