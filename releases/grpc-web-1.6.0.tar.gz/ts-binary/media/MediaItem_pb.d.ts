import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as media_MediaKey_pb from '../media/MediaKey_pb';
import * as media_MediaType_pb from '../media/MediaType_pb';
import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as identity_UserKey_pb from '../identity/UserKey_pb';
import * as partner_PartnerKey_pb from '../partner/PartnerKey_pb';
import * as partner_LocationKey_pb from '../partner/LocationKey_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';

export class MediaSubject extends jspb.Message {
  getProduct(): base_ProductKey_pb.ProductKey | undefined;
  setProduct(value?: base_ProductKey_pb.ProductKey): void;
  hasProduct(): boolean;
  clearProduct(): void;
  hasProduct(): boolean;

  getPartner(): string;
  setPartner(value: string): void;
  hasPartner(): boolean;

  getLocation(): string;
  setLocation(value: string): void;
  hasLocation(): boolean;

  getGlobal(): boolean;
  setGlobal(value: boolean): void;
  hasGlobal(): boolean;

  getAttachmentCase(): MediaSubject.AttachmentCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaSubject.AsObject;
  static toObject(includeInstance: boolean, msg: MediaSubject): MediaSubject.AsObject;
  static serializeBinaryToWriter(message: MediaSubject, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaSubject;
  static deserializeBinaryFromReader(message: MediaSubject, reader: jspb.BinaryReader): MediaSubject;
}

export namespace MediaSubject {
  export type AsObject = {
    product?: base_ProductKey_pb.ProductKey.AsObject,
    partner: string,
    location: string,
    global: boolean,
  }

  export enum AttachmentCase { 
    ATTACHMENT_NOT_SET = 0,
    PRODUCT = 2,
    PARTNER = 3,
    LOCATION = 4,
    GLOBAL = 5,
  }
}

export class MediaUpload extends jspb.Message {
  getToken(): string;
  setToken(value: string): void;

  getOperation(): string;
  setOperation(value: string): void;

  getMedia(): MediaItem | undefined;
  setMedia(value?: MediaItem): void;
  hasMedia(): boolean;
  clearMedia(): void;

  getMime(): string;
  setMime(value: string): void;

  getSize(): number;
  setSize(value: number): void;

  getFinished(): boolean;
  setFinished(value: boolean): void;

  getMd5(): string;
  setMd5(value: string): void;

  getCrc32(): string;
  setCrc32(value: string): void;

  getOwner(): string;
  setOwner(value: string): void;

  getPath(): string;
  setPath(value: string): void;

  getParent(): string;
  setParent(value: string): void;

  getCreated(): temporal_Instant_pb.Instant | undefined;
  setCreated(value?: temporal_Instant_pb.Instant): void;
  hasCreated(): boolean;
  clearCreated(): void;

  getCompleted(): temporal_Instant_pb.Instant | undefined;
  setCompleted(value?: temporal_Instant_pb.Instant): void;
  hasCompleted(): boolean;
  clearCompleted(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaUpload.AsObject;
  static toObject(includeInstance: boolean, msg: MediaUpload): MediaUpload.AsObject;
  static serializeBinaryToWriter(message: MediaUpload, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaUpload;
  static deserializeBinaryFromReader(message: MediaUpload, reader: jspb.BinaryReader): MediaUpload;
}

export namespace MediaUpload {
  export type AsObject = {
    token: string,
    operation: string,
    media?: MediaItem.AsObject,
    mime: string,
    size: number,
    finished: boolean,
    md5: string,
    crc32: string,
    owner: string,
    path: string,
    parent: string,
    created?: temporal_Instant_pb.Instant.AsObject,
    completed?: temporal_Instant_pb.Instant.AsObject,
  }
}

export class MediaItem extends jspb.Message {
  getKey(): media_MediaKey_pb.MediaKey | undefined;
  setKey(value?: media_MediaKey_pb.MediaKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getStatus(): MediaStatus;
  setStatus(value: MediaStatus): void;

  getType(): media_MediaType_pb.MediaType | undefined;
  setType(value?: media_MediaType_pb.MediaType): void;
  hasType(): boolean;
  clearType(): void;

  getName(): string;
  setName(value: string): void;

  getUri(): string;
  setUri(value: string): void;

  getServingUri(): string;
  setServingUri(value: string): void;

  getPrivacy(): MediaPrivacy;
  setPrivacy(value: MediaPrivacy): void;

  getCreated(): temporal_Instant_pb.Instant | undefined;
  setCreated(value?: temporal_Instant_pb.Instant): void;
  hasCreated(): boolean;
  clearCreated(): void;

  getModified(): temporal_Instant_pb.Instant | undefined;
  setModified(value?: temporal_Instant_pb.Instant): void;
  hasModified(): boolean;
  clearModified(): void;

  getPublished(): temporal_Instant_pb.Instant | undefined;
  setPublished(value?: temporal_Instant_pb.Instant): void;
  hasPublished(): boolean;
  clearPublished(): void;

  getScope(): string;
  setScope(value: string): void;

  getToken(): string;
  setToken(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaItem.AsObject;
  static toObject(includeInstance: boolean, msg: MediaItem): MediaItem.AsObject;
  static serializeBinaryToWriter(message: MediaItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaItem;
  static deserializeBinaryFromReader(message: MediaItem, reader: jspb.BinaryReader): MediaItem;
}

export namespace MediaItem {
  export type AsObject = {
    key?: media_MediaKey_pb.MediaKey.AsObject,
    status: MediaStatus,
    type?: media_MediaType_pb.MediaType.AsObject,
    name: string,
    uri: string,
    servingUri: string,
    privacy: MediaPrivacy,
    created?: temporal_Instant_pb.Instant.AsObject,
    modified?: temporal_Instant_pb.Instant.AsObject,
    published?: temporal_Instant_pb.Instant.AsObject,
    scope: string,
    token: string,
  }
}

export enum MediaStatus { 
  PROVISIONED = 0,
  PENDING = 1,
  UPLOADED = 2,
  READY = 3,
}
export enum MediaPrivacy { 
  DEFAULT_PRIVACY = 0,
  PARTNER = 1,
  PUBLIC = 2,
}
