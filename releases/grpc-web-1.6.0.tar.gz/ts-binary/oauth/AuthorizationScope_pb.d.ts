import * as jspb from "google-protobuf"

export class AuthorizationScope extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getLabel(): string;
  setLabel(value: string): void;

  getUri(): string;
  setUri(value: string): void;

  getIcon(): string;
  setIcon(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthorizationScope.AsObject;
  static toObject(includeInstance: boolean, msg: AuthorizationScope): AuthorizationScope.AsObject;
  static serializeBinaryToWriter(message: AuthorizationScope, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthorizationScope;
  static deserializeBinaryFromReader(message: AuthorizationScope, reader: jspb.BinaryReader): AuthorizationScope;
}

export namespace AuthorizationScope {
  export type AsObject = {
    id: string,
    label: string,
    uri: string,
    icon: string,
  }
}

