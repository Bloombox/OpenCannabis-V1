import * as jspb from "google-protobuf"

import * as protoc$gen$swagger_options_openapiv2_pb from '../../protoc-gen-swagger/options/openapiv2_pb';
import * as google_protobuf_descriptor_pb from 'google-protobuf/google/protobuf/descriptor_pb';

