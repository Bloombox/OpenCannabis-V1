import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Plant extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): PlantType;
  setType(value: PlantType): void;

  getOriginList(): Array<base_ProductKey_pb.ProductReference>;
  setOriginList(value: Array<base_ProductKey_pb.ProductReference>): void;
  clearOriginList(): void;
  addOrigin(value?: base_ProductKey_pb.ProductReference, index?: number): base_ProductKey_pb.ProductReference;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Plant.AsObject;
  static toObject(includeInstance: boolean, msg: Plant): Plant.AsObject;
  static serializeBinaryToWriter(message: Plant, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Plant;
  static deserializeBinaryFromReader(message: Plant, reader: jspb.BinaryReader): Plant;
}

export namespace Plant {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    type: PlantType,
    originList: Array<base_ProductKey_pb.ProductReference.AsObject>,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }
}

export enum PlantType { 
  UNSPECIFIED_PLANT = 0,
  SEED = 1,
  CLONE = 2,
}
