import * as jspb from "google-protobuf"

export class DistributionPolicy extends jspb.Message {
  getEnabled(): boolean;
  setEnabled(value: boolean): void;

  getChannel(): Channel;
  setChannel(value: Channel): void;

  getType(): ChannelType;
  setType(value: ChannelType): void;

  getSuppress(): boolean;
  setSuppress(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DistributionPolicy.AsObject;
  static toObject(includeInstance: boolean, msg: DistributionPolicy): DistributionPolicy.AsObject;
  static serializeBinaryToWriter(message: DistributionPolicy, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DistributionPolicy;
  static deserializeBinaryFromReader(message: DistributionPolicy, reader: jspb.BinaryReader): DistributionPolicy;
}

export namespace DistributionPolicy {
  export type AsObject = {
    enabled: boolean,
    channel: Channel,
    type: ChannelType,
    suppress: boolean,
  }
}

export enum Channel { 
  UNSPECIFIED_CHANNEL = 0,
  RETAIL = 1,
  WHOLESALE = 2,
  BULK = 3,
}
export enum ChannelType { 
  UNSPECIFIED_CHANNEL_TYPE = 0,
  DIRECT = 1,
  MARKETPLACE = 2,
}
