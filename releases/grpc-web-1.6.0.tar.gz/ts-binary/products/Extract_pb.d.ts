import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Extract extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): ExtractType;
  setType(value: ExtractType): void;

  getFlagList(): Array<ExtractFlag>;
  setFlagList(value: Array<ExtractFlag>): void;
  clearFlagList(): void;
  addFlag(value: ExtractFlag, index?: number): void;

  getFlower(): base_ProductKey_pb.ProductReference | undefined;
  setFlower(value?: base_ProductKey_pb.ProductReference): void;
  hasFlower(): boolean;
  clearFlower(): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Extract.AsObject;
  static toObject(includeInstance: boolean, msg: Extract): Extract.AsObject;
  static serializeBinaryToWriter(message: Extract, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Extract;
  static deserializeBinaryFromReader(message: Extract, reader: jspb.BinaryReader): Extract;
}

export namespace Extract {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    type: ExtractType,
    flagList: Array<ExtractFlag>,
    flower?: base_ProductKey_pb.ProductReference.AsObject,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }
}

export enum ExtractType { 
  UNSPECIFIED_EXTRACT = 0,
  OIL = 1,
  WAX = 2,
  SHATTER = 3,
  KIEF = 4,
  HASH = 5,
  LIVE_RESIN = 6,
  ROSIN = 7,
  CRUMBLE = 8,
  SAUCE = 9,
  SUGAR = 10,
}
export enum ExtractFlag { 
  NO_EXTRACT_FLAGS = 0,
  SOLVENTLESS = 1,
}
