import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Merchandise extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): MerchandiseType;
  setType(value: MerchandiseType): void;

  getFlagsList(): Array<MerchandiseFlag>;
  setFlagsList(value: Array<MerchandiseFlag>): void;
  clearFlagsList(): void;
  addFlags(value: MerchandiseFlag, index?: number): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Merchandise.AsObject;
  static toObject(includeInstance: boolean, msg: Merchandise): Merchandise.AsObject;
  static serializeBinaryToWriter(message: Merchandise, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Merchandise;
  static deserializeBinaryFromReader(message: Merchandise, reader: jspb.BinaryReader): Merchandise;
}

export namespace Merchandise {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    type: MerchandiseType,
    flagsList: Array<MerchandiseFlag>,
    product?: content_ProductContent_pb.ProductContent.AsObject,
  }
}

export enum MerchandiseType { 
  UNSPECIFIED_MERCHANDISE = 0,
  CLOTHING = 1,
  GLASSWARE = 2,
  CONTAINER = 3,
  LIGHTER = 4,
  TSHIRT = 5,
  HOODIE = 6,
  HAT = 7,
}
export enum MerchandiseFlag { 
  NO_MERCHANDISE_FLAGS = 0,
  MEDICAL_ONLY = 1,
  BRAND_SWAG = 2,
}
