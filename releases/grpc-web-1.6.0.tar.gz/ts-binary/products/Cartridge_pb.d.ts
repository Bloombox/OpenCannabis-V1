import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Cartridge extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): CartridgeType;
  setType(value: CartridgeType): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Cartridge.AsObject;
  static toObject(includeInstance: boolean, msg: Cartridge): Cartridge.AsObject;
  static serializeBinaryToWriter(message: Cartridge, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Cartridge;
  static deserializeBinaryFromReader(message: Cartridge, reader: jspb.BinaryReader): Cartridge;
}

export namespace Cartridge {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    type: CartridgeType,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }
}

export enum CartridgeType { 
  UNSPECIFIED_CARTRIDGE = 0,
  CARTRIDGE = 1,
  BATTERY = 2,
  KIT = 3,
}
