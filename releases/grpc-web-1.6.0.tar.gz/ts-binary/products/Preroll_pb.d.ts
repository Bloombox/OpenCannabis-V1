import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Preroll extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getFlower(): base_ProductKey_pb.ProductReference | undefined;
  setFlower(value?: base_ProductKey_pb.ProductReference): void;
  hasFlower(): boolean;
  clearFlower(): void;

  getLength(): number;
  setLength(value: number): void;

  getThickness(): number;
  setThickness(value: number): void;

  getFlagsList(): Array<PrerollFlag>;
  setFlagsList(value: Array<PrerollFlag>): void;
  clearFlagsList(): void;
  addFlags(value: PrerollFlag, index?: number): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Preroll.AsObject;
  static toObject(includeInstance: boolean, msg: Preroll): Preroll.AsObject;
  static serializeBinaryToWriter(message: Preroll, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Preroll;
  static deserializeBinaryFromReader(message: Preroll, reader: jspb.BinaryReader): Preroll;
}

export namespace Preroll {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    flower?: base_ProductKey_pb.ProductReference.AsObject,
    length: number,
    thickness: number,
    flagsList: Array<PrerollFlag>,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }
}

export enum PrerollFlag { 
  NO_PREROLL_FLAGS = 0,
  HASH_INFUSED = 1,
  KIEF_INFUSED = 2,
  FORTIFIED = 3,
  FULL_FLOWER = 4,
  CONTAINS_TOBACCO = 5,
}
