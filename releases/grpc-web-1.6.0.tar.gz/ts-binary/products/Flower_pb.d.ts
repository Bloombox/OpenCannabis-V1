import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Flower extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Flower.AsObject;
  static toObject(includeInstance: boolean, msg: Flower): Flower.AsObject;
  static serializeBinaryToWriter(message: Flower, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Flower;
  static deserializeBinaryFromReader(message: Flower, reader: jspb.BinaryReader): Flower;
}

export namespace Flower {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }
}

