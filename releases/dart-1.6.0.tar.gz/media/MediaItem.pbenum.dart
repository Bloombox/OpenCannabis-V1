///
//  Generated code. Do not modify.
//  source: media/MediaItem.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class MediaStatus extends $pb.ProtobufEnum {
  static const MediaStatus PROVISIONED = MediaStatus._(0, 'PROVISIONED');
  static const MediaStatus PENDING = MediaStatus._(1, 'PENDING');
  static const MediaStatus UPLOADED = MediaStatus._(2, 'UPLOADED');
  static const MediaStatus READY = MediaStatus._(3, 'READY');

  static const $core.List<MediaStatus> values = <MediaStatus> [
    PROVISIONED,
    PENDING,
    UPLOADED,
    READY,
  ];

  static final $core.Map<$core.int, MediaStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaStatus valueOf($core.int value) => _byValue[value];

  const MediaStatus._($core.int v, $core.String n) : super(v, n);
}

class MediaPrivacy extends $pb.ProtobufEnum {
  static const MediaPrivacy DEFAULT_PRIVACY = MediaPrivacy._(0, 'DEFAULT_PRIVACY');
  static const MediaPrivacy PARTNER = MediaPrivacy._(1, 'PARTNER');
  static const MediaPrivacy PUBLIC = MediaPrivacy._(2, 'PUBLIC');

  static const $core.List<MediaPrivacy> values = <MediaPrivacy> [
    DEFAULT_PRIVACY,
    PARTNER,
    PUBLIC,
  ];

  static final $core.Map<$core.int, MediaPrivacy> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaPrivacy valueOf($core.int value) => _byValue[value];

  const MediaPrivacy._($core.int v, $core.String n) : super(v, n);
}

