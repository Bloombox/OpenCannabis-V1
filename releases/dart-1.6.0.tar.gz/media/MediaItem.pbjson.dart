///
//  Generated code. Do not modify.
//  source: media/MediaItem.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MediaStatus$json = const {
  '1': 'MediaStatus',
  '2': const [
    const {'1': 'PROVISIONED', '2': 0},
    const {'1': 'PENDING', '2': 1},
    const {'1': 'UPLOADED', '2': 2},
    const {'1': 'READY', '2': 3},
  ],
};

const MediaPrivacy$json = const {
  '1': 'MediaPrivacy',
  '2': const [
    const {'1': 'DEFAULT_PRIVACY', '2': 0},
    const {'1': 'PARTNER', '2': 1},
    const {'1': 'PUBLIC', '2': 2},
  ],
};

const MediaSubject$json = const {
  '1': 'MediaSubject',
  '2': const [
    const {'1': 'product', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '9': 0, '10': 'product'},
    const {'1': 'partner', '3': 3, '4': 1, '5': 9, '9': 0, '10': 'partner'},
    const {'1': 'location', '3': 4, '4': 1, '5': 9, '9': 0, '10': 'location'},
    const {'1': 'global', '3': 5, '4': 1, '5': 8, '9': 0, '10': 'global'},
  ],
  '8': const [
    const {'1': 'attachment'},
  ],
};

const MediaUpload$json = const {
  '1': 'MediaUpload',
  '2': const [
    const {'1': 'token', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'token'},
    const {'1': 'operation', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'operation'},
    const {'1': 'media', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '8': const {}, '10': 'media'},
    const {'1': 'mime', '3': 4, '4': 1, '5': 9, '8': const {}, '10': 'mime'},
    const {'1': 'size', '3': 5, '4': 1, '5': 4, '8': const {}, '10': 'size'},
    const {'1': 'finished', '3': 6, '4': 1, '5': 8, '8': const {}, '10': 'finished'},
    const {'1': 'md5', '3': 7, '4': 1, '5': 9, '8': const {}, '10': 'md5'},
    const {'1': 'crc32', '3': 8, '4': 1, '5': 9, '8': const {}, '10': 'crc32'},
    const {'1': 'owner', '3': 9, '4': 1, '5': 9, '8': const {}, '10': 'owner'},
    const {'1': 'path', '3': 10, '4': 1, '5': 9, '8': const {}, '10': 'path'},
    const {'1': 'parent', '3': 11, '4': 1, '5': 9, '8': const {}, '10': 'parent'},
    const {'1': 'created', '3': 20, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'created'},
    const {'1': 'completed', '3': 21, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'completed'},
  ],
  '7': const {},
};

const MediaItem$json = const {
  '1': 'MediaItem',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.media.MediaKey', '8': const {}, '10': 'key'},
    const {'1': 'status', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.media.MediaStatus', '8': const {}, '10': 'status'},
    const {'1': 'type', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.media.MediaType', '8': const {}, '10': 'type'},
    const {'1': 'name', '3': 4, '4': 1, '5': 9, '8': const {}, '10': 'name'},
    const {'1': 'uri', '3': 5, '4': 1, '5': 9, '8': const {}, '10': 'uri'},
    const {'1': 'serving_uri', '3': 6, '4': 1, '5': 9, '8': const {}, '10': 'servingUri'},
    const {'1': 'privacy', '3': 7, '4': 1, '5': 14, '6': '.opencannabis.media.MediaPrivacy', '8': const {}, '10': 'privacy'},
    const {'1': 'created', '3': 8, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'created'},
    const {'1': 'modified', '3': 9, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'modified'},
    const {'1': 'published', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'published'},
    const {'1': 'scope', '3': 11, '4': 1, '5': 9, '8': const {}, '10': 'scope'},
    const {'1': 'token', '3': 12, '4': 1, '5': 9, '8': const {}, '10': 'token'},
  ],
  '7': const {},
};

