///
//  Generated code. Do not modify.
//  source: media/MediaType.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MediaType$json = const {
  '1': 'MediaType',
  '2': const [
    const {'1': 'kind', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.media.MediaType.Kind', '8': const {}, '10': 'kind'},
    const {'1': 'image_type', '3': 101, '4': 1, '5': 14, '6': '.opencannabis.media.MediaType.ImageKind', '8': const {}, '9': 0, '10': 'imageType'},
    const {'1': 'document_type', '3': 201, '4': 1, '5': 14, '6': '.opencannabis.media.MediaType.DocumentKind', '8': const {}, '9': 0, '10': 'documentType'},
    const {'1': 'video_type', '3': 301, '4': 1, '5': 14, '6': '.opencannabis.media.MediaType.VideoKind', '8': const {}, '9': 0, '10': 'videoType'},
  ],
  '4': const [MediaType_Kind$json, MediaType_ImageKind$json, MediaType_ImageDPI$json, MediaType_DocumentKind$json, MediaType_VideoKind$json],
  '8': const [
    const {'1': 'content'},
  ],
};

const MediaType_Kind$json = const {
  '1': 'Kind',
  '2': const [
    const {'1': 'LINK', '2': 0},
    const {'1': 'IMAGE', '2': 1},
    const {'1': 'DOCUMENT', '2': 2},
    const {'1': 'VIDEO', '2': 3},
  ],
};

const MediaType_ImageKind$json = const {
  '1': 'ImageKind',
  '2': const [
    const {'1': 'UNSPECIFIED_IMAGE_TYPE', '2': 0},
    const {'1': 'PNG', '2': 1},
    const {'1': 'JPG', '2': 2},
    const {'1': 'GIF', '2': 3},
    const {'1': 'SVG', '2': 4},
    const {'1': 'WEBP', '2': 5},
  ],
};

const MediaType_ImageDPI$json = const {
  '1': 'ImageDPI',
  '2': const [
    const {'1': 'X1', '2': 0},
    const {'1': 'X2', '2': 1},
    const {'1': 'X3', '2': 2},
  ],
};

const MediaType_DocumentKind$json = const {
  '1': 'DocumentKind',
  '2': const [
    const {'1': 'UNSPECIFIED_DOCUMENT_TYPE', '2': 0},
    const {'1': 'TXT', '2': 1},
    const {'1': 'HTML', '2': 2},
    const {'1': 'PDF', '2': 3},
    const {'1': 'MARKDOWN', '2': 4},
  ],
};

const MediaType_VideoKind$json = const {
  '1': 'VideoKind',
  '2': const [
    const {'1': 'UNSPECIFIED_VIDEO_TYPE', '2': 0},
    const {'1': 'MP4', '2': 1},
    const {'1': 'FLV', '2': 2},
    const {'1': 'HLS', '2': 3},
  ],
};

