///
//  Generated code. Do not modify.
//  source: media/MediaType.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class MediaType_Kind extends $pb.ProtobufEnum {
  static const MediaType_Kind LINK = MediaType_Kind._(0, 'LINK');
  static const MediaType_Kind IMAGE = MediaType_Kind._(1, 'IMAGE');
  static const MediaType_Kind DOCUMENT = MediaType_Kind._(2, 'DOCUMENT');
  static const MediaType_Kind VIDEO = MediaType_Kind._(3, 'VIDEO');

  static const $core.List<MediaType_Kind> values = <MediaType_Kind> [
    LINK,
    IMAGE,
    DOCUMENT,
    VIDEO,
  ];

  static final $core.Map<$core.int, MediaType_Kind> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaType_Kind valueOf($core.int value) => _byValue[value];

  const MediaType_Kind._($core.int v, $core.String n) : super(v, n);
}

class MediaType_ImageKind extends $pb.ProtobufEnum {
  static const MediaType_ImageKind UNSPECIFIED_IMAGE_TYPE = MediaType_ImageKind._(0, 'UNSPECIFIED_IMAGE_TYPE');
  static const MediaType_ImageKind PNG = MediaType_ImageKind._(1, 'PNG');
  static const MediaType_ImageKind JPG = MediaType_ImageKind._(2, 'JPG');
  static const MediaType_ImageKind GIF = MediaType_ImageKind._(3, 'GIF');
  static const MediaType_ImageKind SVG = MediaType_ImageKind._(4, 'SVG');
  static const MediaType_ImageKind WEBP = MediaType_ImageKind._(5, 'WEBP');

  static const $core.List<MediaType_ImageKind> values = <MediaType_ImageKind> [
    UNSPECIFIED_IMAGE_TYPE,
    PNG,
    JPG,
    GIF,
    SVG,
    WEBP,
  ];

  static final $core.Map<$core.int, MediaType_ImageKind> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaType_ImageKind valueOf($core.int value) => _byValue[value];

  const MediaType_ImageKind._($core.int v, $core.String n) : super(v, n);
}

class MediaType_ImageDPI extends $pb.ProtobufEnum {
  static const MediaType_ImageDPI X1 = MediaType_ImageDPI._(0, 'X1');
  static const MediaType_ImageDPI X2 = MediaType_ImageDPI._(1, 'X2');
  static const MediaType_ImageDPI X3 = MediaType_ImageDPI._(2, 'X3');

  static const $core.List<MediaType_ImageDPI> values = <MediaType_ImageDPI> [
    X1,
    X2,
    X3,
  ];

  static final $core.Map<$core.int, MediaType_ImageDPI> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaType_ImageDPI valueOf($core.int value) => _byValue[value];

  const MediaType_ImageDPI._($core.int v, $core.String n) : super(v, n);
}

class MediaType_DocumentKind extends $pb.ProtobufEnum {
  static const MediaType_DocumentKind UNSPECIFIED_DOCUMENT_TYPE = MediaType_DocumentKind._(0, 'UNSPECIFIED_DOCUMENT_TYPE');
  static const MediaType_DocumentKind TXT = MediaType_DocumentKind._(1, 'TXT');
  static const MediaType_DocumentKind HTML = MediaType_DocumentKind._(2, 'HTML');
  static const MediaType_DocumentKind PDF = MediaType_DocumentKind._(3, 'PDF');
  static const MediaType_DocumentKind MARKDOWN = MediaType_DocumentKind._(4, 'MARKDOWN');

  static const $core.List<MediaType_DocumentKind> values = <MediaType_DocumentKind> [
    UNSPECIFIED_DOCUMENT_TYPE,
    TXT,
    HTML,
    PDF,
    MARKDOWN,
  ];

  static final $core.Map<$core.int, MediaType_DocumentKind> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaType_DocumentKind valueOf($core.int value) => _byValue[value];

  const MediaType_DocumentKind._($core.int v, $core.String n) : super(v, n);
}

class MediaType_VideoKind extends $pb.ProtobufEnum {
  static const MediaType_VideoKind UNSPECIFIED_VIDEO_TYPE = MediaType_VideoKind._(0, 'UNSPECIFIED_VIDEO_TYPE');
  static const MediaType_VideoKind MP4 = MediaType_VideoKind._(1, 'MP4');
  static const MediaType_VideoKind FLV = MediaType_VideoKind._(2, 'FLV');
  static const MediaType_VideoKind HLS = MediaType_VideoKind._(3, 'HLS');

  static const $core.List<MediaType_VideoKind> values = <MediaType_VideoKind> [
    UNSPECIFIED_VIDEO_TYPE,
    MP4,
    FLV,
    HLS,
  ];

  static final $core.Map<$core.int, MediaType_VideoKind> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaType_VideoKind valueOf($core.int value) => _byValue[value];

  const MediaType_VideoKind._($core.int v, $core.String n) : super(v, n);
}

