///
//  Generated code. Do not modify.
//  source: media/MediaItem.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;
import '../temporal/Instant.pb.dart' as $0;
import 'MediaKey.pb.dart' as $28;
import 'MediaType.pb.dart' as $26;

import 'MediaItem.pbenum.dart';

export 'MediaItem.pbenum.dart';

enum MediaSubject_Attachment {
  product, 
  partner, 
  location, 
  global, 
  notSet
}

class MediaSubject extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, MediaSubject_Attachment> _MediaSubject_AttachmentByTag = {
    2 : MediaSubject_Attachment.product,
    3 : MediaSubject_Attachment.partner,
    4 : MediaSubject_Attachment.location,
    5 : MediaSubject_Attachment.global,
    0 : MediaSubject_Attachment.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaSubject', package: const $pb.PackageName('opencannabis.media'))
    ..a<$17.ProductKey>(2, 'product', $pb.PbFieldType.OM, $17.ProductKey.getDefault, $17.ProductKey.create)
    ..aOS(3, 'partner')
    ..aOS(4, 'location')
    ..aOB(5, 'global')
    ..oo(0, [2, 3, 4, 5])
    ..hasRequiredFields = false
  ;

  MediaSubject() : super();
  MediaSubject.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaSubject.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaSubject clone() => MediaSubject()..mergeFromMessage(this);
  MediaSubject copyWith(void Function(MediaSubject) updates) => super.copyWith((message) => updates(message as MediaSubject));
  $pb.BuilderInfo get info_ => _i;
  static MediaSubject create() => MediaSubject();
  MediaSubject createEmptyInstance() => create();
  static $pb.PbList<MediaSubject> createRepeated() => $pb.PbList<MediaSubject>();
  static MediaSubject getDefault() => _defaultInstance ??= create()..freeze();
  static MediaSubject _defaultInstance;

  MediaSubject_Attachment whichAttachment() => _MediaSubject_AttachmentByTag[$_whichOneof(0)];
  void clearAttachment() => clearField($_whichOneof(0));

  $17.ProductKey get product => $_getN(0);
  set product($17.ProductKey v) { setField(2, v); }
  $core.bool hasProduct() => $_has(0);
  void clearProduct() => clearField(2);

  $core.String get partner => $_getS(1, '');
  set partner($core.String v) { $_setString(1, v); }
  $core.bool hasPartner() => $_has(1);
  void clearPartner() => clearField(3);

  $core.String get location => $_getS(2, '');
  set location($core.String v) { $_setString(2, v); }
  $core.bool hasLocation() => $_has(2);
  void clearLocation() => clearField(4);

  $core.bool get global => $_get(3, false);
  set global($core.bool v) { $_setBool(3, v); }
  $core.bool hasGlobal() => $_has(3);
  void clearGlobal() => clearField(5);
}

class MediaUpload extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaUpload', package: const $pb.PackageName('opencannabis.media'))
    ..aOS(1, 'token')
    ..aOS(2, 'operation')
    ..a<MediaItem>(3, 'media', $pb.PbFieldType.OM, MediaItem.getDefault, MediaItem.create)
    ..aOS(4, 'mime')
    ..a<Int64>(5, 'size', $pb.PbFieldType.OU6, Int64.ZERO)
    ..aOB(6, 'finished')
    ..aOS(7, 'md5')
    ..aOS(8, 'crc32')
    ..aOS(9, 'owner')
    ..aOS(10, 'path')
    ..aOS(11, 'parent')
    ..a<$0.Instant>(20, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(21, 'completed', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  MediaUpload() : super();
  MediaUpload.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaUpload.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaUpload clone() => MediaUpload()..mergeFromMessage(this);
  MediaUpload copyWith(void Function(MediaUpload) updates) => super.copyWith((message) => updates(message as MediaUpload));
  $pb.BuilderInfo get info_ => _i;
  static MediaUpload create() => MediaUpload();
  MediaUpload createEmptyInstance() => create();
  static $pb.PbList<MediaUpload> createRepeated() => $pb.PbList<MediaUpload>();
  static MediaUpload getDefault() => _defaultInstance ??= create()..freeze();
  static MediaUpload _defaultInstance;

  $core.String get token => $_getS(0, '');
  set token($core.String v) { $_setString(0, v); }
  $core.bool hasToken() => $_has(0);
  void clearToken() => clearField(1);

  $core.String get operation => $_getS(1, '');
  set operation($core.String v) { $_setString(1, v); }
  $core.bool hasOperation() => $_has(1);
  void clearOperation() => clearField(2);

  MediaItem get media => $_getN(2);
  set media(MediaItem v) { setField(3, v); }
  $core.bool hasMedia() => $_has(2);
  void clearMedia() => clearField(3);

  $core.String get mime => $_getS(3, '');
  set mime($core.String v) { $_setString(3, v); }
  $core.bool hasMime() => $_has(3);
  void clearMime() => clearField(4);

  Int64 get size => $_getI64(4);
  set size(Int64 v) { $_setInt64(4, v); }
  $core.bool hasSize() => $_has(4);
  void clearSize() => clearField(5);

  $core.bool get finished => $_get(5, false);
  set finished($core.bool v) { $_setBool(5, v); }
  $core.bool hasFinished() => $_has(5);
  void clearFinished() => clearField(6);

  $core.String get md5 => $_getS(6, '');
  set md5($core.String v) { $_setString(6, v); }
  $core.bool hasMd5() => $_has(6);
  void clearMd5() => clearField(7);

  $core.String get crc32 => $_getS(7, '');
  set crc32($core.String v) { $_setString(7, v); }
  $core.bool hasCrc32() => $_has(7);
  void clearCrc32() => clearField(8);

  $core.String get owner => $_getS(8, '');
  set owner($core.String v) { $_setString(8, v); }
  $core.bool hasOwner() => $_has(8);
  void clearOwner() => clearField(9);

  $core.String get path => $_getS(9, '');
  set path($core.String v) { $_setString(9, v); }
  $core.bool hasPath() => $_has(9);
  void clearPath() => clearField(10);

  $core.String get parent => $_getS(10, '');
  set parent($core.String v) { $_setString(10, v); }
  $core.bool hasParent() => $_has(10);
  void clearParent() => clearField(11);

  $0.Instant get created => $_getN(11);
  set created($0.Instant v) { setField(20, v); }
  $core.bool hasCreated() => $_has(11);
  void clearCreated() => clearField(20);

  $0.Instant get completed => $_getN(12);
  set completed($0.Instant v) { setField(21, v); }
  $core.bool hasCompleted() => $_has(12);
  void clearCompleted() => clearField(21);
}

class MediaItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaItem', package: const $pb.PackageName('opencannabis.media'))
    ..a<$28.MediaKey>(1, 'key', $pb.PbFieldType.OM, $28.MediaKey.getDefault, $28.MediaKey.create)
    ..e<MediaStatus>(2, 'status', $pb.PbFieldType.OE, MediaStatus.PROVISIONED, MediaStatus.valueOf, MediaStatus.values)
    ..a<$26.MediaType>(3, 'type', $pb.PbFieldType.OM, $26.MediaType.getDefault, $26.MediaType.create)
    ..aOS(4, 'name')
    ..aOS(5, 'uri')
    ..aOS(6, 'servingUri')
    ..e<MediaPrivacy>(7, 'privacy', $pb.PbFieldType.OE, MediaPrivacy.DEFAULT_PRIVACY, MediaPrivacy.valueOf, MediaPrivacy.values)
    ..a<$0.Instant>(8, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(9, 'modified', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(10, 'published', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..aOS(11, 'scope')
    ..aOS(12, 'token')
    ..hasRequiredFields = false
  ;

  MediaItem() : super();
  MediaItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaItem clone() => MediaItem()..mergeFromMessage(this);
  MediaItem copyWith(void Function(MediaItem) updates) => super.copyWith((message) => updates(message as MediaItem));
  $pb.BuilderInfo get info_ => _i;
  static MediaItem create() => MediaItem();
  MediaItem createEmptyInstance() => create();
  static $pb.PbList<MediaItem> createRepeated() => $pb.PbList<MediaItem>();
  static MediaItem getDefault() => _defaultInstance ??= create()..freeze();
  static MediaItem _defaultInstance;

  $28.MediaKey get key => $_getN(0);
  set key($28.MediaKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  MediaStatus get status => $_getN(1);
  set status(MediaStatus v) { setField(2, v); }
  $core.bool hasStatus() => $_has(1);
  void clearStatus() => clearField(2);

  $26.MediaType get type => $_getN(2);
  set type($26.MediaType v) { setField(3, v); }
  $core.bool hasType() => $_has(2);
  void clearType() => clearField(3);

  $core.String get name => $_getS(3, '');
  set name($core.String v) { $_setString(3, v); }
  $core.bool hasName() => $_has(3);
  void clearName() => clearField(4);

  $core.String get uri => $_getS(4, '');
  set uri($core.String v) { $_setString(4, v); }
  $core.bool hasUri() => $_has(4);
  void clearUri() => clearField(5);

  $core.String get servingUri => $_getS(5, '');
  set servingUri($core.String v) { $_setString(5, v); }
  $core.bool hasServingUri() => $_has(5);
  void clearServingUri() => clearField(6);

  MediaPrivacy get privacy => $_getN(6);
  set privacy(MediaPrivacy v) { setField(7, v); }
  $core.bool hasPrivacy() => $_has(6);
  void clearPrivacy() => clearField(7);

  $0.Instant get created => $_getN(7);
  set created($0.Instant v) { setField(8, v); }
  $core.bool hasCreated() => $_has(7);
  void clearCreated() => clearField(8);

  $0.Instant get modified => $_getN(8);
  set modified($0.Instant v) { setField(9, v); }
  $core.bool hasModified() => $_has(8);
  void clearModified() => clearField(9);

  $0.Instant get published => $_getN(9);
  set published($0.Instant v) { setField(10, v); }
  $core.bool hasPublished() => $_has(9);
  void clearPublished() => clearField(10);

  $core.String get scope => $_getS(10, '');
  set scope($core.String v) { $_setString(10, v); }
  $core.bool hasScope() => $_has(10);
  void clearScope() => clearField(11);

  $core.String get token => $_getS(11, '');
  set token($core.String v) { $_setString(11, v); }
  $core.bool hasToken() => $_has(11);
  void clearToken() => clearField(12);
}

