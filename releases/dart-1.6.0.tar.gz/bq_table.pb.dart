///
//  Generated code. Do not modify.
//  source: bq_table.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Bq_table {
  static final $pb.Extension tableName = $pb.Extension<$core.String>('google.protobuf.MessageOptions', 'tableName', 1021, $pb.PbFieldType.OS);
  static final $pb.Extension tableDescription = $pb.Extension<$core.String>('google.protobuf.MessageOptions', 'tableDescription', 1026, $pb.PbFieldType.OS);
  static void registerAllExtensions($pb.ExtensionRegistry registry) {
    registry.add(tableName);
    registry.add(tableDescription);
  }
}

