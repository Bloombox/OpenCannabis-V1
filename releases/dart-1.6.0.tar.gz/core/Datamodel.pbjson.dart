///
//  Generated code. Do not modify.
//  source: core/Datamodel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Visibility$json = const {
  '1': 'Visibility',
  '2': const [
    const {'1': 'PUBLIC', '2': 0},
    const {'1': 'PRIVATE', '2': 1},
    const {'1': 'PROTECTED', '2': 2},
    const {'1': 'PACKAGE', '2': 3},
    const {'1': 'EXPORT', '2': 4},
  ],
};

const CollectionMode$json = const {
  '1': 'CollectionMode',
  '2': const [
    const {'1': 'NESTED', '2': 0},
    const {'1': 'COLLECTION', '2': 1},
    const {'1': 'GROUP', '2': 2},
  ],
};

const FieldType$json = const {
  '1': 'FieldType',
  '2': const [
    const {'1': 'STANDARD', '2': 0},
    const {'1': 'KEY', '2': 1},
    const {'1': 'ID', '2': 2},
    const {'1': 'TAGS', '2': 3},
    const {'1': 'FLAGS', '2': 4},
  ],
};

const DatapointOptions$json = const {
  '1': 'DatapointOptions',
  '2': const [
    const {'1': 'visibility', '3': 1, '4': 1, '5': 14, '6': '.core.Visibility', '10': 'visibility'},
    const {'1': 'required', '3': 2, '4': 1, '5': 8, '10': 'required'},
  ],
};

const PersistenceOptions$json = const {
  '1': 'PersistenceOptions',
  '2': const [
    const {'1': 'mode', '3': 1, '4': 1, '5': 14, '6': '.core.CollectionMode', '10': 'mode'},
    const {'1': 'path', '3': 2, '4': 1, '5': 9, '10': 'path'},
  ],
};

const TableOptions$json = const {
  '1': 'TableOptions',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 9, '10': 'name'},
    const {'1': 'description', '3': 2, '4': 1, '5': 9, '10': 'description'},
  ],
};

const SubmessageOptions$json = const {
  '1': 'SubmessageOptions',
  '2': const [
    const {'1': 'mode', '3': 1, '4': 1, '5': 14, '6': '.core.CollectionMode', '10': 'mode'},
    const {'1': 'path', '3': 3, '4': 1, '5': 9, '10': 'path'},
  ],
};

const FieldPersistenceOptions$json = const {
  '1': 'FieldPersistenceOptions',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.core.FieldType', '10': 'type'},
    const {'1': 'description', '3': 2, '4': 1, '5': 9, '10': 'description'},
  ],
};

const TableFieldOptions$json = const {
  '1': 'TableFieldOptions',
  '2': const [
    const {'1': 'require', '3': 1, '4': 1, '5': 8, '10': 'require'},
    const {'1': 'ignore', '3': 2, '4': 1, '5': 8, '10': 'ignore'},
    const {'1': 'bqtype', '3': 3, '4': 1, '5': 9, '10': 'bqtype'},
  ],
};

const ObjectMapping$json = const {
  '1': 'ObjectMapping',
  '2': const [
    const {'1': 'instance', '3': 1, '4': 3, '5': 9, '10': 'instance'},
  ],
};

