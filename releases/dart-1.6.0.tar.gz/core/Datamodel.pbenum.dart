///
//  Generated code. Do not modify.
//  source: core/Datamodel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Visibility extends $pb.ProtobufEnum {
  static const Visibility PUBLIC = Visibility._(0, 'PUBLIC');
  static const Visibility PRIVATE = Visibility._(1, 'PRIVATE');
  static const Visibility PROTECTED = Visibility._(2, 'PROTECTED');
  static const Visibility PACKAGE = Visibility._(3, 'PACKAGE');
  static const Visibility EXPORT = Visibility._(4, 'EXPORT');

  static const $core.List<Visibility> values = <Visibility> [
    PUBLIC,
    PRIVATE,
    PROTECTED,
    PACKAGE,
    EXPORT,
  ];

  static final $core.Map<$core.int, Visibility> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Visibility valueOf($core.int value) => _byValue[value];

  const Visibility._($core.int v, $core.String n) : super(v, n);
}

class CollectionMode extends $pb.ProtobufEnum {
  static const CollectionMode NESTED = CollectionMode._(0, 'NESTED');
  static const CollectionMode COLLECTION = CollectionMode._(1, 'COLLECTION');
  static const CollectionMode GROUP = CollectionMode._(2, 'GROUP');

  static const $core.List<CollectionMode> values = <CollectionMode> [
    NESTED,
    COLLECTION,
    GROUP,
  ];

  static final $core.Map<$core.int, CollectionMode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CollectionMode valueOf($core.int value) => _byValue[value];

  const CollectionMode._($core.int v, $core.String n) : super(v, n);
}

class FieldType extends $pb.ProtobufEnum {
  static const FieldType STANDARD = FieldType._(0, 'STANDARD');
  static const FieldType KEY = FieldType._(1, 'KEY');
  static const FieldType ID = FieldType._(2, 'ID');
  static const FieldType TAGS = FieldType._(3, 'TAGS');
  static const FieldType FLAGS = FieldType._(4, 'FLAGS');

  static const $core.List<FieldType> values = <FieldType> [
    STANDARD,
    KEY,
    ID,
    TAGS,
    FLAGS,
  ];

  static final $core.Map<$core.int, FieldType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static FieldType valueOf($core.int value) => _byValue[value];

  const FieldType._($core.int v, $core.String n) : super(v, n);
}

