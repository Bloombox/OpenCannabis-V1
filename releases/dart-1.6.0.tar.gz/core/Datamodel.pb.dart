///
//  Generated code. Do not modify.
//  source: core/Datamodel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../content/Colors.pb.dart' as $13;

import 'Datamodel.pbenum.dart';

export 'Datamodel.pbenum.dart';

class DatapointOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DatapointOptions', package: const $pb.PackageName('core'))
    ..e<Visibility>(1, 'visibility', $pb.PbFieldType.OE, Visibility.PUBLIC, Visibility.valueOf, Visibility.values)
    ..aOB(2, 'required')
    ..hasRequiredFields = false
  ;

  DatapointOptions() : super();
  DatapointOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DatapointOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DatapointOptions clone() => DatapointOptions()..mergeFromMessage(this);
  DatapointOptions copyWith(void Function(DatapointOptions) updates) => super.copyWith((message) => updates(message as DatapointOptions));
  $pb.BuilderInfo get info_ => _i;
  static DatapointOptions create() => DatapointOptions();
  DatapointOptions createEmptyInstance() => create();
  static $pb.PbList<DatapointOptions> createRepeated() => $pb.PbList<DatapointOptions>();
  static DatapointOptions getDefault() => _defaultInstance ??= create()..freeze();
  static DatapointOptions _defaultInstance;

  Visibility get visibility => $_getN(0);
  set visibility(Visibility v) { setField(1, v); }
  $core.bool hasVisibility() => $_has(0);
  void clearVisibility() => clearField(1);

  $core.bool get required => $_get(1, false);
  set required($core.bool v) { $_setBool(1, v); }
  $core.bool hasRequired() => $_has(1);
  void clearRequired() => clearField(2);
}

class PersistenceOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PersistenceOptions', package: const $pb.PackageName('core'))
    ..e<CollectionMode>(1, 'mode', $pb.PbFieldType.OE, CollectionMode.NESTED, CollectionMode.valueOf, CollectionMode.values)
    ..aOS(2, 'path')
    ..hasRequiredFields = false
  ;

  PersistenceOptions() : super();
  PersistenceOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PersistenceOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PersistenceOptions clone() => PersistenceOptions()..mergeFromMessage(this);
  PersistenceOptions copyWith(void Function(PersistenceOptions) updates) => super.copyWith((message) => updates(message as PersistenceOptions));
  $pb.BuilderInfo get info_ => _i;
  static PersistenceOptions create() => PersistenceOptions();
  PersistenceOptions createEmptyInstance() => create();
  static $pb.PbList<PersistenceOptions> createRepeated() => $pb.PbList<PersistenceOptions>();
  static PersistenceOptions getDefault() => _defaultInstance ??= create()..freeze();
  static PersistenceOptions _defaultInstance;

  CollectionMode get mode => $_getN(0);
  set mode(CollectionMode v) { setField(1, v); }
  $core.bool hasMode() => $_has(0);
  void clearMode() => clearField(1);

  $core.String get path => $_getS(1, '');
  set path($core.String v) { $_setString(1, v); }
  $core.bool hasPath() => $_has(1);
  void clearPath() => clearField(2);
}

class TableOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TableOptions', package: const $pb.PackageName('core'))
    ..aOS(1, 'name')
    ..aOS(2, 'description')
    ..hasRequiredFields = false
  ;

  TableOptions() : super();
  TableOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TableOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TableOptions clone() => TableOptions()..mergeFromMessage(this);
  TableOptions copyWith(void Function(TableOptions) updates) => super.copyWith((message) => updates(message as TableOptions));
  $pb.BuilderInfo get info_ => _i;
  static TableOptions create() => TableOptions();
  TableOptions createEmptyInstance() => create();
  static $pb.PbList<TableOptions> createRepeated() => $pb.PbList<TableOptions>();
  static TableOptions getDefault() => _defaultInstance ??= create()..freeze();
  static TableOptions _defaultInstance;

  $core.String get name => $_getS(0, '');
  set name($core.String v) { $_setString(0, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(2);
}

class SubmessageOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SubmessageOptions', package: const $pb.PackageName('core'))
    ..e<CollectionMode>(1, 'mode', $pb.PbFieldType.OE, CollectionMode.NESTED, CollectionMode.valueOf, CollectionMode.values)
    ..aOS(3, 'path')
    ..hasRequiredFields = false
  ;

  SubmessageOptions() : super();
  SubmessageOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SubmessageOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SubmessageOptions clone() => SubmessageOptions()..mergeFromMessage(this);
  SubmessageOptions copyWith(void Function(SubmessageOptions) updates) => super.copyWith((message) => updates(message as SubmessageOptions));
  $pb.BuilderInfo get info_ => _i;
  static SubmessageOptions create() => SubmessageOptions();
  SubmessageOptions createEmptyInstance() => create();
  static $pb.PbList<SubmessageOptions> createRepeated() => $pb.PbList<SubmessageOptions>();
  static SubmessageOptions getDefault() => _defaultInstance ??= create()..freeze();
  static SubmessageOptions _defaultInstance;

  CollectionMode get mode => $_getN(0);
  set mode(CollectionMode v) { setField(1, v); }
  $core.bool hasMode() => $_has(0);
  void clearMode() => clearField(1);

  $core.String get path => $_getS(1, '');
  set path($core.String v) { $_setString(1, v); }
  $core.bool hasPath() => $_has(1);
  void clearPath() => clearField(3);
}

class FieldPersistenceOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('FieldPersistenceOptions', package: const $pb.PackageName('core'))
    ..e<FieldType>(1, 'type', $pb.PbFieldType.OE, FieldType.STANDARD, FieldType.valueOf, FieldType.values)
    ..aOS(2, 'description')
    ..hasRequiredFields = false
  ;

  FieldPersistenceOptions() : super();
  FieldPersistenceOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  FieldPersistenceOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  FieldPersistenceOptions clone() => FieldPersistenceOptions()..mergeFromMessage(this);
  FieldPersistenceOptions copyWith(void Function(FieldPersistenceOptions) updates) => super.copyWith((message) => updates(message as FieldPersistenceOptions));
  $pb.BuilderInfo get info_ => _i;
  static FieldPersistenceOptions create() => FieldPersistenceOptions();
  FieldPersistenceOptions createEmptyInstance() => create();
  static $pb.PbList<FieldPersistenceOptions> createRepeated() => $pb.PbList<FieldPersistenceOptions>();
  static FieldPersistenceOptions getDefault() => _defaultInstance ??= create()..freeze();
  static FieldPersistenceOptions _defaultInstance;

  FieldType get type => $_getN(0);
  set type(FieldType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(2);
}

class TableFieldOptions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TableFieldOptions', package: const $pb.PackageName('core'))
    ..aOB(1, 'require')
    ..aOB(2, 'ignore')
    ..aOS(3, 'bqtype')
    ..hasRequiredFields = false
  ;

  TableFieldOptions() : super();
  TableFieldOptions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TableFieldOptions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TableFieldOptions clone() => TableFieldOptions()..mergeFromMessage(this);
  TableFieldOptions copyWith(void Function(TableFieldOptions) updates) => super.copyWith((message) => updates(message as TableFieldOptions));
  $pb.BuilderInfo get info_ => _i;
  static TableFieldOptions create() => TableFieldOptions();
  TableFieldOptions createEmptyInstance() => create();
  static $pb.PbList<TableFieldOptions> createRepeated() => $pb.PbList<TableFieldOptions>();
  static TableFieldOptions getDefault() => _defaultInstance ??= create()..freeze();
  static TableFieldOptions _defaultInstance;

  $core.bool get require => $_get(0, false);
  set require($core.bool v) { $_setBool(0, v); }
  $core.bool hasRequire() => $_has(0);
  void clearRequire() => clearField(1);

  $core.bool get ignore => $_get(1, false);
  set ignore($core.bool v) { $_setBool(1, v); }
  $core.bool hasIgnore() => $_has(1);
  void clearIgnore() => clearField(2);

  $core.String get bqtype => $_getS(2, '');
  set bqtype($core.String v) { $_setString(2, v); }
  $core.bool hasBqtype() => $_has(2);
  void clearBqtype() => clearField(3);
}

class ObjectMapping extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ObjectMapping', package: const $pb.PackageName('core'))
    ..pPS(1, 'instance')
    ..hasRequiredFields = false
  ;

  ObjectMapping() : super();
  ObjectMapping.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ObjectMapping.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ObjectMapping clone() => ObjectMapping()..mergeFromMessage(this);
  ObjectMapping copyWith(void Function(ObjectMapping) updates) => super.copyWith((message) => updates(message as ObjectMapping));
  $pb.BuilderInfo get info_ => _i;
  static ObjectMapping create() => ObjectMapping();
  ObjectMapping createEmptyInstance() => create();
  static $pb.PbList<ObjectMapping> createRepeated() => $pb.PbList<ObjectMapping>();
  static ObjectMapping getDefault() => _defaultInstance ??= create()..freeze();
  static ObjectMapping _defaultInstance;

  $core.List<$core.String> get instance => $_getList(0);
}

class Datamodel {
  static final $pb.Extension db = $pb.Extension<PersistenceOptions>('google.protobuf.MessageOptions', 'db', 6000, $pb.PbFieldType.OM, PersistenceOptions.getDefault, PersistenceOptions.create);
  static final $pb.Extension table = $pb.Extension<TableOptions>('google.protobuf.MessageOptions', 'table', 6001, $pb.PbFieldType.OM, TableOptions.getDefault, TableOptions.create);
  static final $pb.Extension map = $pb.Extension<ObjectMapping>('google.protobuf.MessageOptions', 'map', 6002, $pb.PbFieldType.OM, ObjectMapping.getDefault, ObjectMapping.create);
  static final $pb.Extension msg = $pb.Extension<DatapointOptions>('google.protobuf.MessageOptions', 'msg', 6003, $pb.PbFieldType.OM, DatapointOptions.getDefault, DatapointOptions.create);
  static final $pb.Extension field = $pb.Extension<FieldPersistenceOptions>('google.protobuf.FieldOptions', 'field', 7000, $pb.PbFieldType.OM, FieldPersistenceOptions.getDefault, FieldPersistenceOptions.create);
  static final $pb.Extension column = $pb.Extension<TableFieldOptions>('google.protobuf.FieldOptions', 'column', 7001, $pb.PbFieldType.OM, TableFieldOptions.getDefault, TableFieldOptions.create);
  static final $pb.Extension collection = $pb.Extension<SubmessageOptions>('google.protobuf.FieldOptions', 'collection', 7002, $pb.PbFieldType.OM, SubmessageOptions.getDefault, SubmessageOptions.create);
  static final $pb.Extension opts = $pb.Extension<DatapointOptions>('google.protobuf.FieldOptions', 'opts', 7003, $pb.PbFieldType.OM, DatapointOptions.getDefault, DatapointOptions.create);
  static final $pb.Extension label = $pb.Extension<$core.String>('google.protobuf.EnumValueOptions', 'label', 8003, $pb.PbFieldType.OS);
  static final $pb.Extension color = $pb.Extension<$13.Color>('google.protobuf.EnumValueOptions', 'color', 8004, $pb.PbFieldType.OM, $13.Color.getDefault, $13.Color.create);
  static final $pb.Extension value = $pb.Extension<DatapointOptions>('google.protobuf.EnumValueOptions', 'value', 8007, $pb.PbFieldType.OM, DatapointOptions.getDefault, DatapointOptions.create);
  static final $pb.Extension enumeration = $pb.Extension<DatapointOptions>('google.protobuf.EnumOptions', 'enumeration', 9001, $pb.PbFieldType.OM, DatapointOptions.getDefault, DatapointOptions.create);
  static void registerAllExtensions($pb.ExtensionRegistry registry) {
    registry.add(db);
    registry.add(table);
    registry.add(map);
    registry.add(msg);
    registry.add(field);
    registry.add(column);
    registry.add(collection);
    registry.add(opts);
    registry.add(label);
    registry.add(color);
    registry.add(value);
    registry.add(enumeration);
  }
}

