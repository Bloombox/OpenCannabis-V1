///
//  Generated code. Do not modify.
//  source: regulatory/usa/ca/CAAgency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class CaliforniaAgency extends $pb.ProtobufEnum {
  static const CaliforniaAgency UNKNOWN_AGENCY = CaliforniaAgency._(0, 'UNKNOWN_AGENCY');
  static const CaliforniaAgency CDFA = CaliforniaAgency._(1, 'CDFA');
  static const CaliforniaAgency CBCC = CaliforniaAgency._(2, 'CBCC');
  static const CaliforniaAgency CDCA = CaliforniaAgency._(3, 'CDCA');
  static const CaliforniaAgency CDPH = CaliforniaAgency._(4, 'CDPH');

  static const $core.List<CaliforniaAgency> values = <CaliforniaAgency> [
    UNKNOWN_AGENCY,
    CDFA,
    CBCC,
    CDCA,
    CDPH,
  ];

  static final $core.Map<$core.int, CaliforniaAgency> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CaliforniaAgency valueOf($core.int value) => _byValue[value];

  const CaliforniaAgency._($core.int v, $core.String n) : super(v, n);
}

