///
//  Generated code. Do not modify.
//  source: inventory/InventoryProduct.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const InventoryKey$json = const {
  '1': 'InventoryKey',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '8': const {}, '10': 'key'},
    const {'1': 'uuid', '3': 2, '4': 1, '5': 9, '10': 'uuid'},
  ],
};

const InventoryCoordinates$json = const {
  '1': 'InventoryCoordinates',
  '2': const [
    const {'1': 'location', '3': 1, '4': 1, '5': 9, '10': 'location'},
    const {'1': 'zone', '3': 2, '4': 1, '5': 9, '10': 'zone'},
    const {'1': 'rack', '3': 3, '4': 1, '5': 9, '10': 'rack'},
    const {'1': 'shelf', '3': 4, '4': 1, '5': 9, '10': 'shelf'},
    const {'1': 'bin', '3': 5, '4': 1, '5': 9, '10': 'bin'},
    const {'1': 'batch', '3': 6, '4': 1, '5': 9, '10': 'batch'},
  ],
};

const InventoryAmount$json = const {
  '1': 'InventoryAmount',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.PricingType', '10': 'type'},
    const {'1': 'unit', '3': 2, '4': 1, '5': 8, '9': 0, '10': 'unit'},
    const {'1': 'weight', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.PricingWeightTier', '9': 0, '10': 'weight'},
    const {'1': 'quantity', '3': 4, '4': 1, '5': 4, '10': 'quantity'},
  ],
  '8': const [
    const {'1': 'basis'},
  ],
};

const InventoryState$json = const {
  '1': 'InventoryState',
  '2': const [
    const {'1': 'status', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.inventory.InventoryState.Status', '10': 'status'},
    const {'1': 'coordinates', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryCoordinates', '10': 'coordinates'},
    const {'1': 'fit_for_sale', '3': 3, '4': 1, '5': 8, '10': 'fitForSale'},
    const {'1': 'amount', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryAmount', '10': 'amount'},
    const {'1': 'created', '3': 98, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'created'},
    const {'1': 'modified', '3': 99, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'modified'},
  ],
  '4': const [InventoryState_Status$json],
};

const InventoryState_Status$json = const {
  '1': 'Status',
  '2': const [
    const {'1': 'UNRECONCILED', '2': 0},
    const {'1': 'RECEIVING', '2': 1},
    const {'1': 'QUARANTINE', '2': 2},
    const {'1': 'ON_HAND', '2': 3},
    const {'1': 'FOR_SALE', '2': 4},
    const {'1': 'CLAIMED', '2': 5},
    const {'1': 'COMMITTED', '2': 6},
  ],
};

const InventoryProduct$json = const {
  '1': 'InventoryProduct',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryKey', '10': 'key'},
    const {'1': 'sku', '3': 2, '4': 3, '5': 9, '10': 'sku'},
    const {'1': 'variant', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.commerce.VariantSpec', '10': 'variant'},
    const {'1': 'state', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryState', '10': 'state'},
    const {'1': 'history', '3': 11, '4': 3, '5': 11, '6': '.opencannabis.inventory.InventoryState', '10': 'history'},
    const {'1': 'item', '3': 20, '4': 1, '5': 11, '6': '.opencannabis.products.menu.MenuProduct', '10': 'item'},
  ],
  '7': const {},
};

