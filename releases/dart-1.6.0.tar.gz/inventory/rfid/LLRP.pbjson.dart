///
//  Generated code. Do not modify.
//  source: inventory/rfid/LLRP.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const RegulatoryCapability$json = const {
  '1': 'RegulatoryCapability',
  '2': const [
    const {'1': 'UNSPECIFIED_REGULATORY_REGION', '2': 0},
    const {'1': 'US_FCC', '2': 1},
    const {'1': 'ETSI_302_208', '2': 2},
    const {'1': 'ETSI_300_220', '2': 3},
    const {'1': 'AUSTRALIA_LIPD_1W', '2': 4},
    const {'1': 'AUSTRALIA_LIPD_4W', '2': 5},
    const {'1': 'JAPAN_ARIB_STD_T89', '2': 6},
    const {'1': 'HONGKONG_OFTA_1049', '2': 7},
    const {'1': 'TAIWAN_DGT_LP0002', '2': 8},
    const {'1': 'KOREA_MIC_ARTICLE_5_2', '2': 9},
  ],
};

const StartTriggerType$json = const {
  '1': 'StartTriggerType',
  '2': const [
    const {'1': 'NO_START_TRIGGER', '2': 0},
    const {'1': 'IMMEDIATE', '2': 1},
    const {'1': 'PERIODIC', '2': 2},
    const {'1': 'GPIO_START', '2': 3},
  ],
};

const StopTriggerType$json = const {
  '1': 'StopTriggerType',
  '2': const [
    const {'1': 'NO_STOP_TRIGGER', '2': 0},
    const {'1': 'DURATION', '2': 1},
    const {'1': 'GPIO_STOP', '2': 2},
  ],
};

const BoundaryConfig$json = const {
  '1': 'BoundaryConfig',
  '2': const [
    const {'1': 'start', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.BoundaryConfig.StartTrigger', '10': 'start'},
    const {'1': 'stop', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.BoundaryConfig.StopTrigger', '10': 'stop'},
  ],
  '3': const [BoundaryConfig_StartTrigger$json, BoundaryConfig_StopTrigger$json],
};

const BoundaryConfig_StartTrigger$json = const {
  '1': 'StartTrigger',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.inventory.rfid.StartTriggerType', '10': 'type'},
    const {'1': 'schedule', '3': 2, '4': 1, '5': 4, '10': 'schedule'},
  ],
};

const BoundaryConfig_StopTrigger$json = const {
  '1': 'StopTrigger',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.inventory.rfid.StopTriggerType', '10': 'type'},
    const {'1': 'schedule', '3': 2, '4': 1, '5': 4, '10': 'schedule'},
  ],
};

const ReportingConfig$json = const {
  '1': 'ReportingConfig',
};

const ROSpec$json = const {
  '1': 'ROSpec',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 13, '10': 'id'},
    const {'1': 'priority', '3': 2, '4': 1, '5': 13, '10': 'priority'},
    const {'1': 'boundary', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.BoundaryConfig', '10': 'boundary'},
    const {'1': 'reporting', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.ReportingConfig', '10': 'reporting'},
  ],
};

const TagReportOrigin$json = const {
  '1': 'TagReportOrigin',
  '2': const [
    const {'1': 'reader', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.Reader', '8': const {}, '10': 'reader'},
    const {'1': 'partner', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'partner'},
    const {'1': 'location', '3': 3, '4': 1, '5': 9, '8': const {}, '10': 'location'},
  ],
};

const TagReport$json = const {
  '1': 'TagReport',
  '2': const [
    const {'1': 'antenna', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.Antenna', '8': const {}, '10': 'antenna'},
    const {'1': 'tag', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.Tag', '8': const {}, '10': 'tag'},
    const {'1': 'rssi', '3': 3, '4': 1, '5': 1, '8': const {}, '10': 'rssi'},
    const {'1': 'first_seen', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'firstSeen'},
    const {'1': 'last_seen', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'lastSeen'},
    const {'1': 'received', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'received'},
    const {'1': 'peers', '3': 7, '4': 1, '5': 13, '8': const {}, '10': 'peers'},
  ],
};

const TagReportSet$json = const {
  '1': 'TagReportSet',
  '2': const [
    const {'1': 'origin', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.rfid.TagReportOrigin', '8': const {}, '10': 'origin'},
    const {'1': 'report', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.inventory.rfid.TagReport', '8': const {}, '10': 'report'},
  ],
};

