///
//  Generated code. Do not modify.
//  source: products/Apothecary.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;
import '../content/ProductContent.pb.dart' as $42;
import '../content/MaterialsData.pb.dart' as $43;

import 'Apothecary.pbenum.dart';

export 'Apothecary.pbenum.dart';

class Apothecary extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Apothecary', package: const $pb.PackageName('opencannabis.products'))
    ..a<$17.ProductKey>(1, 'key', $pb.PbFieldType.OM, $17.ProductKey.getDefault, $17.ProductKey.create)
    ..e<ApothecaryType>(2, 'type', $pb.PbFieldType.OE, ApothecaryType.UNSPECIFIED_APOTHECARY, ApothecaryType.valueOf, ApothecaryType.values)
    ..a<$42.ProductContent>(3, 'product', $pb.PbFieldType.OM, $42.ProductContent.getDefault, $42.ProductContent.create)
    ..a<$43.MaterialsData>(4, 'material', $pb.PbFieldType.OM, $43.MaterialsData.getDefault, $43.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Apothecary() : super();
  Apothecary.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Apothecary.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Apothecary clone() => Apothecary()..mergeFromMessage(this);
  Apothecary copyWith(void Function(Apothecary) updates) => super.copyWith((message) => updates(message as Apothecary));
  $pb.BuilderInfo get info_ => _i;
  static Apothecary create() => Apothecary();
  Apothecary createEmptyInstance() => create();
  static $pb.PbList<Apothecary> createRepeated() => $pb.PbList<Apothecary>();
  static Apothecary getDefault() => _defaultInstance ??= create()..freeze();
  static Apothecary _defaultInstance;

  $17.ProductKey get key => $_getN(0);
  set key($17.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  ApothecaryType get type => $_getN(1);
  set type(ApothecaryType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $42.ProductContent get product => $_getN(2);
  set product($42.ProductContent v) { setField(3, v); }
  $core.bool hasProduct() => $_has(2);
  void clearProduct() => clearField(3);

  $43.MaterialsData get material => $_getN(3);
  set material($43.MaterialsData v) { setField(4, v); }
  $core.bool hasMaterial() => $_has(3);
  void clearMaterial() => clearField(4);
}

