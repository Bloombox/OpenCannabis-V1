///
//  Generated code. Do not modify.
//  source: products/Merchandise.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class MerchandiseType extends $pb.ProtobufEnum {
  static const MerchandiseType UNSPECIFIED_MERCHANDISE = MerchandiseType._(0, 'UNSPECIFIED_MERCHANDISE');
  static const MerchandiseType CLOTHING = MerchandiseType._(1, 'CLOTHING');
  static const MerchandiseType GLASSWARE = MerchandiseType._(2, 'GLASSWARE');
  static const MerchandiseType CONTAINER = MerchandiseType._(3, 'CONTAINER');
  static const MerchandiseType LIGHTER = MerchandiseType._(4, 'LIGHTER');
  static const MerchandiseType TSHIRT = MerchandiseType._(5, 'TSHIRT');
  static const MerchandiseType HOODIE = MerchandiseType._(6, 'HOODIE');
  static const MerchandiseType HAT = MerchandiseType._(7, 'HAT');

  static const $core.List<MerchandiseType> values = <MerchandiseType> [
    UNSPECIFIED_MERCHANDISE,
    CLOTHING,
    GLASSWARE,
    CONTAINER,
    LIGHTER,
    TSHIRT,
    HOODIE,
    HAT,
  ];

  static final $core.Map<$core.int, MerchandiseType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MerchandiseType valueOf($core.int value) => _byValue[value];

  const MerchandiseType._($core.int v, $core.String n) : super(v, n);
}

class MerchandiseFlag extends $pb.ProtobufEnum {
  static const MerchandiseFlag NO_MERCHANDISE_FLAGS = MerchandiseFlag._(0, 'NO_MERCHANDISE_FLAGS');
  static const MerchandiseFlag MEDICAL_ONLY = MerchandiseFlag._(1, 'MEDICAL_ONLY');
  static const MerchandiseFlag BRAND_SWAG = MerchandiseFlag._(2, 'BRAND_SWAG');

  static const $core.List<MerchandiseFlag> values = <MerchandiseFlag> [
    NO_MERCHANDISE_FLAGS,
    MEDICAL_ONLY,
    BRAND_SWAG,
  ];

  static final $core.Map<$core.int, MerchandiseFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MerchandiseFlag valueOf($core.int value) => _byValue[value];

  const MerchandiseFlag._($core.int v, $core.String n) : super(v, n);
}

