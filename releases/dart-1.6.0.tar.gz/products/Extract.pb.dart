///
//  Generated code. Do not modify.
//  source: products/Extract.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;
import '../content/ProductContent.pb.dart' as $42;
import '../content/MaterialsData.pb.dart' as $43;

import 'Extract.pbenum.dart';

export 'Extract.pbenum.dart';

class Extract extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Extract', package: const $pb.PackageName('opencannabis.products'))
    ..a<$17.ProductKey>(1, 'key', $pb.PbFieldType.OM, $17.ProductKey.getDefault, $17.ProductKey.create)
    ..e<ExtractType>(2, 'type', $pb.PbFieldType.OE, ExtractType.UNSPECIFIED_EXTRACT, ExtractType.valueOf, ExtractType.values)
    ..pc<ExtractFlag>(3, 'flag', $pb.PbFieldType.PE, null, ExtractFlag.valueOf, ExtractFlag.values)
    ..a<$17.ProductReference>(4, 'flower', $pb.PbFieldType.OM, $17.ProductReference.getDefault, $17.ProductReference.create)
    ..a<$42.ProductContent>(5, 'product', $pb.PbFieldType.OM, $42.ProductContent.getDefault, $42.ProductContent.create)
    ..a<$43.MaterialsData>(6, 'material', $pb.PbFieldType.OM, $43.MaterialsData.getDefault, $43.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Extract() : super();
  Extract.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Extract.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Extract clone() => Extract()..mergeFromMessage(this);
  Extract copyWith(void Function(Extract) updates) => super.copyWith((message) => updates(message as Extract));
  $pb.BuilderInfo get info_ => _i;
  static Extract create() => Extract();
  Extract createEmptyInstance() => create();
  static $pb.PbList<Extract> createRepeated() => $pb.PbList<Extract>();
  static Extract getDefault() => _defaultInstance ??= create()..freeze();
  static Extract _defaultInstance;

  $17.ProductKey get key => $_getN(0);
  set key($17.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  ExtractType get type => $_getN(1);
  set type(ExtractType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.List<ExtractFlag> get flag => $_getList(2);

  $17.ProductReference get flower => $_getN(3);
  set flower($17.ProductReference v) { setField(4, v); }
  $core.bool hasFlower() => $_has(3);
  void clearFlower() => clearField(4);

  $42.ProductContent get product => $_getN(4);
  set product($42.ProductContent v) { setField(5, v); }
  $core.bool hasProduct() => $_has(4);
  void clearProduct() => clearField(5);

  $43.MaterialsData get material => $_getN(5);
  set material($43.MaterialsData v) { setField(6, v); }
  $core.bool hasMaterial() => $_has(5);
  void clearMaterial() => clearField(6);
}

