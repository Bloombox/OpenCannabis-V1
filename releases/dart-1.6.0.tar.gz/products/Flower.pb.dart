///
//  Generated code. Do not modify.
//  source: products/Flower.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;
import '../content/ProductContent.pb.dart' as $42;
import '../content/MaterialsData.pb.dart' as $43;

class Flower extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Flower', package: const $pb.PackageName('opencannabis.products'))
    ..a<$17.ProductKey>(1, 'key', $pb.PbFieldType.OM, $17.ProductKey.getDefault, $17.ProductKey.create)
    ..a<$42.ProductContent>(2, 'product', $pb.PbFieldType.OM, $42.ProductContent.getDefault, $42.ProductContent.create)
    ..a<$43.MaterialsData>(3, 'material', $pb.PbFieldType.OM, $43.MaterialsData.getDefault, $43.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Flower() : super();
  Flower.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Flower.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Flower clone() => Flower()..mergeFromMessage(this);
  Flower copyWith(void Function(Flower) updates) => super.copyWith((message) => updates(message as Flower));
  $pb.BuilderInfo get info_ => _i;
  static Flower create() => Flower();
  Flower createEmptyInstance() => create();
  static $pb.PbList<Flower> createRepeated() => $pb.PbList<Flower>();
  static Flower getDefault() => _defaultInstance ??= create()..freeze();
  static Flower _defaultInstance;

  $17.ProductKey get key => $_getN(0);
  set key($17.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $42.ProductContent get product => $_getN(1);
  set product($42.ProductContent v) { setField(2, v); }
  $core.bool hasProduct() => $_has(1);
  void clearProduct() => clearField(2);

  $43.MaterialsData get material => $_getN(2);
  set material($43.MaterialsData v) { setField(3, v); }
  $core.bool hasMaterial() => $_has(2);
  void clearMaterial() => clearField(3);
}

