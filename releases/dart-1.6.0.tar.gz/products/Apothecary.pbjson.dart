///
//  Generated code. Do not modify.
//  source: products/Apothecary.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ApothecaryType$json = const {
  '1': 'ApothecaryType',
  '2': const [
    const {'1': 'UNSPECIFIED_APOTHECARY', '2': 0},
    const {'1': 'TOPICAL', '2': 1},
    const {'1': 'TINCTURE', '2': 2},
    const {'1': 'CAPSULE', '2': 3},
    const {'1': 'INJECTOR', '2': 4},
  ],
};

const Apothecary$json = const {
  '1': 'Apothecary',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.products.ApothecaryType', '10': 'type'},
    const {'1': 'product', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.content.MaterialsData', '10': 'material'},
  ],
};

