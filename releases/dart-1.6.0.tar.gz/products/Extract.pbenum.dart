///
//  Generated code. Do not modify.
//  source: products/Extract.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ExtractType extends $pb.ProtobufEnum {
  static const ExtractType UNSPECIFIED_EXTRACT = ExtractType._(0, 'UNSPECIFIED_EXTRACT');
  static const ExtractType OIL = ExtractType._(1, 'OIL');
  static const ExtractType WAX = ExtractType._(2, 'WAX');
  static const ExtractType SHATTER = ExtractType._(3, 'SHATTER');
  static const ExtractType KIEF = ExtractType._(4, 'KIEF');
  static const ExtractType HASH = ExtractType._(5, 'HASH');
  static const ExtractType LIVE_RESIN = ExtractType._(6, 'LIVE_RESIN');
  static const ExtractType ROSIN = ExtractType._(7, 'ROSIN');
  static const ExtractType CRUMBLE = ExtractType._(8, 'CRUMBLE');
  static const ExtractType SAUCE = ExtractType._(9, 'SAUCE');
  static const ExtractType SUGAR = ExtractType._(10, 'SUGAR');

  static const $core.List<ExtractType> values = <ExtractType> [
    UNSPECIFIED_EXTRACT,
    OIL,
    WAX,
    SHATTER,
    KIEF,
    HASH,
    LIVE_RESIN,
    ROSIN,
    CRUMBLE,
    SAUCE,
    SUGAR,
  ];

  static final $core.Map<$core.int, ExtractType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ExtractType valueOf($core.int value) => _byValue[value];

  const ExtractType._($core.int v, $core.String n) : super(v, n);
}

class ExtractFlag extends $pb.ProtobufEnum {
  static const ExtractFlag NO_EXTRACT_FLAGS = ExtractFlag._(0, 'NO_EXTRACT_FLAGS');
  static const ExtractFlag SOLVENTLESS = ExtractFlag._(1, 'SOLVENTLESS');

  static const $core.List<ExtractFlag> values = <ExtractFlag> [
    NO_EXTRACT_FLAGS,
    SOLVENTLESS,
  ];

  static final $core.Map<$core.int, ExtractFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ExtractFlag valueOf($core.int value) => _byValue[value];

  const ExtractFlag._($core.int v, $core.String n) : super(v, n);
}

