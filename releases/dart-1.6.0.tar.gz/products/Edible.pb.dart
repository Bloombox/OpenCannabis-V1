///
//  Generated code. Do not modify.
//  source: products/Edible.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;
import '../content/ProductContent.pb.dart' as $42;
import '../content/MaterialsData.pb.dart' as $43;

import 'Edible.pbenum.dart';

export 'Edible.pbenum.dart';

class EdibleIngredient extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EdibleIngredient', package: const $pb.PackageName('opencannabis.products'))
    ..aOS(1, 'label')
    ..aOS(2, 'amount')
    ..hasRequiredFields = false
  ;

  EdibleIngredient() : super();
  EdibleIngredient.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EdibleIngredient.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EdibleIngredient clone() => EdibleIngredient()..mergeFromMessage(this);
  EdibleIngredient copyWith(void Function(EdibleIngredient) updates) => super.copyWith((message) => updates(message as EdibleIngredient));
  $pb.BuilderInfo get info_ => _i;
  static EdibleIngredient create() => EdibleIngredient();
  EdibleIngredient createEmptyInstance() => create();
  static $pb.PbList<EdibleIngredient> createRepeated() => $pb.PbList<EdibleIngredient>();
  static EdibleIngredient getDefault() => _defaultInstance ??= create()..freeze();
  static EdibleIngredient _defaultInstance;

  $core.String get label => $_getS(0, '');
  set label($core.String v) { $_setString(0, v); }
  $core.bool hasLabel() => $_has(0);
  void clearLabel() => clearField(1);

  $core.String get amount => $_getS(1, '');
  set amount($core.String v) { $_setString(1, v); }
  $core.bool hasAmount() => $_has(1);
  void clearAmount() => clearField(2);
}

class Edible extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Edible', package: const $pb.PackageName('opencannabis.products'))
    ..a<$17.ProductKey>(1, 'key', $pb.PbFieldType.OM, $17.ProductKey.getDefault, $17.ProductKey.create)
    ..e<EdibleType>(2, 'type', $pb.PbFieldType.OE, EdibleType.UNSPECIFIED_EDIBLE, EdibleType.valueOf, EdibleType.values)
    ..pc<EdibleFlag>(3, 'flags', $pb.PbFieldType.PE, null, EdibleFlag.valueOf, EdibleFlag.values)
    ..a<$42.ProductContent>(4, 'product', $pb.PbFieldType.OM, $42.ProductContent.getDefault, $42.ProductContent.create)
    ..a<$43.MaterialsData>(5, 'material', $pb.PbFieldType.OM, $43.MaterialsData.getDefault, $43.MaterialsData.create)
    ..pc<EdibleIngredient>(6, 'ingredients', $pb.PbFieldType.PM,EdibleIngredient.create)
    ..hasRequiredFields = false
  ;

  Edible() : super();
  Edible.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Edible.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Edible clone() => Edible()..mergeFromMessage(this);
  Edible copyWith(void Function(Edible) updates) => super.copyWith((message) => updates(message as Edible));
  $pb.BuilderInfo get info_ => _i;
  static Edible create() => Edible();
  Edible createEmptyInstance() => create();
  static $pb.PbList<Edible> createRepeated() => $pb.PbList<Edible>();
  static Edible getDefault() => _defaultInstance ??= create()..freeze();
  static Edible _defaultInstance;

  $17.ProductKey get key => $_getN(0);
  set key($17.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  EdibleType get type => $_getN(1);
  set type(EdibleType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.List<EdibleFlag> get flags => $_getList(2);

  $42.ProductContent get product => $_getN(3);
  set product($42.ProductContent v) { setField(4, v); }
  $core.bool hasProduct() => $_has(3);
  void clearProduct() => clearField(4);

  $43.MaterialsData get material => $_getN(4);
  set material($43.MaterialsData v) { setField(5, v); }
  $core.bool hasMaterial() => $_has(4);
  void clearMaterial() => clearField(5);

  $core.List<EdibleIngredient> get ingredients => $_getList(5);
}

