///
//  Generated code. Do not modify.
//  source: products/Apothecary.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ApothecaryType extends $pb.ProtobufEnum {
  static const ApothecaryType UNSPECIFIED_APOTHECARY = ApothecaryType._(0, 'UNSPECIFIED_APOTHECARY');
  static const ApothecaryType TOPICAL = ApothecaryType._(1, 'TOPICAL');
  static const ApothecaryType TINCTURE = ApothecaryType._(2, 'TINCTURE');
  static const ApothecaryType CAPSULE = ApothecaryType._(3, 'CAPSULE');
  static const ApothecaryType INJECTOR = ApothecaryType._(4, 'INJECTOR');

  static const $core.List<ApothecaryType> values = <ApothecaryType> [
    UNSPECIFIED_APOTHECARY,
    TOPICAL,
    TINCTURE,
    CAPSULE,
    INJECTOR,
  ];

  static final $core.Map<$core.int, ApothecaryType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ApothecaryType valueOf($core.int value) => _byValue[value];

  const ApothecaryType._($core.int v, $core.String n) : super(v, n);
}

