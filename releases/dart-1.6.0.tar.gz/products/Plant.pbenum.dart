///
//  Generated code. Do not modify.
//  source: products/Plant.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PlantType extends $pb.ProtobufEnum {
  static const PlantType UNSPECIFIED_PLANT = PlantType._(0, 'UNSPECIFIED_PLANT');
  static const PlantType SEED = PlantType._(1, 'SEED');
  static const PlantType CLONE = PlantType._(2, 'CLONE');

  static const $core.List<PlantType> values = <PlantType> [
    UNSPECIFIED_PLANT,
    SEED,
    CLONE,
  ];

  static final $core.Map<$core.int, PlantType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PlantType valueOf($core.int value) => _byValue[value];

  const PlantType._($core.int v, $core.String n) : super(v, n);
}

