///
//  Generated code. Do not modify.
//  source: products/distribution/DistributionChannel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Channel extends $pb.ProtobufEnum {
  static const Channel UNSPECIFIED_CHANNEL = Channel._(0, 'UNSPECIFIED_CHANNEL');
  static const Channel RETAIL = Channel._(1, 'RETAIL');
  static const Channel WHOLESALE = Channel._(2, 'WHOLESALE');
  static const Channel BULK = Channel._(3, 'BULK');

  static const $core.List<Channel> values = <Channel> [
    UNSPECIFIED_CHANNEL,
    RETAIL,
    WHOLESALE,
    BULK,
  ];

  static final $core.Map<$core.int, Channel> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Channel valueOf($core.int value) => _byValue[value];

  const Channel._($core.int v, $core.String n) : super(v, n);
}

class ChannelType extends $pb.ProtobufEnum {
  static const ChannelType UNSPECIFIED_CHANNEL_TYPE = ChannelType._(0, 'UNSPECIFIED_CHANNEL_TYPE');
  static const ChannelType DIRECT = ChannelType._(1, 'DIRECT');
  static const ChannelType MARKETPLACE = ChannelType._(2, 'MARKETPLACE');

  static const $core.List<ChannelType> values = <ChannelType> [
    UNSPECIFIED_CHANNEL_TYPE,
    DIRECT,
    MARKETPLACE,
  ];

  static final $core.Map<$core.int, ChannelType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ChannelType valueOf($core.int value) => _byValue[value];

  const ChannelType._($core.int v, $core.String n) : super(v, n);
}

