///
//  Generated code. Do not modify.
//  source: products/menu/Section.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const SectionFlag$json = const {
  '1': 'SectionFlag',
  '2': const [
    const {'1': 'HIDDEN', '2': 0},
    const {'1': 'FEATURED', '2': 1},
  ],
};

const Section$json = const {
  '1': 'Section',
  '2': const [
    const {'1': 'UNSPECIFIED', '2': 0},
    const {'1': 'FLOWERS', '2': 1},
    const {'1': 'EXTRACTS', '2': 2},
    const {'1': 'EDIBLES', '2': 3},
    const {'1': 'CARTRIDGES', '2': 4},
    const {'1': 'APOTHECARY', '2': 5},
    const {'1': 'PREROLLS', '2': 6},
    const {'1': 'PLANTS', '2': 7},
    const {'1': 'MERCHANDISE', '2': 8},
  ],
};

const FilteredSection$json = const {
  '1': 'FilteredSection',
  '2': const [
    const {'1': 'ON_SALE', '2': 0},
    const {'1': 'HOUSE', '2': 1},
    const {'1': 'CBD', '2': 2},
    const {'1': 'SEARCH', '2': 3},
  ],
};

const CustomSection$json = const {
  '1': 'CustomSection',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'filter', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.products.menu.section.FilteredSection', '10': 'filter'},
  ],
};

const SectionMedia$json = const {
  '1': 'SectionMedia',
  '2': const [
    const {'1': 'tablet_homescreen_media', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '10': 'tabletHomescreenMedia'},
  ],
};

const SectionSettings$json = const {
  '1': 'SectionSettings',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Name', '10': 'name'},
    const {'1': 'media', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.menu.section.SectionMedia', '10': 'media'},
  ],
};

const SectionSpec$json = const {
  '1': 'SectionSpec',
  '2': const [
    const {'1': 'section', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.products.menu.section.Section', '9': 0, '10': 'section'},
    const {'1': 'custom_section', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.menu.section.CustomSection', '9': 0, '10': 'customSection'},
    const {'1': 'name', '3': 3, '4': 1, '5': 9, '9': 0, '10': 'name'},
    const {'1': 'settings', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.products.menu.section.SectionSettings', '10': 'settings'},
    const {'1': 'flags', '3': 5, '4': 3, '5': 14, '6': '.opencannabis.products.menu.section.SectionFlag', '10': 'flags'},
  ],
  '8': const [
    const {'1': 'spec'},
  ],
};

