///
//  Generated code. Do not modify.
//  source: products/menu/Section.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class SectionFlag extends $pb.ProtobufEnum {
  static const SectionFlag HIDDEN = SectionFlag._(0, 'HIDDEN');
  static const SectionFlag FEATURED = SectionFlag._(1, 'FEATURED');

  static const $core.List<SectionFlag> values = <SectionFlag> [
    HIDDEN,
    FEATURED,
  ];

  static final $core.Map<$core.int, SectionFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static SectionFlag valueOf($core.int value) => _byValue[value];

  const SectionFlag._($core.int v, $core.String n) : super(v, n);
}

class Section extends $pb.ProtobufEnum {
  static const Section UNSPECIFIED = Section._(0, 'UNSPECIFIED');
  static const Section FLOWERS = Section._(1, 'FLOWERS');
  static const Section EXTRACTS = Section._(2, 'EXTRACTS');
  static const Section EDIBLES = Section._(3, 'EDIBLES');
  static const Section CARTRIDGES = Section._(4, 'CARTRIDGES');
  static const Section APOTHECARY = Section._(5, 'APOTHECARY');
  static const Section PREROLLS = Section._(6, 'PREROLLS');
  static const Section PLANTS = Section._(7, 'PLANTS');
  static const Section MERCHANDISE = Section._(8, 'MERCHANDISE');

  static const $core.List<Section> values = <Section> [
    UNSPECIFIED,
    FLOWERS,
    EXTRACTS,
    EDIBLES,
    CARTRIDGES,
    APOTHECARY,
    PREROLLS,
    PLANTS,
    MERCHANDISE,
  ];

  static final $core.Map<$core.int, Section> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Section valueOf($core.int value) => _byValue[value];

  const Section._($core.int v, $core.String n) : super(v, n);
}

class FilteredSection extends $pb.ProtobufEnum {
  static const FilteredSection ON_SALE = FilteredSection._(0, 'ON_SALE');
  static const FilteredSection HOUSE = FilteredSection._(1, 'HOUSE');
  static const FilteredSection CBD = FilteredSection._(2, 'CBD');
  static const FilteredSection SEARCH = FilteredSection._(3, 'SEARCH');

  static const $core.List<FilteredSection> values = <FilteredSection> [
    ON_SALE,
    HOUSE,
    CBD,
    SEARCH,
  ];

  static final $core.Map<$core.int, FilteredSection> _byValue = $pb.ProtobufEnum.initByValue(values);
  static FilteredSection valueOf($core.int value) => _byValue[value];

  const FilteredSection._($core.int v, $core.String n) : super(v, n);
}

