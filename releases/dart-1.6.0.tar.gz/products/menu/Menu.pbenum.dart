///
//  Generated code. Do not modify.
//  source: products/menu/Menu.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Status extends $pb.ProtobufEnum {
  static const Status UNPUBLISHED = Status._(0, 'UNPUBLISHED');
  static const Status LIVE = Status._(1, 'LIVE');

  static const $core.List<Status> values = <Status> [
    UNPUBLISHED,
    LIVE,
  ];

  static final $core.Map<$core.int, Status> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Status valueOf($core.int value) => _byValue[value];

  const Status._($core.int v, $core.String n) : super(v, n);
}

class Flag extends $pb.ProtobufEnum {
  static const Flag DRAFT = Flag._(0, 'DRAFT');
  static const Flag PRIVATE = Flag._(1, 'PRIVATE');
  static const Flag OUT_OF_DATE = Flag._(2, 'OUT_OF_DATE');

  static const $core.List<Flag> values = <Flag> [
    DRAFT,
    PRIVATE,
    OUT_OF_DATE,
  ];

  static final $core.Map<$core.int, Flag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Flag valueOf($core.int value) => _byValue[value];

  const Flag._($core.int v, $core.String n) : super(v, n);
}

