///
//  Generated code. Do not modify.
//  source: products/menu/Menu.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Status$json = const {
  '1': 'Status',
  '2': const [
    const {'1': 'UNPUBLISHED', '2': 0},
    const {'1': 'LIVE', '2': 1},
  ],
};

const Flag$json = const {
  '1': 'Flag',
  '2': const [
    const {'1': 'DRAFT', '2': 0},
    const {'1': 'PRIVATE', '2': 1},
    const {'1': 'OUT_OF_DATE', '2': 2},
  ],
};

const MenuSettings$json = const {
  '1': 'MenuSettings',
  '2': const [
    const {'1': 'full', '3': 1, '4': 1, '5': 8, '10': 'full'},
    const {'1': 'keys_only', '3': 2, '4': 1, '5': 8, '10': 'keysOnly'},
    const {'1': 'snapshot', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'snapshot'},
    const {'1': 'fingerprint', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'fingerprint'},
    const {'1': 'section', '3': 5, '4': 3, '5': 14, '6': '.opencannabis.products.menu.section.Section', '10': 'section'},
    const {'1': 'available_section', '3': 6, '4': 3, '5': 14, '6': '.opencannabis.products.menu.section.Section', '10': 'availableSection'},
  ],
};

const Metadata$json = const {
  '1': 'Metadata',
  '2': const [
    const {'1': 'scope', '3': 1, '4': 1, '5': 9, '10': 'scope'},
    const {'1': 'version', '3': 2, '4': 1, '5': 4, '10': 'version'},
    const {'1': 'status', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.products.menu.Status', '10': 'status'},
    const {'1': 'flags', '3': 4, '4': 3, '5': 14, '6': '.opencannabis.products.menu.Flag', '10': 'flags'},
    const {'1': 'published', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'published'},
    const {'1': 'settings', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.products.menu.MenuSettings', '10': 'settings'},
  ],
};

const ProductTag$json = const {
  '1': 'ProductTag',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'display', '3': 2, '4': 1, '5': 9, '10': 'display'},
    const {'1': 'color', '3': 3, '4': 1, '5': 9, '10': 'color'},
  ],
};

const ForeignReference$json = const {
  '1': 'ForeignReference',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'domain', '3': 2, '4': 1, '5': 9, '10': 'domain'},
    const {'1': 'link', '3': 3, '4': 1, '5': 9, '10': 'link'},
    const {'1': 'attached', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'attached'},
    const {'1': 'validated', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'validated'},
  ],
};

const MenuProduct$json = const {
  '1': 'MenuProduct',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '8': const {}, '10': 'key'},
    const {'1': 'tag', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.products.menu.ProductTag', '10': 'tag'},
    const {'1': 'ref', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.products.menu.ForeignReference', '10': 'ref'},
    const {'1': 'apothecary', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.products.Apothecary', '9': 0, '10': 'apothecary'},
    const {'1': 'cartridge', '3': 11, '4': 1, '5': 11, '6': '.opencannabis.products.Cartridge', '9': 0, '10': 'cartridge'},
    const {'1': 'edible', '3': 12, '4': 1, '5': 11, '6': '.opencannabis.products.Edible', '9': 0, '10': 'edible'},
    const {'1': 'extract', '3': 13, '4': 1, '5': 11, '6': '.opencannabis.products.Extract', '9': 0, '10': 'extract'},
    const {'1': 'flower', '3': 14, '4': 1, '5': 11, '6': '.opencannabis.products.Flower', '9': 0, '10': 'flower'},
    const {'1': 'merchandise', '3': 15, '4': 1, '5': 11, '6': '.opencannabis.products.Merchandise', '9': 0, '10': 'merchandise'},
    const {'1': 'plant', '3': 16, '4': 1, '5': 11, '6': '.opencannabis.products.Plant', '9': 0, '10': 'plant'},
    const {'1': 'preroll', '3': 17, '4': 1, '5': 11, '6': '.opencannabis.products.Preroll', '9': 0, '10': 'preroll'},
  ],
  '7': const {},
  '8': const [
    const {'1': 'product'},
  ],
};

const SectionData$json = const {
  '1': 'SectionData',
  '2': const [
    const {'1': 'count', '3': 1, '4': 1, '5': 5, '10': 'count'},
    const {'1': 'section', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.menu.section.SectionSpec', '10': 'section'},
    const {'1': 'product', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.products.menu.MenuProduct', '10': 'product'},
  ],
};

const SectionedMenu$json = const {
  '1': 'SectionedMenu',
  '2': const [
    const {'1': 'count', '3': 1, '4': 1, '5': 5, '10': 'count'},
    const {'1': 'payload', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.products.menu.SectionData', '10': 'payload'},
  ],
};

const StaticMenu$json = const {
  '1': 'StaticMenu',
  '2': const [
    const {'1': 'apothecary', '3': 1, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.ApothecaryEntry', '10': 'apothecary'},
    const {'1': 'cartridges', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.CartridgesEntry', '10': 'cartridges'},
    const {'1': 'edibles', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.EdiblesEntry', '10': 'edibles'},
    const {'1': 'extracts', '3': 4, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.ExtractsEntry', '10': 'extracts'},
    const {'1': 'flowers', '3': 5, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.FlowersEntry', '10': 'flowers'},
    const {'1': 'merchandise', '3': 6, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.MerchandiseEntry', '10': 'merchandise'},
    const {'1': 'plants', '3': 7, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.PlantsEntry', '10': 'plants'},
    const {'1': 'prerolls', '3': 8, '4': 3, '5': 11, '6': '.opencannabis.products.menu.StaticMenu.PrerollsEntry', '10': 'prerolls'},
  ],
  '3': const [StaticMenu_ApothecaryEntry$json, StaticMenu_CartridgesEntry$json, StaticMenu_EdiblesEntry$json, StaticMenu_ExtractsEntry$json, StaticMenu_FlowersEntry$json, StaticMenu_MerchandiseEntry$json, StaticMenu_PlantsEntry$json, StaticMenu_PrerollsEntry$json],
};

const StaticMenu_ApothecaryEntry$json = const {
  '1': 'ApothecaryEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Apothecary', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_CartridgesEntry$json = const {
  '1': 'CartridgesEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Cartridge', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_EdiblesEntry$json = const {
  '1': 'EdiblesEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Edible', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_ExtractsEntry$json = const {
  '1': 'ExtractsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Extract', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_FlowersEntry$json = const {
  '1': 'FlowersEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Flower', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_MerchandiseEntry$json = const {
  '1': 'MerchandiseEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Merchandise', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_PlantsEntry$json = const {
  '1': 'PlantsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Plant', '10': 'value'},
  ],
  '7': const {'7': true},
};

const StaticMenu_PrerollsEntry$json = const {
  '1': 'PrerollsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.products.Preroll', '10': 'value'},
  ],
  '7': const {'7': true},
};

const Menu$json = const {
  '1': 'Menu',
  '2': const [
    const {'1': 'metadata', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.products.menu.Metadata', '10': 'metadata'},
    const {'1': 'payload', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.products.menu.SectionedMenu', '9': 0, '10': 'payload'},
    const {'1': 'menu', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.products.menu.StaticMenu', '9': 0, '10': 'menu'},
  ],
  '8': const [
    const {'1': 'content'},
  ],
};

