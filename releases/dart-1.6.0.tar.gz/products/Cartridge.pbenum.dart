///
//  Generated code. Do not modify.
//  source: products/Cartridge.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class CartridgeType extends $pb.ProtobufEnum {
  static const CartridgeType UNSPECIFIED_CARTRIDGE = CartridgeType._(0, 'UNSPECIFIED_CARTRIDGE');
  static const CartridgeType CARTRIDGE = CartridgeType._(1, 'CARTRIDGE');
  static const CartridgeType BATTERY = CartridgeType._(2, 'BATTERY');
  static const CartridgeType KIT = CartridgeType._(3, 'KIT');

  static const $core.List<CartridgeType> values = <CartridgeType> [
    UNSPECIFIED_CARTRIDGE,
    CARTRIDGE,
    BATTERY,
    KIT,
  ];

  static final $core.Map<$core.int, CartridgeType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CartridgeType valueOf($core.int value) => _byValue[value];

  const CartridgeType._($core.int v, $core.String n) : super(v, n);
}

