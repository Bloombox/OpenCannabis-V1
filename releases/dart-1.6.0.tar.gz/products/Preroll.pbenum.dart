///
//  Generated code. Do not modify.
//  source: products/Preroll.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PrerollFlag extends $pb.ProtobufEnum {
  static const PrerollFlag NO_PREROLL_FLAGS = PrerollFlag._(0, 'NO_PREROLL_FLAGS');
  static const PrerollFlag HASH_INFUSED = PrerollFlag._(1, 'HASH_INFUSED');
  static const PrerollFlag KIEF_INFUSED = PrerollFlag._(2, 'KIEF_INFUSED');
  static const PrerollFlag FORTIFIED = PrerollFlag._(3, 'FORTIFIED');
  static const PrerollFlag FULL_FLOWER = PrerollFlag._(4, 'FULL_FLOWER');
  static const PrerollFlag CONTAINS_TOBACCO = PrerollFlag._(5, 'CONTAINS_TOBACCO');

  static const $core.List<PrerollFlag> values = <PrerollFlag> [
    NO_PREROLL_FLAGS,
    HASH_INFUSED,
    KIEF_INFUSED,
    FORTIFIED,
    FULL_FLOWER,
    CONTAINS_TOBACCO,
  ];

  static final $core.Map<$core.int, PrerollFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PrerollFlag valueOf($core.int value) => _byValue[value];

  const PrerollFlag._($core.int v, $core.String n) : super(v, n);
}

