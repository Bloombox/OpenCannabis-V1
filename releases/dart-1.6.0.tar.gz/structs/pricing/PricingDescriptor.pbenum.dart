///
//  Generated code. Do not modify.
//  source: structs/pricing/PricingDescriptor.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PricingType extends $pb.ProtobufEnum {
  static const PricingType UNIT = PricingType._(0, 'UNIT');
  static const PricingType WEIGHTED = PricingType._(1, 'WEIGHTED');

  static const $core.List<PricingType> values = <PricingType> [
    UNIT,
    WEIGHTED,
  ];

  static final $core.Map<$core.int, PricingType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PricingType valueOf($core.int value) => _byValue[value];

  const PricingType._($core.int v, $core.String n) : super(v, n);
}

class PricingWeightTier extends $pb.ProtobufEnum {
  static const PricingWeightTier NO_WEIGHT = PricingWeightTier._(0, 'NO_WEIGHT');
  static const PricingWeightTier GRAM = PricingWeightTier._(1, 'GRAM');
  static const PricingWeightTier HALFGRAM = PricingWeightTier._(2, 'HALFGRAM');
  static const PricingWeightTier QUARTERGRAM = PricingWeightTier._(3, 'QUARTERGRAM');
  static const PricingWeightTier DUB = PricingWeightTier._(4, 'DUB');
  static const PricingWeightTier EIGHTH = PricingWeightTier._(5, 'EIGHTH');
  static const PricingWeightTier QUARTER = PricingWeightTier._(6, 'QUARTER');
  static const PricingWeightTier HALF = PricingWeightTier._(7, 'HALF');
  static const PricingWeightTier OUNCE = PricingWeightTier._(8, 'OUNCE');
  static const PricingWeightTier QUARTERPOUND = PricingWeightTier._(9, 'QUARTERPOUND');
  static const PricingWeightTier HALFPOUND = PricingWeightTier._(10, 'HALFPOUND');
  static const PricingWeightTier POUND = PricingWeightTier._(11, 'POUND');
  static const PricingWeightTier KILO = PricingWeightTier._(12, 'KILO');
  static const PricingWeightTier TON = PricingWeightTier._(13, 'TON');
  static const PricingWeightTier OTHER = PricingWeightTier._(99, 'OTHER');

  static const $core.List<PricingWeightTier> values = <PricingWeightTier> [
    NO_WEIGHT,
    GRAM,
    HALFGRAM,
    QUARTERGRAM,
    DUB,
    EIGHTH,
    QUARTER,
    HALF,
    OUNCE,
    QUARTERPOUND,
    HALFPOUND,
    POUND,
    KILO,
    TON,
    OTHER,
  ];

  static final $core.Map<$core.int, PricingWeightTier> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PricingWeightTier valueOf($core.int value) => _byValue[value];

  const PricingWeightTier._($core.int v, $core.String n) : super(v, n);
}

