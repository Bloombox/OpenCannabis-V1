///
//  Generated code. Do not modify.
//  source: structs/ProductFlags.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ProductFlag extends $pb.ProtobufEnum {
  static const ProductFlag VISIBLE = ProductFlag._(0, 'VISIBLE');
  static const ProductFlag HIDDEN = ProductFlag._(1, 'HIDDEN');
  static const ProductFlag PREMIUM = ProductFlag._(2, 'PREMIUM');
  static const ProductFlag FEATURED = ProductFlag._(3, 'FEATURED');
  static const ProductFlag EXCLUSIVE = ProductFlag._(4, 'EXCLUSIVE');
  static const ProductFlag IN_HOUSE = ProductFlag._(5, 'IN_HOUSE');
  static const ProductFlag LAST_CHANCE = ProductFlag._(6, 'LAST_CHANCE');
  static const ProductFlag LIMITED_TIME = ProductFlag._(7, 'LIMITED_TIME');
  static const ProductFlag LOCAL = ProductFlag._(8, 'LOCAL');
  static const ProductFlag ON_SALE = ProductFlag._(20, 'ON_SALE');

  static const $core.List<ProductFlag> values = <ProductFlag> [
    VISIBLE,
    HIDDEN,
    PREMIUM,
    FEATURED,
    EXCLUSIVE,
    IN_HOUSE,
    LAST_CHANCE,
    LIMITED_TIME,
    LOCAL,
    ON_SALE,
  ];

  static final $core.Map<$core.int, ProductFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ProductFlag valueOf($core.int value) => _byValue[value];

  const ProductFlag._($core.int v, $core.String n) : super(v, n);
}

