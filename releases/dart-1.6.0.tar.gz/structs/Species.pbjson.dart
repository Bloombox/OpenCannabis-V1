///
//  Generated code. Do not modify.
//  source: structs/Species.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Species$json = const {
  '1': 'Species',
  '2': const [
    const {'1': 'UNSPECIFIED', '2': 0},
    const {'1': 'SATIVA', '2': 1},
    const {'1': 'HYBRID_SATIVA', '2': 2},
    const {'1': 'HYBRID', '2': 3},
    const {'1': 'HYBRID_INDICA', '2': 4},
    const {'1': 'INDICA', '2': 5},
  ],
};

