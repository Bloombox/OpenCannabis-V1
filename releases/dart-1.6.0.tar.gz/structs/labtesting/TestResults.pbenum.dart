///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestResults.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class TestMethod extends $pb.ProtobufEnum {
  static const TestMethod UNSPECIFIED_METHOD = TestMethod._(0, 'UNSPECIFIED_METHOD');
  static const TestMethod GCMS = TestMethod._(1, 'GCMS');
  static const TestMethod LCMS = TestMethod._(2, 'LCMS');
  static const TestMethod CLASSIC_PCR = TestMethod._(3, 'CLASSIC_PCR');
  static const TestMethod qPCR = TestMethod._(4, 'qPCR');
  static const TestMethod ELISA = TestMethod._(5, 'ELISA');

  static const $core.List<TestMethod> values = <TestMethod> [
    UNSPECIFIED_METHOD,
    GCMS,
    LCMS,
    CLASSIC_PCR,
    qPCR,
    ELISA,
  ];

  static final $core.Map<$core.int, TestMethod> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TestMethod valueOf($core.int value) => _byValue[value];

  const TestMethod._($core.int v, $core.String n) : super(v, n);
}

class Cannabinoid extends $pb.ProtobufEnum {
  static const Cannabinoid THC = Cannabinoid._(0, 'THC');
  static const Cannabinoid THC_A = Cannabinoid._(1, 'THC_A');
  static const Cannabinoid THC_V = Cannabinoid._(2, 'THC_V');
  static const Cannabinoid CBD = Cannabinoid._(10, 'CBD');
  static const Cannabinoid CBD_A = Cannabinoid._(11, 'CBD_A');
  static const Cannabinoid CBD_V = Cannabinoid._(12, 'CBD_V');
  static const Cannabinoid CBD_VA = Cannabinoid._(13, 'CBD_VA');
  static const Cannabinoid CBC = Cannabinoid._(20, 'CBC');
  static const Cannabinoid CBG = Cannabinoid._(30, 'CBG');
  static const Cannabinoid CBG_A = Cannabinoid._(31, 'CBG_A');
  static const Cannabinoid CBN = Cannabinoid._(40, 'CBN');
  static const Cannabinoid CBV = Cannabinoid._(50, 'CBV');
  static const Cannabinoid CBV_A = Cannabinoid._(51, 'CBV_A');

  static const $core.List<Cannabinoid> values = <Cannabinoid> [
    THC,
    THC_A,
    THC_V,
    CBD,
    CBD_A,
    CBD_V,
    CBD_VA,
    CBC,
    CBG,
    CBG_A,
    CBN,
    CBV,
    CBV_A,
  ];

  static final $core.Map<$core.int, Cannabinoid> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Cannabinoid valueOf($core.int value) => _byValue[value];

  const Cannabinoid._($core.int v, $core.String n) : super(v, n);
}

class CannabinoidRatio extends $pb.ProtobufEnum {
  static const CannabinoidRatio NO_CANNABINOID_PREFERENCE = CannabinoidRatio._(0, 'NO_CANNABINOID_PREFERENCE');
  static const CannabinoidRatio THC_ONLY = CannabinoidRatio._(1, 'THC_ONLY');
  static const CannabinoidRatio THC_OVER_CBD = CannabinoidRatio._(2, 'THC_OVER_CBD');
  static const CannabinoidRatio EQUAL = CannabinoidRatio._(3, 'EQUAL');
  static const CannabinoidRatio CBD_OVER_THC = CannabinoidRatio._(4, 'CBD_OVER_THC');
  static const CannabinoidRatio CBD_ONLY = CannabinoidRatio._(5, 'CBD_ONLY');

  static const $core.List<CannabinoidRatio> values = <CannabinoidRatio> [
    NO_CANNABINOID_PREFERENCE,
    THC_ONLY,
    THC_OVER_CBD,
    EQUAL,
    CBD_OVER_THC,
    CBD_ONLY,
  ];

  static final $core.Map<$core.int, CannabinoidRatio> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CannabinoidRatio valueOf($core.int value) => _byValue[value];

  const CannabinoidRatio._($core.int v, $core.String n) : super(v, n);
}

class Feeling extends $pb.ProtobufEnum {
  static const Feeling NO_FEELING_PREFERENCE = Feeling._(0, 'NO_FEELING_PREFERENCE');
  static const Feeling GROUNDING = Feeling._(1, 'GROUNDING');
  static const Feeling SLEEP = Feeling._(2, 'SLEEP');
  static const Feeling CALMING = Feeling._(3, 'CALMING');
  static const Feeling STIMULATING = Feeling._(4, 'STIMULATING');
  static const Feeling FUNNY = Feeling._(5, 'FUNNY');
  static const Feeling FOCUS = Feeling._(6, 'FOCUS');
  static const Feeling PASSION = Feeling._(7, 'PASSION');

  static const $core.List<Feeling> values = <Feeling> [
    NO_FEELING_PREFERENCE,
    GROUNDING,
    SLEEP,
    CALMING,
    STIMULATING,
    FUNNY,
    FOCUS,
    PASSION,
  ];

  static final $core.Map<$core.int, Feeling> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Feeling valueOf($core.int value) => _byValue[value];

  const Feeling._($core.int v, $core.String n) : super(v, n);
}

class TasteNote extends $pb.ProtobufEnum {
  static const TasteNote NO_TASTE_PREFERENCE = TasteNote._(0, 'NO_TASTE_PREFERENCE');
  static const TasteNote SWEET = TasteNote._(1, 'SWEET');
  static const TasteNote SOUR = TasteNote._(2, 'SOUR');
  static const TasteNote SPICE = TasteNote._(3, 'SPICE');
  static const TasteNote SMOOTH = TasteNote._(4, 'SMOOTH');
  static const TasteNote CITRUS = TasteNote._(5, 'CITRUS');
  static const TasteNote PINE = TasteNote._(6, 'PINE');
  static const TasteNote FRUIT = TasteNote._(7, 'FRUIT');
  static const TasteNote TROPICS = TasteNote._(8, 'TROPICS');
  static const TasteNote FLORAL = TasteNote._(9, 'FLORAL');
  static const TasteNote HERB = TasteNote._(10, 'HERB');
  static const TasteNote EARTH = TasteNote._(11, 'EARTH');

  static const $core.List<TasteNote> values = <TasteNote> [
    NO_TASTE_PREFERENCE,
    SWEET,
    SOUR,
    SPICE,
    SMOOTH,
    CITRUS,
    PINE,
    FRUIT,
    TROPICS,
    FLORAL,
    HERB,
    EARTH,
  ];

  static final $core.Map<$core.int, TasteNote> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TasteNote valueOf($core.int value) => _byValue[value];

  const TasteNote._($core.int v, $core.String n) : super(v, n);
}

class PotencyEstimate extends $pb.ProtobufEnum {
  static const PotencyEstimate LIGHT = PotencyEstimate._(0, 'LIGHT');
  static const PotencyEstimate MEDIUM = PotencyEstimate._(1, 'MEDIUM');
  static const PotencyEstimate HEAVY = PotencyEstimate._(2, 'HEAVY');
  static const PotencyEstimate SUPER = PotencyEstimate._(3, 'SUPER');

  static const $core.List<PotencyEstimate> values = <PotencyEstimate> [
    LIGHT,
    MEDIUM,
    HEAVY,
    SUPER,
  ];

  static final $core.Map<$core.int, PotencyEstimate> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PotencyEstimate valueOf($core.int value) => _byValue[value];

  const PotencyEstimate._($core.int v, $core.String n) : super(v, n);
}

class Terpene extends $pb.ProtobufEnum {
  static const Terpene CAMPHENE = Terpene._(0, 'CAMPHENE');
  static const Terpene CARENE = Terpene._(1, 'CARENE');
  static const Terpene BETA_CARYOPHYLLENE = Terpene._(2, 'BETA_CARYOPHYLLENE');
  static const Terpene CARYOPHYLLENE_OXIDE = Terpene._(3, 'CARYOPHYLLENE_OXIDE');
  static const Terpene EUCALYPTOL = Terpene._(4, 'EUCALYPTOL');
  static const Terpene FENCHOL = Terpene._(5, 'FENCHOL');
  static const Terpene ALPHA_HUMULENE = Terpene._(6, 'ALPHA_HUMULENE');
  static const Terpene LIMONENE = Terpene._(7, 'LIMONENE');
  static const Terpene LINALOOL = Terpene._(8, 'LINALOOL');
  static const Terpene MYRCENE = Terpene._(9, 'MYRCENE');
  static const Terpene ALPHA_OCIMENE = Terpene._(10, 'ALPHA_OCIMENE');
  static const Terpene BETA_OCIMENE = Terpene._(11, 'BETA_OCIMENE');
  static const Terpene ALPHA_PHELLANDRENE = Terpene._(12, 'ALPHA_PHELLANDRENE');
  static const Terpene ALPHA_PINENE = Terpene._(13, 'ALPHA_PINENE');
  static const Terpene BETA_PINENE = Terpene._(14, 'BETA_PINENE');
  static const Terpene ALPHA_TERPINEOL = Terpene._(15, 'ALPHA_TERPINEOL');
  static const Terpene ALPHA_TERPININE = Terpene._(16, 'ALPHA_TERPININE');
  static const Terpene GAMMA_TERPININE = Terpene._(17, 'GAMMA_TERPININE');
  static const Terpene TERPINOLENE = Terpene._(18, 'TERPINOLENE');
  static const Terpene VALENCENE = Terpene._(19, 'VALENCENE');
  static const Terpene GERANIOL = Terpene._(20, 'GERANIOL');
  static const Terpene PHELLANDRENE = Terpene._(21, 'PHELLANDRENE');
  static const Terpene BORNEOL = Terpene._(22, 'BORNEOL');
  static const Terpene ISOBORNEOL = Terpene._(23, 'ISOBORNEOL');
  static const Terpene BISABOLOL = Terpene._(24, 'BISABOLOL');
  static const Terpene PHYTOL = Terpene._(25, 'PHYTOL');
  static const Terpene SABINENE = Terpene._(26, 'SABINENE');
  static const Terpene CAMPHOR = Terpene._(27, 'CAMPHOR');
  static const Terpene MENTHOL = Terpene._(28, 'MENTHOL');
  static const Terpene CEDRENE = Terpene._(29, 'CEDRENE');
  static const Terpene NEROL = Terpene._(30, 'NEROL');
  static const Terpene NEROLIDOL = Terpene._(31, 'NEROLIDOL');
  static const Terpene GUAIOL = Terpene._(32, 'GUAIOL');
  static const Terpene ISOPULEGOL = Terpene._(33, 'ISOPULEGOL');
  static const Terpene GERANYL_ACETATE = Terpene._(34, 'GERANYL_ACETATE');
  static const Terpene CYMENE = Terpene._(35, 'CYMENE');
  static const Terpene PULEGONE = Terpene._(36, 'PULEGONE');
  static const Terpene CINEOLE = Terpene._(37, 'CINEOLE');
  static const Terpene FENCHONE = Terpene._(38, 'FENCHONE');
  static const Terpene TERPINENE = Terpene._(39, 'TERPINENE');
  static const Terpene CITRONELLOL = Terpene._(40, 'CITRONELLOL');
  static const Terpene DELTA_3_CARENE = Terpene._(41, 'DELTA_3_CARENE');

  static const $core.List<Terpene> values = <Terpene> [
    CAMPHENE,
    CARENE,
    BETA_CARYOPHYLLENE,
    CARYOPHYLLENE_OXIDE,
    EUCALYPTOL,
    FENCHOL,
    ALPHA_HUMULENE,
    LIMONENE,
    LINALOOL,
    MYRCENE,
    ALPHA_OCIMENE,
    BETA_OCIMENE,
    ALPHA_PHELLANDRENE,
    ALPHA_PINENE,
    BETA_PINENE,
    ALPHA_TERPINEOL,
    ALPHA_TERPININE,
    GAMMA_TERPININE,
    TERPINOLENE,
    VALENCENE,
    GERANIOL,
    PHELLANDRENE,
    BORNEOL,
    ISOBORNEOL,
    BISABOLOL,
    PHYTOL,
    SABINENE,
    CAMPHOR,
    MENTHOL,
    CEDRENE,
    NEROL,
    NEROLIDOL,
    GUAIOL,
    ISOPULEGOL,
    GERANYL_ACETATE,
    CYMENE,
    PULEGONE,
    CINEOLE,
    FENCHONE,
    TERPINENE,
    CITRONELLOL,
    DELTA_3_CARENE,
  ];

  static final $core.Map<$core.int, Terpene> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Terpene valueOf($core.int value) => _byValue[value];

  const Terpene._($core.int v, $core.String n) : super(v, n);
}

