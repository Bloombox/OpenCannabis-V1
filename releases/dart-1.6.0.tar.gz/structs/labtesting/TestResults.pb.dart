///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestResults.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'TestValue.pb.dart' as $38;
import '../../temporal/Instant.pb.dart' as $0;
import '../../content/Content.pb.dart' as $37;

import 'TestResults.pbenum.dart';

export 'TestResults.pbenum.dart';

class Contaminants extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Contaminants', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..a<Pesticides>(1, 'pesticides', $pb.PbFieldType.OM, Pesticides.getDefault, Pesticides.create)
    ..a<Metals>(2, 'metals', $pb.PbFieldType.OM, Metals.getDefault, Metals.create)
    ..a<MoldMildew>(3, 'moldMildew', $pb.PbFieldType.OM, MoldMildew.getDefault, MoldMildew.create)
    ..a<OtherContaminants>(4, 'otherContaminants', $pb.PbFieldType.OM, OtherContaminants.getDefault, OtherContaminants.create)
    ..hasRequiredFields = false
  ;

  Contaminants() : super();
  Contaminants.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Contaminants.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Contaminants clone() => Contaminants()..mergeFromMessage(this);
  Contaminants copyWith(void Function(Contaminants) updates) => super.copyWith((message) => updates(message as Contaminants));
  $pb.BuilderInfo get info_ => _i;
  static Contaminants create() => Contaminants();
  Contaminants createEmptyInstance() => create();
  static $pb.PbList<Contaminants> createRepeated() => $pb.PbList<Contaminants>();
  static Contaminants getDefault() => _defaultInstance ??= create()..freeze();
  static Contaminants _defaultInstance;

  Pesticides get pesticides => $_getN(0);
  set pesticides(Pesticides v) { setField(1, v); }
  $core.bool hasPesticides() => $_has(0);
  void clearPesticides() => clearField(1);

  Metals get metals => $_getN(1);
  set metals(Metals v) { setField(2, v); }
  $core.bool hasMetals() => $_has(1);
  void clearMetals() => clearField(2);

  MoldMildew get moldMildew => $_getN(2);
  set moldMildew(MoldMildew v) { setField(3, v); }
  $core.bool hasMoldMildew() => $_has(2);
  void clearMoldMildew() => clearField(3);

  OtherContaminants get otherContaminants => $_getN(3);
  set otherContaminants(OtherContaminants v) { setField(4, v); }
  $core.bool hasOtherContaminants() => $_has(3);
  void clearOtherContaminants() => clearField(4);
}

class TestSuite extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestSuite', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<TestMethod>(1, 'method', $pb.PbFieldType.OE, TestMethod.UNSPECIFIED_METHOD, TestMethod.valueOf, TestMethod.values)
    ..a<TestResults>(2, 'results', $pb.PbFieldType.OM, TestResults.getDefault, TestResults.create)
    ..aOS(3, 'comments')
    ..hasRequiredFields = false
  ;

  TestSuite() : super();
  TestSuite.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestSuite.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestSuite clone() => TestSuite()..mergeFromMessage(this);
  TestSuite copyWith(void Function(TestSuite) updates) => super.copyWith((message) => updates(message as TestSuite));
  $pb.BuilderInfo get info_ => _i;
  static TestSuite create() => TestSuite();
  TestSuite createEmptyInstance() => create();
  static $pb.PbList<TestSuite> createRepeated() => $pb.PbList<TestSuite>();
  static TestSuite getDefault() => _defaultInstance ??= create()..freeze();
  static TestSuite _defaultInstance;

  TestMethod get method => $_getN(0);
  set method(TestMethod v) { setField(1, v); }
  $core.bool hasMethod() => $_has(0);
  void clearMethod() => clearField(1);

  TestResults get results => $_getN(1);
  set results(TestResults v) { setField(2, v); }
  $core.bool hasResults() => $_has(1);
  void clearResults() => clearField(2);

  $core.String get comments => $_getS(2, '');
  set comments($core.String v) { $_setString(2, v); }
  $core.bool hasComments() => $_has(2);
  void clearComments() => clearField(3);
}

class TestResults extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestResults', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOB(1, 'available')
    ..pc<$38.TestMedia>(2, 'media', $pb.PbFieldType.PM,$38.TestMedia.create)
    ..a<$0.Instant>(3, 'lastUpdated', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(4, 'sealed', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<TestCoordinates>(5, 'coordinates', $pb.PbFieldType.OM, TestCoordinates.getDefault, TestCoordinates.create)
    ..a<Cannabinoids>(30, 'cannabinoids', $pb.PbFieldType.OM, Cannabinoids.getDefault, Cannabinoids.create)
    ..a<Terpenes>(31, 'terpenes', $pb.PbFieldType.OM, Terpenes.getDefault, Terpenes.create)
    ..a<Contaminants>(32, 'contaminants', $pb.PbFieldType.OM, Contaminants.getDefault, Contaminants.create)
    ..a<Moisture>(33, 'moisture', $pb.PbFieldType.OM, Moisture.getDefault, Moisture.create)
    ..a<Subjective>(34, 'subjective', $pb.PbFieldType.OM, Subjective.getDefault, Subjective.create)
    ..pc<TasteNote>(35, 'aroma', $pb.PbFieldType.PE, null, TasteNote.valueOf, TasteNote.values)
    ..pc<TestResults>(36, 'data', $pb.PbFieldType.PM,TestResults.create)
    ..hasRequiredFields = false
  ;

  TestResults() : super();
  TestResults.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestResults.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestResults clone() => TestResults()..mergeFromMessage(this);
  TestResults copyWith(void Function(TestResults) updates) => super.copyWith((message) => updates(message as TestResults));
  $pb.BuilderInfo get info_ => _i;
  static TestResults create() => TestResults();
  TestResults createEmptyInstance() => create();
  static $pb.PbList<TestResults> createRepeated() => $pb.PbList<TestResults>();
  static TestResults getDefault() => _defaultInstance ??= create()..freeze();
  static TestResults _defaultInstance;

  $core.bool get available => $_get(0, false);
  set available($core.bool v) { $_setBool(0, v); }
  $core.bool hasAvailable() => $_has(0);
  void clearAvailable() => clearField(1);

  $core.List<$38.TestMedia> get media => $_getList(1);

  $0.Instant get lastUpdated => $_getN(2);
  set lastUpdated($0.Instant v) { setField(3, v); }
  $core.bool hasLastUpdated() => $_has(2);
  void clearLastUpdated() => clearField(3);

  $0.Instant get sealed => $_getN(3);
  set sealed($0.Instant v) { setField(4, v); }
  $core.bool hasSealed() => $_has(3);
  void clearSealed() => clearField(4);

  TestCoordinates get coordinates => $_getN(4);
  set coordinates(TestCoordinates v) { setField(5, v); }
  $core.bool hasCoordinates() => $_has(4);
  void clearCoordinates() => clearField(5);

  Cannabinoids get cannabinoids => $_getN(5);
  set cannabinoids(Cannabinoids v) { setField(30, v); }
  $core.bool hasCannabinoids() => $_has(5);
  void clearCannabinoids() => clearField(30);

  Terpenes get terpenes => $_getN(6);
  set terpenes(Terpenes v) { setField(31, v); }
  $core.bool hasTerpenes() => $_has(6);
  void clearTerpenes() => clearField(31);

  Contaminants get contaminants => $_getN(7);
  set contaminants(Contaminants v) { setField(32, v); }
  $core.bool hasContaminants() => $_has(7);
  void clearContaminants() => clearField(32);

  Moisture get moisture => $_getN(8);
  set moisture(Moisture v) { setField(33, v); }
  $core.bool hasMoisture() => $_has(8);
  void clearMoisture() => clearField(33);

  Subjective get subjective => $_getN(9);
  set subjective(Subjective v) { setField(34, v); }
  $core.bool hasSubjective() => $_has(9);
  void clearSubjective() => clearField(34);

  $core.List<TasteNote> get aroma => $_getList(10);

  $core.List<TestResults> get data => $_getList(11);
}

class TestCoordinates extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestCoordinates', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOS(1, 'zone')
    ..aOS(2, 'lot')
    ..aOS(3, 'batch')
    ..aOS(4, 'sampleId')
    ..hasRequiredFields = false
  ;

  TestCoordinates() : super();
  TestCoordinates.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestCoordinates.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestCoordinates clone() => TestCoordinates()..mergeFromMessage(this);
  TestCoordinates copyWith(void Function(TestCoordinates) updates) => super.copyWith((message) => updates(message as TestCoordinates));
  $pb.BuilderInfo get info_ => _i;
  static TestCoordinates create() => TestCoordinates();
  TestCoordinates createEmptyInstance() => create();
  static $pb.PbList<TestCoordinates> createRepeated() => $pb.PbList<TestCoordinates>();
  static TestCoordinates getDefault() => _defaultInstance ??= create()..freeze();
  static TestCoordinates _defaultInstance;

  $core.String get zone => $_getS(0, '');
  set zone($core.String v) { $_setString(0, v); }
  $core.bool hasZone() => $_has(0);
  void clearZone() => clearField(1);

  $core.String get lot => $_getS(1, '');
  set lot($core.String v) { $_setString(1, v); }
  $core.bool hasLot() => $_has(1);
  void clearLot() => clearField(2);

  $core.String get batch => $_getS(2, '');
  set batch($core.String v) { $_setString(2, v); }
  $core.bool hasBatch() => $_has(2);
  void clearBatch() => clearField(3);

  $core.String get sampleId => $_getS(3, '');
  set sampleId($core.String v) { $_setString(3, v); }
  $core.bool hasSampleId() => $_has(3);
  void clearSampleId() => clearField(4);
}

class Cannabinoids_Result extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Cannabinoids.Result', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<Cannabinoid>(1, 'cannabinoid', $pb.PbFieldType.OE, Cannabinoid.THC, Cannabinoid.valueOf, Cannabinoid.values)
    ..a<$38.TestValue>(3, 'measurement', $pb.PbFieldType.OM, $38.TestValue.getDefault, $38.TestValue.create)
    ..hasRequiredFields = false
  ;

  Cannabinoids_Result() : super();
  Cannabinoids_Result.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Cannabinoids_Result.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Cannabinoids_Result clone() => Cannabinoids_Result()..mergeFromMessage(this);
  Cannabinoids_Result copyWith(void Function(Cannabinoids_Result) updates) => super.copyWith((message) => updates(message as Cannabinoids_Result));
  $pb.BuilderInfo get info_ => _i;
  static Cannabinoids_Result create() => Cannabinoids_Result();
  Cannabinoids_Result createEmptyInstance() => create();
  static $pb.PbList<Cannabinoids_Result> createRepeated() => $pb.PbList<Cannabinoids_Result>();
  static Cannabinoids_Result getDefault() => _defaultInstance ??= create()..freeze();
  static Cannabinoids_Result _defaultInstance;

  Cannabinoid get cannabinoid => $_getN(0);
  set cannabinoid(Cannabinoid v) { setField(1, v); }
  $core.bool hasCannabinoid() => $_has(0);
  void clearCannabinoid() => clearField(1);

  $38.TestValue get measurement => $_getN(1);
  set measurement($38.TestValue v) { setField(3, v); }
  $core.bool hasMeasurement() => $_has(1);
  void clearMeasurement() => clearField(3);
}

class Cannabinoids extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Cannabinoids', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..a<$38.TestValue>(1, 'thc', $pb.PbFieldType.OM, $38.TestValue.getDefault, $38.TestValue.create)
    ..a<$38.TestValue>(2, 'cbd', $pb.PbFieldType.OM, $38.TestValue.getDefault, $38.TestValue.create)
    ..pc<Cannabinoids_Result>(3, 'results', $pb.PbFieldType.PM,Cannabinoids_Result.create)
    ..e<CannabinoidRatio>(4, 'ratio', $pb.PbFieldType.OE, CannabinoidRatio.NO_CANNABINOID_PREFERENCE, CannabinoidRatio.valueOf, CannabinoidRatio.values)
    ..e<PotencyEstimate>(5, 'potency', $pb.PbFieldType.OE, PotencyEstimate.LIGHT, PotencyEstimate.valueOf, PotencyEstimate.values)
    ..hasRequiredFields = false
  ;

  Cannabinoids() : super();
  Cannabinoids.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Cannabinoids.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Cannabinoids clone() => Cannabinoids()..mergeFromMessage(this);
  Cannabinoids copyWith(void Function(Cannabinoids) updates) => super.copyWith((message) => updates(message as Cannabinoids));
  $pb.BuilderInfo get info_ => _i;
  static Cannabinoids create() => Cannabinoids();
  Cannabinoids createEmptyInstance() => create();
  static $pb.PbList<Cannabinoids> createRepeated() => $pb.PbList<Cannabinoids>();
  static Cannabinoids getDefault() => _defaultInstance ??= create()..freeze();
  static Cannabinoids _defaultInstance;

  $38.TestValue get thc => $_getN(0);
  set thc($38.TestValue v) { setField(1, v); }
  $core.bool hasThc() => $_has(0);
  void clearThc() => clearField(1);

  $38.TestValue get cbd => $_getN(1);
  set cbd($38.TestValue v) { setField(2, v); }
  $core.bool hasCbd() => $_has(1);
  void clearCbd() => clearField(2);

  $core.List<Cannabinoids_Result> get results => $_getList(2);

  CannabinoidRatio get ratio => $_getN(3);
  set ratio(CannabinoidRatio v) { setField(4, v); }
  $core.bool hasRatio() => $_has(3);
  void clearRatio() => clearField(4);

  PotencyEstimate get potency => $_getN(4);
  set potency(PotencyEstimate v) { setField(5, v); }
  $core.bool hasPotency() => $_has(4);
  void clearPotency() => clearField(5);
}

class Subjective extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Subjective', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..a<$37.Content>(1, 'description', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..a<$37.Content>(2, 'taste', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..e<PotencyEstimate>(3, 'potency', $pb.PbFieldType.OE, PotencyEstimate.LIGHT, PotencyEstimate.valueOf, PotencyEstimate.values)
    ..pc<Feeling>(4, 'feeling', $pb.PbFieldType.PE, null, Feeling.valueOf, Feeling.values)
    ..pc<TasteNote>(5, 'aroma', $pb.PbFieldType.PE, null, TasteNote.valueOf, TasteNote.values)
    ..hasRequiredFields = false
  ;

  Subjective() : super();
  Subjective.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Subjective.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Subjective clone() => Subjective()..mergeFromMessage(this);
  Subjective copyWith(void Function(Subjective) updates) => super.copyWith((message) => updates(message as Subjective));
  $pb.BuilderInfo get info_ => _i;
  static Subjective create() => Subjective();
  Subjective createEmptyInstance() => create();
  static $pb.PbList<Subjective> createRepeated() => $pb.PbList<Subjective>();
  static Subjective getDefault() => _defaultInstance ??= create()..freeze();
  static Subjective _defaultInstance;

  $37.Content get description => $_getN(0);
  set description($37.Content v) { setField(1, v); }
  $core.bool hasDescription() => $_has(0);
  void clearDescription() => clearField(1);

  $37.Content get taste => $_getN(1);
  set taste($37.Content v) { setField(2, v); }
  $core.bool hasTaste() => $_has(1);
  void clearTaste() => clearField(2);

  PotencyEstimate get potency => $_getN(2);
  set potency(PotencyEstimate v) { setField(3, v); }
  $core.bool hasPotency() => $_has(2);
  void clearPotency() => clearField(3);

  $core.List<Feeling> get feeling => $_getList(3);

  $core.List<TasteNote> get aroma => $_getList(4);
}

class Pesticides extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Pesticides', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOB(1, 'pesticideFree')
    ..m<$core.String, $38.TestValue>(2, 'measurements', 'Pesticides.MeasurementsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $38.TestValue.create, null, null , const $pb.PackageName('opencannabis.structs.labtesting'))
    ..hasRequiredFields = false
  ;

  Pesticides() : super();
  Pesticides.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Pesticides.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Pesticides clone() => Pesticides()..mergeFromMessage(this);
  Pesticides copyWith(void Function(Pesticides) updates) => super.copyWith((message) => updates(message as Pesticides));
  $pb.BuilderInfo get info_ => _i;
  static Pesticides create() => Pesticides();
  Pesticides createEmptyInstance() => create();
  static $pb.PbList<Pesticides> createRepeated() => $pb.PbList<Pesticides>();
  static Pesticides getDefault() => _defaultInstance ??= create()..freeze();
  static Pesticides _defaultInstance;

  $core.bool get pesticideFree => $_get(0, false);
  set pesticideFree($core.bool v) { $_setBool(0, v); }
  $core.bool hasPesticideFree() => $_has(0);
  void clearPesticideFree() => clearField(1);

  $core.Map<$core.String, $38.TestValue> get measurements => $_getMap(1);
}

class Metals extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Metals', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOB(1, 'metalFree')
    ..m<$core.String, $38.TestValue>(2, 'measurements', 'Metals.MeasurementsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $38.TestValue.create, null, null , const $pb.PackageName('opencannabis.structs.labtesting'))
    ..hasRequiredFields = false
  ;

  Metals() : super();
  Metals.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Metals.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Metals clone() => Metals()..mergeFromMessage(this);
  Metals copyWith(void Function(Metals) updates) => super.copyWith((message) => updates(message as Metals));
  $pb.BuilderInfo get info_ => _i;
  static Metals create() => Metals();
  Metals createEmptyInstance() => create();
  static $pb.PbList<Metals> createRepeated() => $pb.PbList<Metals>();
  static Metals getDefault() => _defaultInstance ??= create()..freeze();
  static Metals _defaultInstance;

  $core.bool get metalFree => $_get(0, false);
  set metalFree($core.bool v) { $_setBool(0, v); }
  $core.bool hasMetalFree() => $_has(0);
  void clearMetalFree() => clearField(1);

  $core.Map<$core.String, $38.TestValue> get measurements => $_getMap(1);
}

class MoldMildew extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MoldMildew', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOB(1, 'moldMildewFree')
    ..m<$core.String, $38.TestValue>(2, 'measurements', 'MoldMildew.MeasurementsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $38.TestValue.create, null, null , const $pb.PackageName('opencannabis.structs.labtesting'))
    ..hasRequiredFields = false
  ;

  MoldMildew() : super();
  MoldMildew.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MoldMildew.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MoldMildew clone() => MoldMildew()..mergeFromMessage(this);
  MoldMildew copyWith(void Function(MoldMildew) updates) => super.copyWith((message) => updates(message as MoldMildew));
  $pb.BuilderInfo get info_ => _i;
  static MoldMildew create() => MoldMildew();
  MoldMildew createEmptyInstance() => create();
  static $pb.PbList<MoldMildew> createRepeated() => $pb.PbList<MoldMildew>();
  static MoldMildew getDefault() => _defaultInstance ??= create()..freeze();
  static MoldMildew _defaultInstance;

  $core.bool get moldMildewFree => $_get(0, false);
  set moldMildewFree($core.bool v) { $_setBool(0, v); }
  $core.bool hasMoldMildewFree() => $_has(0);
  void clearMoldMildewFree() => clearField(1);

  $core.Map<$core.String, $38.TestValue> get measurements => $_getMap(1);
}

class OtherContaminants extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OtherContaminants', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..m<$core.String, $38.TestValue>(1, 'measurements', 'OtherContaminants.MeasurementsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $38.TestValue.create, null, null , const $pb.PackageName('opencannabis.structs.labtesting'))
    ..hasRequiredFields = false
  ;

  OtherContaminants() : super();
  OtherContaminants.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OtherContaminants.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OtherContaminants clone() => OtherContaminants()..mergeFromMessage(this);
  OtherContaminants copyWith(void Function(OtherContaminants) updates) => super.copyWith((message) => updates(message as OtherContaminants));
  $pb.BuilderInfo get info_ => _i;
  static OtherContaminants create() => OtherContaminants();
  OtherContaminants createEmptyInstance() => create();
  static $pb.PbList<OtherContaminants> createRepeated() => $pb.PbList<OtherContaminants>();
  static OtherContaminants getDefault() => _defaultInstance ??= create()..freeze();
  static OtherContaminants _defaultInstance;

  $core.Map<$core.String, $38.TestValue> get measurements => $_getMap(0);
}

class Moisture extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Moisture', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..a<$38.TestValue>(1, 'measurement', $pb.PbFieldType.OM, $38.TestValue.getDefault, $38.TestValue.create)
    ..hasRequiredFields = false
  ;

  Moisture() : super();
  Moisture.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Moisture.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Moisture clone() => Moisture()..mergeFromMessage(this);
  Moisture copyWith(void Function(Moisture) updates) => super.copyWith((message) => updates(message as Moisture));
  $pb.BuilderInfo get info_ => _i;
  static Moisture create() => Moisture();
  Moisture createEmptyInstance() => create();
  static $pb.PbList<Moisture> createRepeated() => $pb.PbList<Moisture>();
  static Moisture getDefault() => _defaultInstance ??= create()..freeze();
  static Moisture _defaultInstance;

  $38.TestValue get measurement => $_getN(0);
  set measurement($38.TestValue v) { setField(1, v); }
  $core.bool hasMeasurement() => $_has(0);
  void clearMeasurement() => clearField(1);
}

class Terpenes_Result extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Terpenes.Result', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<Terpene>(1, 'terpene', $pb.PbFieldType.OE, Terpene.CAMPHENE, Terpene.valueOf, Terpene.values)
    ..a<$38.TestValue>(2, 'measurement', $pb.PbFieldType.OM, $38.TestValue.getDefault, $38.TestValue.create)
    ..hasRequiredFields = false
  ;

  Terpenes_Result() : super();
  Terpenes_Result.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Terpenes_Result.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Terpenes_Result clone() => Terpenes_Result()..mergeFromMessage(this);
  Terpenes_Result copyWith(void Function(Terpenes_Result) updates) => super.copyWith((message) => updates(message as Terpenes_Result));
  $pb.BuilderInfo get info_ => _i;
  static Terpenes_Result create() => Terpenes_Result();
  Terpenes_Result createEmptyInstance() => create();
  static $pb.PbList<Terpenes_Result> createRepeated() => $pb.PbList<Terpenes_Result>();
  static Terpenes_Result getDefault() => _defaultInstance ??= create()..freeze();
  static Terpenes_Result _defaultInstance;

  Terpene get terpene => $_getN(0);
  set terpene(Terpene v) { setField(1, v); }
  $core.bool hasTerpene() => $_has(0);
  void clearTerpene() => clearField(1);

  $38.TestValue get measurement => $_getN(1);
  set measurement($38.TestValue v) { setField(2, v); }
  $core.bool hasMeasurement() => $_has(1);
  void clearMeasurement() => clearField(2);
}

class Terpenes extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Terpenes', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..aOB(1, 'available')
    ..pc<Feeling>(2, 'feeling', $pb.PbFieldType.PE, null, Feeling.valueOf, Feeling.values)
    ..pc<TasteNote>(3, 'aroma', $pb.PbFieldType.PE, null, TasteNote.valueOf, TasteNote.values)
    ..pc<Terpenes_Result>(10, 'terpene', $pb.PbFieldType.PM,Terpenes_Result.create)
    ..hasRequiredFields = false
  ;

  Terpenes() : super();
  Terpenes.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Terpenes.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Terpenes clone() => Terpenes()..mergeFromMessage(this);
  Terpenes copyWith(void Function(Terpenes) updates) => super.copyWith((message) => updates(message as Terpenes));
  $pb.BuilderInfo get info_ => _i;
  static Terpenes create() => Terpenes();
  Terpenes createEmptyInstance() => create();
  static $pb.PbList<Terpenes> createRepeated() => $pb.PbList<Terpenes>();
  static Terpenes getDefault() => _defaultInstance ??= create()..freeze();
  static Terpenes _defaultInstance;

  $core.bool get available => $_get(0, false);
  set available($core.bool v) { $_setBool(0, v); }
  $core.bool hasAvailable() => $_has(0);
  void clearAvailable() => clearField(1);

  $core.List<Feeling> get feeling => $_getList(1);

  $core.List<TasteNote> get aroma => $_getList(2);

  $core.List<Terpenes_Result> get terpene => $_getList(3);
}

