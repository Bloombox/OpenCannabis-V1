///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestValue.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const TestValueType$json = const {
  '1': 'TestValueType',
  '2': const [
    const {'1': 'MILLIGRAMS', '2': 0},
    const {'1': 'PERCENTAGE', '2': 1},
    const {'1': 'PRESENCE', '2': 2},
  ],
};

const TestErrorType$json = const {
  '1': 'TestErrorType',
  '2': const [
    const {'1': 'PERCENT', '2': 0},
    const {'1': 'ABSOLUTE', '2': 1},
    const {'1': 'RELATIVE', '2': 2},
  ],
};

const TestMediaType$json = const {
  '1': 'TestMediaType',
  '2': const [
    const {'1': 'CERTIFICATE', '2': 0},
    const {'1': 'RESULTS', '2': 1},
    const {'1': 'PRODUCT_IMAGE', '2': 2},
  ],
};

const TestValue$json = const {
  '1': 'TestValue',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.TestValueType', '10': 'type'},
    const {'1': 'error', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue.TestError', '10': 'error'},
    const {'1': 'measurement', '3': 10, '4': 1, '5': 1, '9': 0, '10': 'measurement'},
    const {'1': 'present', '3': 20, '4': 1, '5': 8, '9': 0, '10': 'present'},
  ],
  '3': const [TestValue_TestError$json],
  '8': const [
    const {'1': 'value'},
  ],
};

const TestValue_TestError$json = const {
  '1': 'TestError',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.TestErrorType', '10': 'type'},
    const {'1': 'value', '3': 2, '4': 1, '5': 1, '10': 'value'},
  ],
};

const TestMedia$json = const {
  '1': 'TestMedia',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.TestMediaType', '10': 'type'},
    const {'1': 'media_item', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '10': 'mediaItem'},
  ],
};

