///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestResults.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const TestMethod$json = const {
  '1': 'TestMethod',
  '2': const [
    const {'1': 'UNSPECIFIED_METHOD', '2': 0},
    const {'1': 'GCMS', '2': 1},
    const {'1': 'LCMS', '2': 2},
    const {'1': 'CLASSIC_PCR', '2': 3},
    const {'1': 'qPCR', '2': 4},
    const {'1': 'ELISA', '2': 5},
  ],
};

const Cannabinoid$json = const {
  '1': 'Cannabinoid',
  '2': const [
    const {'1': 'THC', '2': 0},
    const {'1': 'THC_A', '2': 1},
    const {'1': 'THC_V', '2': 2},
    const {'1': 'CBD', '2': 10},
    const {'1': 'CBD_A', '2': 11},
    const {'1': 'CBD_V', '2': 12},
    const {'1': 'CBD_VA', '2': 13},
    const {'1': 'CBC', '2': 20},
    const {'1': 'CBG', '2': 30},
    const {'1': 'CBG_A', '2': 31},
    const {'1': 'CBN', '2': 40},
    const {'1': 'CBV', '2': 50},
    const {'1': 'CBV_A', '2': 51},
  ],
};

const CannabinoidRatio$json = const {
  '1': 'CannabinoidRatio',
  '2': const [
    const {'1': 'NO_CANNABINOID_PREFERENCE', '2': 0},
    const {'1': 'THC_ONLY', '2': 1},
    const {'1': 'THC_OVER_CBD', '2': 2},
    const {'1': 'EQUAL', '2': 3},
    const {'1': 'CBD_OVER_THC', '2': 4},
    const {'1': 'CBD_ONLY', '2': 5},
  ],
};

const Feeling$json = const {
  '1': 'Feeling',
  '2': const [
    const {'1': 'NO_FEELING_PREFERENCE', '2': 0},
    const {'1': 'GROUNDING', '2': 1},
    const {'1': 'SLEEP', '2': 2},
    const {'1': 'CALMING', '2': 3},
    const {'1': 'STIMULATING', '2': 4},
    const {'1': 'FUNNY', '2': 5},
    const {'1': 'FOCUS', '2': 6},
    const {'1': 'PASSION', '2': 7},
  ],
};

const TasteNote$json = const {
  '1': 'TasteNote',
  '2': const [
    const {'1': 'NO_TASTE_PREFERENCE', '2': 0},
    const {'1': 'SWEET', '2': 1},
    const {'1': 'SOUR', '2': 2},
    const {'1': 'SPICE', '2': 3},
    const {'1': 'SMOOTH', '2': 4},
    const {'1': 'CITRUS', '2': 5},
    const {'1': 'PINE', '2': 6},
    const {'1': 'FRUIT', '2': 7},
    const {'1': 'TROPICS', '2': 8},
    const {'1': 'FLORAL', '2': 9},
    const {'1': 'HERB', '2': 10},
    const {'1': 'EARTH', '2': 11},
  ],
};

const PotencyEstimate$json = const {
  '1': 'PotencyEstimate',
  '2': const [
    const {'1': 'LIGHT', '2': 0},
    const {'1': 'MEDIUM', '2': 1},
    const {'1': 'HEAVY', '2': 2},
    const {'1': 'SUPER', '2': 3},
  ],
};

const Terpene$json = const {
  '1': 'Terpene',
  '2': const [
    const {'1': 'CAMPHENE', '2': 0},
    const {'1': 'CARENE', '2': 1},
    const {'1': 'BETA_CARYOPHYLLENE', '2': 2},
    const {'1': 'CARYOPHYLLENE_OXIDE', '2': 3},
    const {'1': 'EUCALYPTOL', '2': 4},
    const {'1': 'FENCHOL', '2': 5},
    const {'1': 'ALPHA_HUMULENE', '2': 6},
    const {'1': 'LIMONENE', '2': 7},
    const {'1': 'LINALOOL', '2': 8},
    const {'1': 'MYRCENE', '2': 9},
    const {'1': 'ALPHA_OCIMENE', '2': 10},
    const {'1': 'BETA_OCIMENE', '2': 11},
    const {'1': 'ALPHA_PHELLANDRENE', '2': 12},
    const {'1': 'ALPHA_PINENE', '2': 13},
    const {'1': 'BETA_PINENE', '2': 14},
    const {'1': 'ALPHA_TERPINEOL', '2': 15},
    const {'1': 'ALPHA_TERPININE', '2': 16},
    const {'1': 'GAMMA_TERPININE', '2': 17},
    const {'1': 'TERPINOLENE', '2': 18},
    const {'1': 'VALENCENE', '2': 19},
    const {'1': 'GERANIOL', '2': 20},
    const {'1': 'PHELLANDRENE', '2': 21},
    const {'1': 'BORNEOL', '2': 22},
    const {'1': 'ISOBORNEOL', '2': 23},
    const {'1': 'BISABOLOL', '2': 24},
    const {'1': 'PHYTOL', '2': 25},
    const {'1': 'SABINENE', '2': 26},
    const {'1': 'CAMPHOR', '2': 27},
    const {'1': 'MENTHOL', '2': 28},
    const {'1': 'CEDRENE', '2': 29},
    const {'1': 'NEROL', '2': 30},
    const {'1': 'NEROLIDOL', '2': 31},
    const {'1': 'GUAIOL', '2': 32},
    const {'1': 'ISOPULEGOL', '2': 33},
    const {'1': 'GERANYL_ACETATE', '2': 34},
    const {'1': 'CYMENE', '2': 35},
    const {'1': 'PULEGONE', '2': 36},
    const {'1': 'CINEOLE', '2': 37},
    const {'1': 'FENCHONE', '2': 38},
    const {'1': 'TERPINENE', '2': 39},
    const {'1': 'CITRONELLOL', '2': 40},
    const {'1': 'DELTA_3_CARENE', '2': 41},
  ],
};

const Contaminants$json = const {
  '1': 'Contaminants',
  '2': const [
    const {'1': 'pesticides', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Pesticides', '10': 'pesticides'},
    const {'1': 'metals', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Metals', '10': 'metals'},
    const {'1': 'mold_mildew', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.MoldMildew', '10': 'moldMildew'},
    const {'1': 'other_contaminants', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.OtherContaminants', '10': 'otherContaminants'},
  ],
};

const TestSuite$json = const {
  '1': 'TestSuite',
  '2': const [
    const {'1': 'method', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.TestMethod', '10': 'method'},
    const {'1': 'results', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestResults', '10': 'results'},
    const {'1': 'comments', '3': 3, '4': 1, '5': 9, '10': 'comments'},
  ],
};

const TestResults$json = const {
  '1': 'TestResults',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'media', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.TestMedia', '10': 'media'},
    const {'1': 'last_updated', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'lastUpdated'},
    const {'1': 'sealed', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'sealed'},
    const {'1': 'coordinates', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestCoordinates', '10': 'coordinates'},
    const {'1': 'cannabinoids', '3': 30, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Cannabinoids', '10': 'cannabinoids'},
    const {'1': 'terpenes', '3': 31, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Terpenes', '10': 'terpenes'},
    const {'1': 'contaminants', '3': 32, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Contaminants', '10': 'contaminants'},
    const {'1': 'moisture', '3': 33, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Moisture', '10': 'moisture'},
    const {'1': 'subjective', '3': 34, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.Subjective', '10': 'subjective'},
    const {'1': 'aroma', '3': 35, '4': 3, '5': 14, '6': '.opencannabis.structs.labtesting.TasteNote', '10': 'aroma'},
    const {'1': 'data', '3': 36, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.TestResults', '10': 'data'},
  ],
};

const TestCoordinates$json = const {
  '1': 'TestCoordinates',
  '2': const [
    const {'1': 'zone', '3': 1, '4': 1, '5': 9, '10': 'zone'},
    const {'1': 'lot', '3': 2, '4': 1, '5': 9, '10': 'lot'},
    const {'1': 'batch', '3': 3, '4': 1, '5': 9, '10': 'batch'},
    const {'1': 'sample_id', '3': 4, '4': 1, '5': 9, '10': 'sampleId'},
  ],
};

const Cannabinoids$json = const {
  '1': 'Cannabinoids',
  '2': const [
    const {'1': 'thc', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'thc'},
    const {'1': 'cbd', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'cbd'},
    const {'1': 'results', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.Cannabinoids.Result', '10': 'results'},
    const {'1': 'ratio', '3': 4, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.CannabinoidRatio', '10': 'ratio'},
    const {'1': 'potency', '3': 5, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.PotencyEstimate', '10': 'potency'},
  ],
  '3': const [Cannabinoids_Result$json],
};

const Cannabinoids_Result$json = const {
  '1': 'Result',
  '2': const [
    const {'1': 'cannabinoid', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.Cannabinoid', '10': 'cannabinoid'},
    const {'1': 'measurement', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

const Subjective$json = const {
  '1': 'Subjective',
  '2': const [
    const {'1': 'description', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'description'},
    const {'1': 'taste', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'taste'},
    const {'1': 'potency', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.PotencyEstimate', '10': 'potency'},
    const {'1': 'feeling', '3': 4, '4': 3, '5': 14, '6': '.opencannabis.structs.labtesting.Feeling', '10': 'feeling'},
    const {'1': 'aroma', '3': 5, '4': 3, '5': 14, '6': '.opencannabis.structs.labtesting.TasteNote', '10': 'aroma'},
  ],
};

const Pesticides$json = const {
  '1': 'Pesticides',
  '2': const [
    const {'1': 'pesticide_free', '3': 1, '4': 1, '5': 8, '10': 'pesticideFree'},
    const {'1': 'measurements', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.Pesticides.MeasurementsEntry', '10': 'measurements'},
  ],
  '3': const [Pesticides_MeasurementsEntry$json],
};

const Pesticides_MeasurementsEntry$json = const {
  '1': 'MeasurementsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'value'},
  ],
  '7': const {'7': true},
};

const Metals$json = const {
  '1': 'Metals',
  '2': const [
    const {'1': 'metal_free', '3': 1, '4': 1, '5': 8, '10': 'metalFree'},
    const {'1': 'measurements', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.Metals.MeasurementsEntry', '10': 'measurements'},
  ],
  '3': const [Metals_MeasurementsEntry$json],
};

const Metals_MeasurementsEntry$json = const {
  '1': 'MeasurementsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'value'},
  ],
  '7': const {'7': true},
};

const MoldMildew$json = const {
  '1': 'MoldMildew',
  '2': const [
    const {'1': 'mold_mildew_free', '3': 1, '4': 1, '5': 8, '10': 'moldMildewFree'},
    const {'1': 'measurements', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.MoldMildew.MeasurementsEntry', '10': 'measurements'},
  ],
  '3': const [MoldMildew_MeasurementsEntry$json],
};

const MoldMildew_MeasurementsEntry$json = const {
  '1': 'MeasurementsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'value'},
  ],
  '7': const {'7': true},
};

const OtherContaminants$json = const {
  '1': 'OtherContaminants',
  '2': const [
    const {'1': 'measurements', '3': 1, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.OtherContaminants.MeasurementsEntry', '10': 'measurements'},
  ],
  '3': const [OtherContaminants_MeasurementsEntry$json],
};

const OtherContaminants_MeasurementsEntry$json = const {
  '1': 'MeasurementsEntry',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 9, '10': 'key'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'value'},
  ],
  '7': const {'7': true},
};

const Moisture$json = const {
  '1': 'Moisture',
  '2': const [
    const {'1': 'measurement', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

const Terpenes$json = const {
  '1': 'Terpenes',
  '2': const [
    const {'1': 'available', '3': 1, '4': 1, '5': 8, '10': 'available'},
    const {'1': 'terpene', '3': 10, '4': 3, '5': 11, '6': '.opencannabis.structs.labtesting.Terpenes.Result', '10': 'terpene'},
    const {'1': 'feeling', '3': 2, '4': 3, '5': 14, '6': '.opencannabis.structs.labtesting.Feeling', '10': 'feeling'},
    const {'1': 'aroma', '3': 3, '4': 3, '5': 14, '6': '.opencannabis.structs.labtesting.TasteNote', '10': 'aroma'},
  ],
  '3': const [Terpenes_Result$json],
};

const Terpenes_Result$json = const {
  '1': 'Result',
  '2': const [
    const {'1': 'terpene', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.labtesting.Terpene', '10': 'terpene'},
    const {'1': 'measurement', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestValue', '10': 'measurement'},
  ],
};

