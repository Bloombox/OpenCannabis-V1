///
//  Generated code. Do not modify.
//  source: structs/Shelf.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Shelf$json = const {
  '1': 'Shelf',
  '2': const [
    const {'1': 'GENERIC_SHELF', '2': 0},
    const {'1': 'ECONOMY', '2': 1},
    const {'1': 'MIDSHELF', '2': 2},
    const {'1': 'TOPSHELF', '2': 3},
  ],
};

