///
//  Generated code. Do not modify.
//  source: structs/Shelf.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Shelf extends $pb.ProtobufEnum {
  static const Shelf GENERIC_SHELF = Shelf._(0, 'GENERIC_SHELF');
  static const Shelf ECONOMY = Shelf._(1, 'ECONOMY');
  static const Shelf MIDSHELF = Shelf._(2, 'MIDSHELF');
  static const Shelf TOPSHELF = Shelf._(3, 'TOPSHELF');

  static const $core.List<Shelf> values = <Shelf> [
    GENERIC_SHELF,
    ECONOMY,
    MIDSHELF,
    TOPSHELF,
  ];

  static final $core.Map<$core.int, Shelf> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Shelf valueOf($core.int value) => _byValue[value];

  const Shelf._($core.int v, $core.String n) : super(v, n);
}

