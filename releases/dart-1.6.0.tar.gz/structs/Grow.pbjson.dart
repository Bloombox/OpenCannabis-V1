///
//  Generated code. Do not modify.
//  source: structs/Grow.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Grow$json = const {
  '1': 'Grow',
  '2': const [
    const {'1': 'GENERIC', '2': 0},
    const {'1': 'INDOOR', '2': 1},
    const {'1': 'GREENHOUSE', '2': 2},
    const {'1': 'OUTDOOR', '2': 3},
  ],
};

