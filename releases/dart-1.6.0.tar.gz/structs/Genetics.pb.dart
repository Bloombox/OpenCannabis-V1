///
//  Generated code. Do not modify.
//  source: structs/Genetics.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $17;

class Genetics extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Genetics', package: const $pb.PackageName('opencannabis.structs'))
    ..a<$17.ProductReference>(1, 'male', $pb.PbFieldType.OM, $17.ProductReference.getDefault, $17.ProductReference.create)
    ..a<$17.ProductReference>(2, 'female', $pb.PbFieldType.OM, $17.ProductReference.getDefault, $17.ProductReference.create)
    ..hasRequiredFields = false
  ;

  Genetics() : super();
  Genetics.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Genetics.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Genetics clone() => Genetics()..mergeFromMessage(this);
  Genetics copyWith(void Function(Genetics) updates) => super.copyWith((message) => updates(message as Genetics));
  $pb.BuilderInfo get info_ => _i;
  static Genetics create() => Genetics();
  Genetics createEmptyInstance() => create();
  static $pb.PbList<Genetics> createRepeated() => $pb.PbList<Genetics>();
  static Genetics getDefault() => _defaultInstance ??= create()..freeze();
  static Genetics _defaultInstance;

  $17.ProductReference get male => $_getN(0);
  set male($17.ProductReference v) { setField(1, v); }
  $core.bool hasMale() => $_has(0);
  void clearMale() => clearField(1);

  $17.ProductReference get female => $_getN(1);
  set female($17.ProductReference v) { setField(2, v); }
  $core.bool hasFemale() => $_has(1);
  void clearFemale() => clearField(2);
}

