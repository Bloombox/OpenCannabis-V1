///
//  Generated code. Do not modify.
//  source: temporal/Duration.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Duration.pbenum.dart';

export 'Duration.pbenum.dart';

class Duration extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Duration', package: const $pb.PackageName('opencannabis.temporal'))
    ..e<TimeUnit>(1, 'unit', $pb.PbFieldType.OE, TimeUnit.MILLISECONDS, TimeUnit.valueOf, TimeUnit.values)
    ..a<$core.int>(2, 'amount', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  Duration() : super();
  Duration.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Duration.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Duration clone() => Duration()..mergeFromMessage(this);
  Duration copyWith(void Function(Duration) updates) => super.copyWith((message) => updates(message as Duration));
  $pb.BuilderInfo get info_ => _i;
  static Duration create() => Duration();
  Duration createEmptyInstance() => create();
  static $pb.PbList<Duration> createRepeated() => $pb.PbList<Duration>();
  static Duration getDefault() => _defaultInstance ??= create()..freeze();
  static Duration _defaultInstance;

  TimeUnit get unit => $_getN(0);
  set unit(TimeUnit v) { setField(1, v); }
  $core.bool hasUnit() => $_has(0);
  void clearUnit() => clearField(1);

  $core.int get amount => $_get(1, 0);
  set amount($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasAmount() => $_has(1);
  void clearAmount() => clearField(2);
}

