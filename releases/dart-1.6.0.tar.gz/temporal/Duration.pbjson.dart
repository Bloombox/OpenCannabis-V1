///
//  Generated code. Do not modify.
//  source: temporal/Duration.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const TimeUnit$json = const {
  '1': 'TimeUnit',
  '2': const [
    const {'1': 'MILLISECONDS', '2': 0},
    const {'1': 'MICROSECONDS', '2': 1},
    const {'1': 'SECONDS', '2': 2},
    const {'1': 'MINUTES', '2': 3},
    const {'1': 'HOURS', '2': 4},
    const {'1': 'DAYS', '2': 5},
    const {'1': 'WEEKS', '2': 6},
    const {'1': 'MONTHS', '2': 7},
    const {'1': 'YEARS', '2': 8},
  ],
};

const Duration$json = const {
  '1': 'Duration',
  '2': const [
    const {'1': 'unit', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.temporal.TimeUnit', '10': 'unit'},
    const {'1': 'amount', '3': 2, '4': 1, '5': 13, '10': 'amount'},
  ],
};

