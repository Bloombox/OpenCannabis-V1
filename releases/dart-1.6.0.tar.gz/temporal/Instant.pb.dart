///
//  Generated code. Do not modify.
//  source: temporal/Instant.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

enum Instant_Spec {
  iso8601, 
  timestamp, 
  notSet
}

class Instant extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Instant_Spec> _Instant_SpecByTag = {
    1 : Instant_Spec.iso8601,
    2 : Instant_Spec.timestamp,
    0 : Instant_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Instant', package: const $pb.PackageName('opencannabis.temporal'))
    ..aOS(1, 'iso8601')
    ..a<Int64>(2, 'timestamp', $pb.PbFieldType.OU6, Int64.ZERO)
    ..oo(0, [1, 2])
    ..hasRequiredFields = false
  ;

  Instant() : super();
  Instant.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Instant.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Instant clone() => Instant()..mergeFromMessage(this);
  Instant copyWith(void Function(Instant) updates) => super.copyWith((message) => updates(message as Instant));
  $pb.BuilderInfo get info_ => _i;
  static Instant create() => Instant();
  Instant createEmptyInstance() => create();
  static $pb.PbList<Instant> createRepeated() => $pb.PbList<Instant>();
  static Instant getDefault() => _defaultInstance ??= create()..freeze();
  static Instant _defaultInstance;

  Instant_Spec whichSpec() => _Instant_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $core.String get iso8601 => $_getS(0, '');
  set iso8601($core.String v) { $_setString(0, v); }
  $core.bool hasIso8601() => $_has(0);
  void clearIso8601() => clearField(1);

  Int64 get timestamp => $_getI64(1);
  set timestamp(Int64 v) { $_setInt64(1, v); }
  $core.bool hasTimestamp() => $_has(1);
  void clearTimestamp() => clearField(2);
}

