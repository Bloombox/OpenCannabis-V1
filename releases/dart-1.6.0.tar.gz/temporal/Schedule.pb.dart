///
//  Generated code. Do not modify.
//  source: temporal/Schedule.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Instant.pb.dart' as $0;
import 'Time.pb.dart' as $60;

import 'Interval.pbenum.dart' as $61;

enum Schedule_Spec {
  absolute, 
  time, 
  interval, 
  notSet
}

class Schedule extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Schedule_Spec> _Schedule_SpecByTag = {
    1 : Schedule_Spec.absolute,
    2 : Schedule_Spec.time,
    3 : Schedule_Spec.interval,
    0 : Schedule_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Schedule', package: const $pb.PackageName('opencannabis.temporal'))
    ..a<$0.Instant>(1, 'absolute', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$60.Time>(2, 'time', $pb.PbFieldType.OM, $60.Time.getDefault, $60.Time.create)
    ..e<$61.Interval>(3, 'interval', $pb.PbFieldType.OE, $61.Interval.MINUTELY, $61.Interval.valueOf, $61.Interval.values)
    ..oo(0, [1, 2, 3])
    ..hasRequiredFields = false
  ;

  Schedule() : super();
  Schedule.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Schedule.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Schedule clone() => Schedule()..mergeFromMessage(this);
  Schedule copyWith(void Function(Schedule) updates) => super.copyWith((message) => updates(message as Schedule));
  $pb.BuilderInfo get info_ => _i;
  static Schedule create() => Schedule();
  Schedule createEmptyInstance() => create();
  static $pb.PbList<Schedule> createRepeated() => $pb.PbList<Schedule>();
  static Schedule getDefault() => _defaultInstance ??= create()..freeze();
  static Schedule _defaultInstance;

  Schedule_Spec whichSpec() => _Schedule_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $0.Instant get absolute => $_getN(0);
  set absolute($0.Instant v) { setField(1, v); }
  $core.bool hasAbsolute() => $_has(0);
  void clearAbsolute() => clearField(1);

  $60.Time get time => $_getN(1);
  set time($60.Time v) { setField(2, v); }
  $core.bool hasTime() => $_has(1);
  void clearTime() => clearField(2);

  $61.Interval get interval => $_getN(2);
  set interval($61.Interval v) { setField(3, v); }
  $core.bool hasInterval() => $_has(2);
  void clearInterval() => clearField(3);
}

