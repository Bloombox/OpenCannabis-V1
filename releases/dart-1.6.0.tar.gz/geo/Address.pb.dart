///
//  Generated code. Do not modify.
//  source: geo/Address.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Address extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Address', package: const $pb.PackageName('opencannabis.geo'))
    ..aOS(1, 'firstLine')
    ..aOS(2, 'secondLine')
    ..aOS(3, 'city')
    ..aOS(4, 'state')
    ..aOS(5, 'zipcode')
    ..aOS(6, 'country')
    ..hasRequiredFields = false
  ;

  Address() : super();
  Address.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Address.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Address clone() => Address()..mergeFromMessage(this);
  Address copyWith(void Function(Address) updates) => super.copyWith((message) => updates(message as Address));
  $pb.BuilderInfo get info_ => _i;
  static Address create() => Address();
  Address createEmptyInstance() => create();
  static $pb.PbList<Address> createRepeated() => $pb.PbList<Address>();
  static Address getDefault() => _defaultInstance ??= create()..freeze();
  static Address _defaultInstance;

  $core.String get firstLine => $_getS(0, '');
  set firstLine($core.String v) { $_setString(0, v); }
  $core.bool hasFirstLine() => $_has(0);
  void clearFirstLine() => clearField(1);

  $core.String get secondLine => $_getS(1, '');
  set secondLine($core.String v) { $_setString(1, v); }
  $core.bool hasSecondLine() => $_has(1);
  void clearSecondLine() => clearField(2);

  $core.String get city => $_getS(2, '');
  set city($core.String v) { $_setString(2, v); }
  $core.bool hasCity() => $_has(2);
  void clearCity() => clearField(3);

  $core.String get state => $_getS(3, '');
  set state($core.String v) { $_setString(3, v); }
  $core.bool hasState() => $_has(3);
  void clearState() => clearField(4);

  $core.String get zipcode => $_getS(4, '');
  set zipcode($core.String v) { $_setString(4, v); }
  $core.bool hasZipcode() => $_has(4);
  void clearZipcode() => clearField(5);

  $core.String get country => $_getS(5, '');
  set country($core.String v) { $_setString(5, v); }
  $core.bool hasCountry() => $_has(5);
  void clearCountry() => clearField(6);
}

