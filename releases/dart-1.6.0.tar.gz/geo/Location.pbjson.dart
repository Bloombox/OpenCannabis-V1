///
//  Generated code. Do not modify.
//  source: geo/Location.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Location$json = const {
  '1': 'Location',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Name', '8': const {}, '10': 'name'},
    const {'1': 'address', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.Address', '8': const {}, '10': 'address'},
    const {'1': 'point', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Point', '8': const {}, '10': 'point'},
    const {'1': 'accuracy', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.geo.LocationAccuracy', '8': const {}, '10': 'accuracy'},
  ],
};

