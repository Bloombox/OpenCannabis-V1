///
//  Generated code. Do not modify.
//  source: geo/Province.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Province$json = const {
  '1': 'Province',
  '2': const [
    const {'1': 'state', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.geo.usa.USState', '9': 0, '10': 'state'},
    const {'1': 'province', '3': 2, '4': 1, '5': 9, '9': 0, '10': 'province'},
  ],
  '8': const [
    const {'1': 'spec'},
  ],
};

