///
//  Generated code. Do not modify.
//  source: geo/Distance.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const DistanceUnit$json = const {
  '1': 'DistanceUnit',
  '2': const [
    const {'1': 'METERS', '2': 0},
    const {'1': 'INCHES', '2': 1},
    const {'1': 'FEET', '2': 2},
    const {'1': 'MILLIMETERS', '2': 3},
    const {'1': 'CENTIMETERS', '2': 4},
    const {'1': 'KILOMETERS', '2': 5},
    const {'1': 'MILES', '2': 6},
  ],
};

const LocationAccuracy$json = const {
  '1': 'LocationAccuracy',
  '2': const [
    const {'1': 'estimate', '3': 1, '4': 1, '5': 8, '8': const {}, '10': 'estimate'},
    const {'1': 'value', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.DistanceValue', '8': const {}, '10': 'value'},
  ],
};

const DistanceValue$json = const {
  '1': 'DistanceValue',
  '2': const [
    const {'1': 'unit', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.geo.DistanceUnit', '8': const {}, '10': 'unit'},
    const {'1': 'value', '3': 3, '4': 1, '5': 1, '8': const {}, '10': 'value'},
  ],
};

const Distance$json = const {
  '1': 'Distance',
  '2': const [
    const {'1': 'estimate', '3': 1, '4': 1, '5': 8, '8': const {}, '10': 'estimate'},
    const {'1': 'accuracy', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.LocationAccuracy', '8': const {}, '10': 'accuracy'},
    const {'1': 'unit', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.geo.DistanceUnit', '8': const {}, '10': 'unit'},
  ],
};

