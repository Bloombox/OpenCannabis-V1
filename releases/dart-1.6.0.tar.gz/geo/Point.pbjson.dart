///
//  Generated code. Do not modify.
//  source: geo/Point.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Point$json = const {
  '1': 'Point',
  '2': const [
    const {'1': 'latitude', '3': 1, '4': 1, '5': 1, '8': const {}, '10': 'latitude'},
    const {'1': 'longitude', '3': 2, '4': 1, '5': 1, '8': const {}, '10': 'longitude'},
    const {'1': 'elevation', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'elevation'},
    const {'1': 'accuracy', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'accuracy'},
  ],
};

