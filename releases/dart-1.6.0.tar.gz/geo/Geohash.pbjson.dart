///
//  Generated code. Do not modify.
//  source: geo/Geohash.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Geohash$json = const {
  '1': 'Geohash',
  '2': const [
    const {'1': 'component', '3': 1, '4': 3, '5': 9, '8': const {}, '10': 'component'},
    const {'1': 'elevation', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'elevation'},
    const {'1': 'accuracy', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'accuracy'},
  ],
};

