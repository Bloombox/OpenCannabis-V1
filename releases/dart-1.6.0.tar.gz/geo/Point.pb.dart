///
//  Generated code. Do not modify.
//  source: geo/Point.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Distance.pb.dart' as $2;

class Point extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Point', package: const $pb.PackageName('opencannabis.geo'))
    ..a<$core.double>(1, 'latitude', $pb.PbFieldType.OD)
    ..a<$core.double>(2, 'longitude', $pb.PbFieldType.OD)
    ..a<$2.Distance>(3, 'elevation', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..a<$2.Distance>(4, 'accuracy', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..hasRequiredFields = false
  ;

  Point() : super();
  Point.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Point.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Point clone() => Point()..mergeFromMessage(this);
  Point copyWith(void Function(Point) updates) => super.copyWith((message) => updates(message as Point));
  $pb.BuilderInfo get info_ => _i;
  static Point create() => Point();
  Point createEmptyInstance() => create();
  static $pb.PbList<Point> createRepeated() => $pb.PbList<Point>();
  static Point getDefault() => _defaultInstance ??= create()..freeze();
  static Point _defaultInstance;

  $core.double get latitude => $_getN(0);
  set latitude($core.double v) { $_setDouble(0, v); }
  $core.bool hasLatitude() => $_has(0);
  void clearLatitude() => clearField(1);

  $core.double get longitude => $_getN(1);
  set longitude($core.double v) { $_setDouble(1, v); }
  $core.bool hasLongitude() => $_has(1);
  void clearLongitude() => clearField(2);

  $2.Distance get elevation => $_getN(2);
  set elevation($2.Distance v) { setField(3, v); }
  $core.bool hasElevation() => $_has(2);
  void clearElevation() => clearField(3);

  $2.Distance get accuracy => $_getN(3);
  set accuracy($2.Distance v) { setField(4, v); }
  $core.bool hasAccuracy() => $_has(3);
  void clearAccuracy() => clearField(4);
}

