///
//  Generated code. Do not modify.
//  source: geo/Distance.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Distance.pbenum.dart';

export 'Distance.pbenum.dart';

class LocationAccuracy extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocationAccuracy', package: const $pb.PackageName('opencannabis.geo'))
    ..aOB(1, 'estimate')
    ..a<DistanceValue>(2, 'value', $pb.PbFieldType.OM, DistanceValue.getDefault, DistanceValue.create)
    ..hasRequiredFields = false
  ;

  LocationAccuracy() : super();
  LocationAccuracy.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocationAccuracy.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocationAccuracy clone() => LocationAccuracy()..mergeFromMessage(this);
  LocationAccuracy copyWith(void Function(LocationAccuracy) updates) => super.copyWith((message) => updates(message as LocationAccuracy));
  $pb.BuilderInfo get info_ => _i;
  static LocationAccuracy create() => LocationAccuracy();
  LocationAccuracy createEmptyInstance() => create();
  static $pb.PbList<LocationAccuracy> createRepeated() => $pb.PbList<LocationAccuracy>();
  static LocationAccuracy getDefault() => _defaultInstance ??= create()..freeze();
  static LocationAccuracy _defaultInstance;

  $core.bool get estimate => $_get(0, false);
  set estimate($core.bool v) { $_setBool(0, v); }
  $core.bool hasEstimate() => $_has(0);
  void clearEstimate() => clearField(1);

  DistanceValue get value => $_getN(1);
  set value(DistanceValue v) { setField(2, v); }
  $core.bool hasValue() => $_has(1);
  void clearValue() => clearField(2);
}

class DistanceValue extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DistanceValue', package: const $pb.PackageName('opencannabis.geo'))
    ..e<DistanceUnit>(1, 'unit', $pb.PbFieldType.OE, DistanceUnit.METERS, DistanceUnit.valueOf, DistanceUnit.values)
    ..a<$core.double>(3, 'value', $pb.PbFieldType.OD)
    ..hasRequiredFields = false
  ;

  DistanceValue() : super();
  DistanceValue.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DistanceValue.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DistanceValue clone() => DistanceValue()..mergeFromMessage(this);
  DistanceValue copyWith(void Function(DistanceValue) updates) => super.copyWith((message) => updates(message as DistanceValue));
  $pb.BuilderInfo get info_ => _i;
  static DistanceValue create() => DistanceValue();
  DistanceValue createEmptyInstance() => create();
  static $pb.PbList<DistanceValue> createRepeated() => $pb.PbList<DistanceValue>();
  static DistanceValue getDefault() => _defaultInstance ??= create()..freeze();
  static DistanceValue _defaultInstance;

  DistanceUnit get unit => $_getN(0);
  set unit(DistanceUnit v) { setField(1, v); }
  $core.bool hasUnit() => $_has(0);
  void clearUnit() => clearField(1);

  $core.double get value => $_getN(1);
  set value($core.double v) { $_setDouble(1, v); }
  $core.bool hasValue() => $_has(1);
  void clearValue() => clearField(3);
}

class Distance extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Distance', package: const $pb.PackageName('opencannabis.geo'))
    ..aOB(1, 'estimate')
    ..a<LocationAccuracy>(2, 'accuracy', $pb.PbFieldType.OM, LocationAccuracy.getDefault, LocationAccuracy.create)
    ..e<DistanceUnit>(3, 'unit', $pb.PbFieldType.OE, DistanceUnit.METERS, DistanceUnit.valueOf, DistanceUnit.values)
    ..hasRequiredFields = false
  ;

  Distance() : super();
  Distance.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Distance.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Distance clone() => Distance()..mergeFromMessage(this);
  Distance copyWith(void Function(Distance) updates) => super.copyWith((message) => updates(message as Distance));
  $pb.BuilderInfo get info_ => _i;
  static Distance create() => Distance();
  Distance createEmptyInstance() => create();
  static $pb.PbList<Distance> createRepeated() => $pb.PbList<Distance>();
  static Distance getDefault() => _defaultInstance ??= create()..freeze();
  static Distance _defaultInstance;

  $core.bool get estimate => $_get(0, false);
  set estimate($core.bool v) { $_setBool(0, v); }
  $core.bool hasEstimate() => $_has(0);
  void clearEstimate() => clearField(1);

  LocationAccuracy get accuracy => $_getN(1);
  set accuracy(LocationAccuracy v) { setField(2, v); }
  $core.bool hasAccuracy() => $_has(1);
  void clearAccuracy() => clearField(2);

  DistanceUnit get unit => $_getN(2);
  set unit(DistanceUnit v) { setField(3, v); }
  $core.bool hasUnit() => $_has(2);
  void clearUnit() => clearField(3);
}

