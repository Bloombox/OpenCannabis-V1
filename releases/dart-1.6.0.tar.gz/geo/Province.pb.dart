///
//  Generated code. Do not modify.
//  source: geo/Province.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'USState.pbenum.dart' as $23;

enum Province_Spec {
  state, 
  province, 
  notSet
}

class Province extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Province_Spec> _Province_SpecByTag = {
    1 : Province_Spec.state,
    2 : Province_Spec.province,
    0 : Province_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Province', package: const $pb.PackageName('opencannabis.geo'))
    ..e<$23.USState>(1, 'state', $pb.PbFieldType.OE, $23.USState.UNSPECIFIED, $23.USState.valueOf, $23.USState.values)
    ..aOS(2, 'province')
    ..oo(0, [1, 2])
    ..hasRequiredFields = false
  ;

  Province() : super();
  Province.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Province.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Province clone() => Province()..mergeFromMessage(this);
  Province copyWith(void Function(Province) updates) => super.copyWith((message) => updates(message as Province));
  $pb.BuilderInfo get info_ => _i;
  static Province create() => Province();
  Province createEmptyInstance() => create();
  static $pb.PbList<Province> createRepeated() => $pb.PbList<Province>();
  static Province getDefault() => _defaultInstance ??= create()..freeze();
  static Province _defaultInstance;

  Province_Spec whichSpec() => _Province_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $23.USState get state => $_getN(0);
  set state($23.USState v) { setField(1, v); }
  $core.bool hasState() => $_has(0);
  void clearState() => clearField(1);

  $core.String get province => $_getS(1, '');
  set province($core.String v) { $_setString(1, v); }
  $core.bool hasProvince() => $_has(1);
  void clearProvince() => clearField(2);
}

