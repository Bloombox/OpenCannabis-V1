///
//  Generated code. Do not modify.
//  source: content/Colors.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class StandardColor extends $pb.ProtobufEnum {
  static const StandardColor UNSPECIFIED_COLOR = StandardColor._(0, 'UNSPECIFIED_COLOR');
  static const StandardColor RED = StandardColor._(1, 'RED');
  static const StandardColor GREEN = StandardColor._(2, 'GREEN');
  static const StandardColor BLUE = StandardColor._(3, 'BLUE');
  static const StandardColor YELLOW = StandardColor._(4, 'YELLOW');
  static const StandardColor PURPLE = StandardColor._(5, 'PURPLE');
  static const StandardColor ORANGE = StandardColor._(6, 'ORANGE');
  static const StandardColor PINK = StandardColor._(7, 'PINK');
  static const StandardColor GRAY = StandardColor._(8, 'GRAY');
  static const StandardColor BROWN = StandardColor._(9, 'BROWN');

  static const $core.List<StandardColor> values = <StandardColor> [
    UNSPECIFIED_COLOR,
    RED,
    GREEN,
    BLUE,
    YELLOW,
    PURPLE,
    ORANGE,
    PINK,
    GRAY,
    BROWN,
  ];

  static final $core.Map<$core.int, StandardColor> _byValue = $pb.ProtobufEnum.initByValue(values);
  static StandardColor valueOf($core.int value) => _byValue[value];

  const StandardColor._($core.int v, $core.String n) : super(v, n);
}

