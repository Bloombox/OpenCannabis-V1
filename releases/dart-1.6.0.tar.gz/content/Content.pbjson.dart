///
//  Generated code. Do not modify.
//  source: content/Content.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Encoding$json = const {
  '1': 'Encoding',
  '2': const [
    const {'1': 'UTF8', '2': 0},
    const {'1': 'B64', '2': 1},
    const {'1': 'B64_ASCII', '2': 2},
  ],
};

const Content$json = const {
  '1': 'Content',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.content.Content.Type', '10': 'type'},
    const {'1': 'encoding', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.content.Encoding', '10': 'encoding'},
    const {'1': 'language', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.base.Language', '10': 'language'},
    const {'1': 'compression', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.base.Compression', '10': 'compression'},
    const {'1': 'content', '3': 10, '4': 1, '5': 9, '9': 0, '10': 'content'},
    const {'1': 'raw', '3': 20, '4': 1, '5': 12, '9': 0, '10': 'raw'},
  ],
  '4': const [Content_Type$json],
  '8': const [
    const {'1': 'payload'},
  ],
};

const Content_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'TEXT', '2': 0},
    const {'1': 'MARKDOWN', '2': 1},
    const {'1': 'HTML', '2': 2},
    const {'1': 'BINARY', '2': 3},
  ],
};

