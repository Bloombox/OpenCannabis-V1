///
//  Generated code. Do not modify.
//  source: content/Content.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Encoding extends $pb.ProtobufEnum {
  static const Encoding UTF8 = Encoding._(0, 'UTF8');
  static const Encoding B64 = Encoding._(1, 'B64');
  static const Encoding B64_ASCII = Encoding._(2, 'B64_ASCII');

  static const $core.List<Encoding> values = <Encoding> [
    UTF8,
    B64,
    B64_ASCII,
  ];

  static final $core.Map<$core.int, Encoding> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Encoding valueOf($core.int value) => _byValue[value];

  const Encoding._($core.int v, $core.String n) : super(v, n);
}

class Content_Type extends $pb.ProtobufEnum {
  static const Content_Type TEXT = Content_Type._(0, 'TEXT');
  static const Content_Type MARKDOWN = Content_Type._(1, 'MARKDOWN');
  static const Content_Type HTML = Content_Type._(2, 'HTML');
  static const Content_Type BINARY = Content_Type._(3, 'BINARY');

  static const $core.List<Content_Type> values = <Content_Type> [
    TEXT,
    MARKDOWN,
    HTML,
    BINARY,
  ];

  static final $core.Map<$core.int, Content_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Content_Type valueOf($core.int value) => _byValue[value];

  const Content_Type._($core.int v, $core.String n) : super(v, n);
}

