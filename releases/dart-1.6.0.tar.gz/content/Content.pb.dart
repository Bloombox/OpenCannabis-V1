///
//  Generated code. Do not modify.
//  source: content/Content.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/Compression.pb.dart' as $35;

import 'Content.pbenum.dart';
import '../base/Language.pbenum.dart' as $36;

export 'Content.pbenum.dart';

enum Content_Payload {
  content, 
  raw, 
  notSet
}

class Content extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Content_Payload> _Content_PayloadByTag = {
    10 : Content_Payload.content,
    20 : Content_Payload.raw,
    0 : Content_Payload.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Content', package: const $pb.PackageName('opencannabis.content'))
    ..e<Content_Type>(1, 'type', $pb.PbFieldType.OE, Content_Type.TEXT, Content_Type.valueOf, Content_Type.values)
    ..e<Encoding>(2, 'encoding', $pb.PbFieldType.OE, Encoding.UTF8, Encoding.valueOf, Encoding.values)
    ..e<$36.Language>(3, 'language', $pb.PbFieldType.OE, $36.Language.LANGUAGE_UNSPECIFIED, $36.Language.valueOf, $36.Language.values)
    ..a<$35.Compression>(4, 'compression', $pb.PbFieldType.OM, $35.Compression.getDefault, $35.Compression.create)
    ..aOS(10, 'content')
    ..a<$core.List<$core.int>>(20, 'raw', $pb.PbFieldType.OY)
    ..oo(0, [10, 20])
    ..hasRequiredFields = false
  ;

  Content() : super();
  Content.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Content.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Content clone() => Content()..mergeFromMessage(this);
  Content copyWith(void Function(Content) updates) => super.copyWith((message) => updates(message as Content));
  $pb.BuilderInfo get info_ => _i;
  static Content create() => Content();
  Content createEmptyInstance() => create();
  static $pb.PbList<Content> createRepeated() => $pb.PbList<Content>();
  static Content getDefault() => _defaultInstance ??= create()..freeze();
  static Content _defaultInstance;

  Content_Payload whichPayload() => _Content_PayloadByTag[$_whichOneof(0)];
  void clearPayload() => clearField($_whichOneof(0));

  Content_Type get type => $_getN(0);
  set type(Content_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  Encoding get encoding => $_getN(1);
  set encoding(Encoding v) { setField(2, v); }
  $core.bool hasEncoding() => $_has(1);
  void clearEncoding() => clearField(2);

  $36.Language get language => $_getN(2);
  set language($36.Language v) { setField(3, v); }
  $core.bool hasLanguage() => $_has(2);
  void clearLanguage() => clearField(3);

  $35.Compression get compression => $_getN(3);
  set compression($35.Compression v) { setField(4, v); }
  $core.bool hasCompression() => $_has(3);
  void clearCompression() => clearField(4);

  $core.String get content => $_getS(4, '');
  set content($core.String v) { $_setString(4, v); }
  $core.bool hasContent() => $_has(4);
  void clearContent() => clearField(10);

  $core.List<$core.int> get raw => $_getN(5);
  set raw($core.List<$core.int> v) { $_setBytes(5, v); }
  $core.bool hasRaw() => $_has(5);
  void clearRaw() => clearField(20);
}

