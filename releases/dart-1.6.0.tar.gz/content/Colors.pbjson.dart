///
//  Generated code. Do not modify.
//  source: content/Colors.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const StandardColor$json = const {
  '1': 'StandardColor',
  '2': const [
    const {'1': 'UNSPECIFIED_COLOR', '2': 0},
    const {'1': 'RED', '2': 1},
    const {'1': 'GREEN', '2': 2},
    const {'1': 'BLUE', '2': 3},
    const {'1': 'YELLOW', '2': 4},
    const {'1': 'PURPLE', '2': 5},
    const {'1': 'ORANGE', '2': 6},
    const {'1': 'PINK', '2': 7},
    const {'1': 'GRAY', '2': 8},
    const {'1': 'BROWN', '2': 9},
  ],
};

const RGBAColorSpec$json = const {
  '1': 'RGBAColorSpec',
  '2': const [
    const {'1': 'r', '3': 1, '4': 1, '5': 4, '10': 'r'},
    const {'1': 'g', '3': 2, '4': 1, '5': 4, '10': 'g'},
    const {'1': 'b', '3': 3, '4': 1, '5': 4, '10': 'b'},
    const {'1': 'a', '3': 4, '4': 1, '5': 4, '10': 'a'},
  ],
};

const HSBColorSpec$json = const {
  '1': 'HSBColorSpec',
  '2': const [
    const {'1': 'h', '3': 1, '4': 1, '5': 4, '10': 'h'},
    const {'1': 's', '3': 2, '4': 1, '5': 4, '10': 's'},
    const {'1': 'b', '3': 3, '4': 1, '5': 4, '10': 'b'},
  ],
};

const CMYKColorSpec$json = const {
  '1': 'CMYKColorSpec',
  '2': const [
    const {'1': 'c', '3': 1, '4': 1, '5': 4, '10': 'c'},
    const {'1': 'm', '3': 2, '4': 1, '5': 4, '10': 'm'},
    const {'1': 'y', '3': 3, '4': 1, '5': 4, '10': 'y'},
    const {'1': 'k', '3': 4, '4': 1, '5': 4, '10': 'k'},
  ],
};

const Color$json = const {
  '1': 'Color',
  '2': const [
    const {'1': 'standard', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.content.StandardColor', '9': 0, '10': 'standard'},
    const {'1': 'hex', '3': 2, '4': 1, '5': 9, '9': 0, '10': 'hex'},
    const {'1': 'rgba', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.RGBAColorSpec', '9': 0, '10': 'rgba'},
    const {'1': 'hsb', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.content.HSBColorSpec', '9': 0, '10': 'hsb'},
    const {'1': 'cmyk', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.content.CMYKColorSpec', '9': 0, '10': 'cmyk'},
  ],
  '8': const [
    const {'1': 'spec'},
  ],
};

const ColorScheme$json = const {
  '1': 'ColorScheme',
  '2': const [
    const {'1': 'primary', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Color', '10': 'primary'},
    const {'1': 'secondary', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.content.Color', '10': 'secondary'},
    const {'1': 'alert', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.Color', '10': 'alert'},
    const {'1': 'shades', '3': 4, '4': 3, '5': 11, '6': '.opencannabis.content.Color', '10': 'shades'},
  ],
};

