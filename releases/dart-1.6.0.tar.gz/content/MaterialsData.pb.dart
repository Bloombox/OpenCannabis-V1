///
//  Generated code. Do not modify.
//  source: content/MaterialsData.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../structs/Genetics.pb.dart' as $30;
import '../products/distribution/DistributionChannel.pb.dart' as $31;

import '../structs/Species.pbenum.dart' as $32;
import '../structs/Grow.pbenum.dart' as $33;
import '../structs/Shelf.pbenum.dart' as $34;

class MaterialsData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MaterialsData', package: const $pb.PackageName('opencannabis.content'))
    ..e<$32.Species>(1, 'species', $pb.PbFieldType.OE, $32.Species.UNSPECIFIED, $32.Species.valueOf, $32.Species.values)
    ..a<$30.Genetics>(2, 'genetics', $pb.PbFieldType.OM, $30.Genetics.getDefault, $30.Genetics.create)
    ..e<$33.Grow>(3, 'grow', $pb.PbFieldType.OE, $33.Grow.GENERIC, $33.Grow.valueOf, $33.Grow.values)
    ..e<$34.Shelf>(4, 'shelf', $pb.PbFieldType.OE, $34.Shelf.GENERIC_SHELF, $34.Shelf.valueOf, $34.Shelf.values)
    ..pc<$31.DistributionPolicy>(5, 'channel', $pb.PbFieldType.PM,$31.DistributionPolicy.create)
    ..hasRequiredFields = false
  ;

  MaterialsData() : super();
  MaterialsData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MaterialsData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MaterialsData clone() => MaterialsData()..mergeFromMessage(this);
  MaterialsData copyWith(void Function(MaterialsData) updates) => super.copyWith((message) => updates(message as MaterialsData));
  $pb.BuilderInfo get info_ => _i;
  static MaterialsData create() => MaterialsData();
  MaterialsData createEmptyInstance() => create();
  static $pb.PbList<MaterialsData> createRepeated() => $pb.PbList<MaterialsData>();
  static MaterialsData getDefault() => _defaultInstance ??= create()..freeze();
  static MaterialsData _defaultInstance;

  $32.Species get species => $_getN(0);
  set species($32.Species v) { setField(1, v); }
  $core.bool hasSpecies() => $_has(0);
  void clearSpecies() => clearField(1);

  $30.Genetics get genetics => $_getN(1);
  set genetics($30.Genetics v) { setField(2, v); }
  $core.bool hasGenetics() => $_has(1);
  void clearGenetics() => clearField(2);

  $33.Grow get grow => $_getN(2);
  set grow($33.Grow v) { setField(3, v); }
  $core.bool hasGrow() => $_has(2);
  void clearGrow() => clearField(3);

  $34.Shelf get shelf => $_getN(3);
  set shelf($34.Shelf v) { setField(4, v); }
  $core.bool hasShelf() => $_has(3);
  void clearShelf() => clearField(4);

  $core.List<$31.DistributionPolicy> get channel => $_getList(4);
}

