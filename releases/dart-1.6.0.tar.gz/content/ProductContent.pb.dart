///
//  Generated code. Do not modify.
//  source: content/ProductContent.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;
import 'Name.pb.dart' as $3;
import 'Brand.pb.dart' as $39;
import 'Content.pb.dart' as $37;
import '../media/MediaKey.pb.dart' as $28;
import '../structs/pricing/PricingDescriptor.pb.dart' as $18;
import '../structs/labtesting/TestResults.pb.dart' as $40;

import '../structs/ProductFlags.pbenum.dart' as $41;

class ProductTimestamps extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductTimestamps', package: const $pb.PackageName('opencannabis.content'))
    ..a<$0.Instant>(1, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(2, 'modified', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(3, 'published', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  ProductTimestamps() : super();
  ProductTimestamps.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductTimestamps.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductTimestamps clone() => ProductTimestamps()..mergeFromMessage(this);
  ProductTimestamps copyWith(void Function(ProductTimestamps) updates) => super.copyWith((message) => updates(message as ProductTimestamps));
  $pb.BuilderInfo get info_ => _i;
  static ProductTimestamps create() => ProductTimestamps();
  ProductTimestamps createEmptyInstance() => create();
  static $pb.PbList<ProductTimestamps> createRepeated() => $pb.PbList<ProductTimestamps>();
  static ProductTimestamps getDefault() => _defaultInstance ??= create()..freeze();
  static ProductTimestamps _defaultInstance;

  $0.Instant get created => $_getN(0);
  set created($0.Instant v) { setField(1, v); }
  $core.bool hasCreated() => $_has(0);
  void clearCreated() => clearField(1);

  $0.Instant get modified => $_getN(1);
  set modified($0.Instant v) { setField(2, v); }
  $core.bool hasModified() => $_has(1);
  void clearModified() => clearField(2);

  $0.Instant get published => $_getN(2);
  set published($0.Instant v) { setField(3, v); }
  $core.bool hasPublished() => $_has(2);
  void clearPublished() => clearField(3);
}

class ProductContent extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductContent', package: const $pb.PackageName('opencannabis.content'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<$39.Brand>(2, 'brand', $pb.PbFieldType.OM, $39.Brand.getDefault, $39.Brand.create)
    ..a<$37.Content>(3, 'summary', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..a<$37.Content>(4, 'usage', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..a<$37.Content>(5, 'dosage', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..pc<$28.MediaReference>(6, 'media', $pb.PbFieldType.PM,$28.MediaReference.create)
    ..a<$18.ProductPricing>(7, 'pricing', $pb.PbFieldType.OM, $18.ProductPricing.getDefault, $18.ProductPricing.create)
    ..a<$40.TestResults>(8, 'tests', $pb.PbFieldType.OM, $40.TestResults.getDefault, $40.TestResults.create)
    ..pc<$41.ProductFlag>(9, 'flags', $pb.PbFieldType.PE, null, $41.ProductFlag.valueOf, $41.ProductFlag.values)
    ..a<ProductTimestamps>(10, 'ts', $pb.PbFieldType.OM, ProductTimestamps.getDefault, ProductTimestamps.create)
    ..hasRequiredFields = false
  ;

  ProductContent() : super();
  ProductContent.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductContent.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductContent clone() => ProductContent()..mergeFromMessage(this);
  ProductContent copyWith(void Function(ProductContent) updates) => super.copyWith((message) => updates(message as ProductContent));
  $pb.BuilderInfo get info_ => _i;
  static ProductContent create() => ProductContent();
  ProductContent createEmptyInstance() => create();
  static $pb.PbList<ProductContent> createRepeated() => $pb.PbList<ProductContent>();
  static ProductContent getDefault() => _defaultInstance ??= create()..freeze();
  static ProductContent _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $39.Brand get brand => $_getN(1);
  set brand($39.Brand v) { setField(2, v); }
  $core.bool hasBrand() => $_has(1);
  void clearBrand() => clearField(2);

  $37.Content get summary => $_getN(2);
  set summary($37.Content v) { setField(3, v); }
  $core.bool hasSummary() => $_has(2);
  void clearSummary() => clearField(3);

  $37.Content get usage => $_getN(3);
  set usage($37.Content v) { setField(4, v); }
  $core.bool hasUsage() => $_has(3);
  void clearUsage() => clearField(4);

  $37.Content get dosage => $_getN(4);
  set dosage($37.Content v) { setField(5, v); }
  $core.bool hasDosage() => $_has(4);
  void clearDosage() => clearField(5);

  $core.List<$28.MediaReference> get media => $_getList(5);

  $18.ProductPricing get pricing => $_getN(6);
  set pricing($18.ProductPricing v) { setField(7, v); }
  $core.bool hasPricing() => $_has(6);
  void clearPricing() => clearField(7);

  $40.TestResults get tests => $_getN(7);
  set tests($40.TestResults v) { setField(8, v); }
  $core.bool hasTests() => $_has(7);
  void clearTests() => clearField(8);

  $core.List<$41.ProductFlag> get flags => $_getList(8);

  ProductTimestamps get ts => $_getN(9);
  set ts(ProductTimestamps v) { setField(10, v); }
  $core.bool hasTs() => $_has(9);
  void clearTs() => clearField(10);
}

