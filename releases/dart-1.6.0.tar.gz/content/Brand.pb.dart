///
//  Generated code. Do not modify.
//  source: content/Brand.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../media/MediaKey.pb.dart' as $28;
import 'Name.pb.dart' as $3;
import 'Content.pb.dart' as $37;
import 'Colors.pb.dart' as $13;

class RasterGraphic extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('RasterGraphic', package: const $pb.PackageName('opencannabis.content'))
    ..a<$28.MediaReference>(1, 'standard', $pb.PbFieldType.OM, $28.MediaReference.getDefault, $28.MediaReference.create)
    ..a<$28.MediaReference>(2, 'retina', $pb.PbFieldType.OM, $28.MediaReference.getDefault, $28.MediaReference.create)
    ..hasRequiredFields = false
  ;

  RasterGraphic() : super();
  RasterGraphic.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  RasterGraphic.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  RasterGraphic clone() => RasterGraphic()..mergeFromMessage(this);
  RasterGraphic copyWith(void Function(RasterGraphic) updates) => super.copyWith((message) => updates(message as RasterGraphic));
  $pb.BuilderInfo get info_ => _i;
  static RasterGraphic create() => RasterGraphic();
  RasterGraphic createEmptyInstance() => create();
  static $pb.PbList<RasterGraphic> createRepeated() => $pb.PbList<RasterGraphic>();
  static RasterGraphic getDefault() => _defaultInstance ??= create()..freeze();
  static RasterGraphic _defaultInstance;

  $28.MediaReference get standard => $_getN(0);
  set standard($28.MediaReference v) { setField(1, v); }
  $core.bool hasStandard() => $_has(0);
  void clearStandard() => clearField(1);

  $28.MediaReference get retina => $_getN(1);
  set retina($28.MediaReference v) { setField(2, v); }
  $core.bool hasRetina() => $_has(1);
  void clearRetina() => clearField(2);
}

class BrandAsset extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BrandAsset', package: const $pb.PackageName('opencannabis.content'))
    ..a<RasterGraphic>(1, 'raster', $pb.PbFieldType.OM, RasterGraphic.getDefault, RasterGraphic.create)
    ..a<$28.MediaReference>(2, 'vector', $pb.PbFieldType.OM, $28.MediaReference.getDefault, $28.MediaReference.create)
    ..hasRequiredFields = false
  ;

  BrandAsset() : super();
  BrandAsset.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BrandAsset.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BrandAsset clone() => BrandAsset()..mergeFromMessage(this);
  BrandAsset copyWith(void Function(BrandAsset) updates) => super.copyWith((message) => updates(message as BrandAsset));
  $pb.BuilderInfo get info_ => _i;
  static BrandAsset create() => BrandAsset();
  BrandAsset createEmptyInstance() => create();
  static $pb.PbList<BrandAsset> createRepeated() => $pb.PbList<BrandAsset>();
  static BrandAsset getDefault() => _defaultInstance ??= create()..freeze();
  static BrandAsset _defaultInstance;

  RasterGraphic get raster => $_getN(0);
  set raster(RasterGraphic v) { setField(1, v); }
  $core.bool hasRaster() => $_has(0);
  void clearRaster() => clearField(1);

  $28.MediaReference get vector => $_getN(1);
  set vector($28.MediaReference v) { setField(2, v); }
  $core.bool hasVector() => $_has(1);
  void clearVector() => clearField(2);
}

class Brand extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Brand', package: const $pb.PackageName('opencannabis.content'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<Brand>(2, 'parent', $pb.PbFieldType.OM, Brand.getDefault, Brand.create)
    ..a<$37.Content>(3, 'summary', $pb.PbFieldType.OM, $37.Content.getDefault, $37.Content.create)
    ..pc<BrandAsset>(20, 'media', $pb.PbFieldType.PM,BrandAsset.create)
    ..a<$13.ColorScheme>(21, 'theme', $pb.PbFieldType.OM, $13.ColorScheme.getDefault, $13.ColorScheme.create)
    ..hasRequiredFields = false
  ;

  Brand() : super();
  Brand.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Brand.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Brand clone() => Brand()..mergeFromMessage(this);
  Brand copyWith(void Function(Brand) updates) => super.copyWith((message) => updates(message as Brand));
  $pb.BuilderInfo get info_ => _i;
  static Brand create() => Brand();
  Brand createEmptyInstance() => create();
  static $pb.PbList<Brand> createRepeated() => $pb.PbList<Brand>();
  static Brand getDefault() => _defaultInstance ??= create()..freeze();
  static Brand _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  Brand get parent => $_getN(1);
  set parent(Brand v) { setField(2, v); }
  $core.bool hasParent() => $_has(1);
  void clearParent() => clearField(2);

  $37.Content get summary => $_getN(2);
  set summary($37.Content v) { setField(3, v); }
  $core.bool hasSummary() => $_has(2);
  void clearSummary() => clearField(3);

  $core.List<BrandAsset> get media => $_getList(3);

  $13.ColorScheme get theme => $_getN(4);
  set theme($13.ColorScheme v) { setField(21, v); }
  $core.bool hasTheme() => $_has(4);
  void clearTheme() => clearField(21);
}

