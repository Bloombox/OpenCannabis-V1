///
//  Generated code. Do not modify.
//  source: crypto/Container.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/Compression.pb.dart' as $35;
import 'primitives/Integrity.pb.dart' as $44;
import 'primitives/Keys.pb.dart' as $55;

import '../content/Content.pbenum.dart' as $37;
import 'primitives/Keys.pbenum.dart' as $55;

class EncryptedData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EncryptedData', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$core.List<$core.int>>(1, 'data', $pb.PbFieldType.OY)
    ..e<$37.Encoding>(2, 'encoding', $pb.PbFieldType.OE, $37.Encoding.UTF8, $37.Encoding.valueOf, $37.Encoding.values)
    ..a<$35.Compression>(3, 'compression', $pb.PbFieldType.OM, $35.Compression.getDefault, $35.Compression.create)
    ..a<$44.Hash>(4, 'fingerprint', $pb.PbFieldType.OM, $44.Hash.getDefault, $44.Hash.create)
    ..hasRequiredFields = false
  ;

  EncryptedData() : super();
  EncryptedData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EncryptedData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EncryptedData clone() => EncryptedData()..mergeFromMessage(this);
  EncryptedData copyWith(void Function(EncryptedData) updates) => super.copyWith((message) => updates(message as EncryptedData));
  $pb.BuilderInfo get info_ => _i;
  static EncryptedData create() => EncryptedData();
  EncryptedData createEmptyInstance() => create();
  static $pb.PbList<EncryptedData> createRepeated() => $pb.PbList<EncryptedData>();
  static EncryptedData getDefault() => _defaultInstance ??= create()..freeze();
  static EncryptedData _defaultInstance;

  $core.List<$core.int> get data => $_getN(0);
  set data($core.List<$core.int> v) { $_setBytes(0, v); }
  $core.bool hasData() => $_has(0);
  void clearData() => clearField(1);

  $37.Encoding get encoding => $_getN(1);
  set encoding($37.Encoding v) { setField(2, v); }
  $core.bool hasEncoding() => $_has(1);
  void clearEncoding() => clearField(2);

  $35.Compression get compression => $_getN(2);
  set compression($35.Compression v) { setField(3, v); }
  $core.bool hasCompression() => $_has(2);
  void clearCompression() => clearField(3);

  $44.Hash get fingerprint => $_getN(3);
  set fingerprint($44.Hash v) { setField(4, v); }
  $core.bool hasFingerprint() => $_has(3);
  void clearFingerprint() => clearField(4);
}

enum EncryptedContainer_Parameters {
  key, 
  keypair, 
  notSet
}

class EncryptedContainer extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, EncryptedContainer_Parameters> _EncryptedContainer_ParametersByTag = {
    4 : EncryptedContainer_Parameters.key,
    5 : EncryptedContainer_Parameters.keypair,
    0 : EncryptedContainer_Parameters.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EncryptedContainer', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<EncryptedData>(1, 'payload', $pb.PbFieldType.OM, EncryptedData.getDefault, EncryptedData.create)
    ..e<$55.KeyType>(2, 'keying', $pb.PbFieldType.OE, $55.KeyType.SYMMETRIC, $55.KeyType.valueOf, $55.KeyType.values)
    ..a<$55.InitializationVector>(3, 'vector', $pb.PbFieldType.OM, $55.InitializationVector.getDefault, $55.InitializationVector.create)
    ..a<$55.SymmetricKeyParameters>(4, 'key', $pb.PbFieldType.OM, $55.SymmetricKeyParameters.getDefault, $55.SymmetricKeyParameters.create)
    ..a<$55.AsymmetricKeypairParameters>(5, 'keypair', $pb.PbFieldType.OM, $55.AsymmetricKeypairParameters.getDefault, $55.AsymmetricKeypairParameters.create)
    ..oo(0, [4, 5])
    ..hasRequiredFields = false
  ;

  EncryptedContainer() : super();
  EncryptedContainer.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EncryptedContainer.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EncryptedContainer clone() => EncryptedContainer()..mergeFromMessage(this);
  EncryptedContainer copyWith(void Function(EncryptedContainer) updates) => super.copyWith((message) => updates(message as EncryptedContainer));
  $pb.BuilderInfo get info_ => _i;
  static EncryptedContainer create() => EncryptedContainer();
  EncryptedContainer createEmptyInstance() => create();
  static $pb.PbList<EncryptedContainer> createRepeated() => $pb.PbList<EncryptedContainer>();
  static EncryptedContainer getDefault() => _defaultInstance ??= create()..freeze();
  static EncryptedContainer _defaultInstance;

  EncryptedContainer_Parameters whichParameters() => _EncryptedContainer_ParametersByTag[$_whichOneof(0)];
  void clearParameters() => clearField($_whichOneof(0));

  EncryptedData get payload => $_getN(0);
  set payload(EncryptedData v) { setField(1, v); }
  $core.bool hasPayload() => $_has(0);
  void clearPayload() => clearField(1);

  $55.KeyType get keying => $_getN(1);
  set keying($55.KeyType v) { setField(2, v); }
  $core.bool hasKeying() => $_has(1);
  void clearKeying() => clearField(2);

  $55.InitializationVector get vector => $_getN(2);
  set vector($55.InitializationVector v) { setField(3, v); }
  $core.bool hasVector() => $_has(2);
  void clearVector() => clearField(3);

  $55.SymmetricKeyParameters get key => $_getN(3);
  set key($55.SymmetricKeyParameters v) { setField(4, v); }
  $core.bool hasKey() => $_has(3);
  void clearKey() => clearField(4);

  $55.AsymmetricKeypairParameters get keypair => $_getN(4);
  set keypair($55.AsymmetricKeypairParameters v) { setField(5, v); }
  $core.bool hasKeypair() => $_has(4);
  void clearKeypair() => clearField(5);
}

