///
//  Generated code. Do not modify.
//  source: crypto/primitives/Integrity.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class HashAlgorithm extends $pb.ProtobufEnum {
  static const HashAlgorithm SHA1 = HashAlgorithm._(0, 'SHA1');
  static const HashAlgorithm MD5 = HashAlgorithm._(1, 'MD5');
  static const HashAlgorithm SHA256 = HashAlgorithm._(2, 'SHA256');
  static const HashAlgorithm SHA384 = HashAlgorithm._(3, 'SHA384');
  static const HashAlgorithm SHA512 = HashAlgorithm._(4, 'SHA512');
  static const HashAlgorithm MURMUR = HashAlgorithm._(6, 'MURMUR');

  static const $core.List<HashAlgorithm> values = <HashAlgorithm> [
    SHA1,
    MD5,
    SHA256,
    SHA384,
    SHA512,
    MURMUR,
  ];

  static final $core.Map<$core.int, HashAlgorithm> _byValue = $pb.ProtobufEnum.initByValue(values);
  static HashAlgorithm valueOf($core.int value) => _byValue[value];

  const HashAlgorithm._($core.int v, $core.String n) : super(v, n);
}

