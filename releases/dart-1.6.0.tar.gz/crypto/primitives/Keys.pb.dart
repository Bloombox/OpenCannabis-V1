///
//  Generated code. Do not modify.
//  source: crypto/primitives/Keys.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Integrity.pb.dart' as $44;

import 'Keys.pbenum.dart';

export 'Keys.pbenum.dart';

class BlockCipherParameters extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BlockCipherParameters', package: const $pb.PackageName('opencannabis.crypto'))
    ..e<BlockCipher>(1, 'algorithm', $pb.PbFieldType.OE, BlockCipher.UNSPECIFIED_BLOCK_CIPHER, BlockCipher.valueOf, BlockCipher.values)
    ..e<BlockMode>(2, 'mode', $pb.PbFieldType.OE, BlockMode.UNSPECIFIED_BLOCK_MODE, BlockMode.valueOf, BlockMode.values)
    ..hasRequiredFields = false
  ;

  BlockCipherParameters() : super();
  BlockCipherParameters.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BlockCipherParameters.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BlockCipherParameters clone() => BlockCipherParameters()..mergeFromMessage(this);
  BlockCipherParameters copyWith(void Function(BlockCipherParameters) updates) => super.copyWith((message) => updates(message as BlockCipherParameters));
  $pb.BuilderInfo get info_ => _i;
  static BlockCipherParameters create() => BlockCipherParameters();
  BlockCipherParameters createEmptyInstance() => create();
  static $pb.PbList<BlockCipherParameters> createRepeated() => $pb.PbList<BlockCipherParameters>();
  static BlockCipherParameters getDefault() => _defaultInstance ??= create()..freeze();
  static BlockCipherParameters _defaultInstance;

  BlockCipher get algorithm => $_getN(0);
  set algorithm(BlockCipher v) { setField(1, v); }
  $core.bool hasAlgorithm() => $_has(0);
  void clearAlgorithm() => clearField(1);

  BlockMode get mode => $_getN(1);
  set mode(BlockMode v) { setField(2, v); }
  $core.bool hasMode() => $_has(1);
  void clearMode() => clearField(2);
}

enum SymmetricKeyParameters_Cipher {
  stream, 
  block, 
  notSet
}

class SymmetricKeyParameters extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SymmetricKeyParameters_Cipher> _SymmetricKeyParameters_CipherByTag = {
    1 : SymmetricKeyParameters_Cipher.stream,
    2 : SymmetricKeyParameters_Cipher.block,
    0 : SymmetricKeyParameters_Cipher.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SymmetricKeyParameters', package: const $pb.PackageName('opencannabis.crypto'))
    ..e<StreamCipher>(1, 'stream', $pb.PbFieldType.OE, StreamCipher.UNSPECIFIED_STREAM_CIPHER, StreamCipher.valueOf, StreamCipher.values)
    ..a<BlockCipherParameters>(2, 'block', $pb.PbFieldType.OM, BlockCipherParameters.getDefault, BlockCipherParameters.create)
    ..oo(0, [1, 2])
    ..hasRequiredFields = false
  ;

  SymmetricKeyParameters() : super();
  SymmetricKeyParameters.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SymmetricKeyParameters.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SymmetricKeyParameters clone() => SymmetricKeyParameters()..mergeFromMessage(this);
  SymmetricKeyParameters copyWith(void Function(SymmetricKeyParameters) updates) => super.copyWith((message) => updates(message as SymmetricKeyParameters));
  $pb.BuilderInfo get info_ => _i;
  static SymmetricKeyParameters create() => SymmetricKeyParameters();
  SymmetricKeyParameters createEmptyInstance() => create();
  static $pb.PbList<SymmetricKeyParameters> createRepeated() => $pb.PbList<SymmetricKeyParameters>();
  static SymmetricKeyParameters getDefault() => _defaultInstance ??= create()..freeze();
  static SymmetricKeyParameters _defaultInstance;

  SymmetricKeyParameters_Cipher whichCipher() => _SymmetricKeyParameters_CipherByTag[$_whichOneof(0)];
  void clearCipher() => clearField($_whichOneof(0));

  StreamCipher get stream => $_getN(0);
  set stream(StreamCipher v) { setField(1, v); }
  $core.bool hasStream() => $_has(0);
  void clearStream() => clearField(1);

  BlockCipherParameters get block => $_getN(1);
  set block(BlockCipherParameters v) { setField(2, v); }
  $core.bool hasBlock() => $_has(1);
  void clearBlock() => clearField(2);
}

class AsymmetricKeypairParameters extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('AsymmetricKeypairParameters', package: const $pb.PackageName('opencannabis.crypto'))
    ..e<KeyingScheme>(1, 'scheme', $pb.PbFieldType.OE, KeyingScheme.RSA, KeyingScheme.valueOf, KeyingScheme.values)
    ..a<$44.Hash>(2, 'fingerprint', $pb.PbFieldType.OM, $44.Hash.getDefault, $44.Hash.create)
    ..hasRequiredFields = false
  ;

  AsymmetricKeypairParameters() : super();
  AsymmetricKeypairParameters.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  AsymmetricKeypairParameters.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  AsymmetricKeypairParameters clone() => AsymmetricKeypairParameters()..mergeFromMessage(this);
  AsymmetricKeypairParameters copyWith(void Function(AsymmetricKeypairParameters) updates) => super.copyWith((message) => updates(message as AsymmetricKeypairParameters));
  $pb.BuilderInfo get info_ => _i;
  static AsymmetricKeypairParameters create() => AsymmetricKeypairParameters();
  AsymmetricKeypairParameters createEmptyInstance() => create();
  static $pb.PbList<AsymmetricKeypairParameters> createRepeated() => $pb.PbList<AsymmetricKeypairParameters>();
  static AsymmetricKeypairParameters getDefault() => _defaultInstance ??= create()..freeze();
  static AsymmetricKeypairParameters _defaultInstance;

  KeyingScheme get scheme => $_getN(0);
  set scheme(KeyingScheme v) { setField(1, v); }
  $core.bool hasScheme() => $_has(0);
  void clearScheme() => clearField(1);

  $44.Hash get fingerprint => $_getN(1);
  set fingerprint($44.Hash v) { setField(2, v); }
  $core.bool hasFingerprint() => $_has(1);
  void clearFingerprint() => clearField(2);
}

enum KeyParameters_Architecture {
  scheme, 
  symmetric, 
  notSet
}

class KeyParameters extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, KeyParameters_Architecture> _KeyParameters_ArchitectureByTag = {
    10 : KeyParameters_Architecture.scheme,
    11 : KeyParameters_Architecture.symmetric,
    0 : KeyParameters_Architecture.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('KeyParameters', package: const $pb.PackageName('opencannabis.crypto'))
    ..aOS(1, 'algorithm')
    ..aOS(2, 'format')
    ..a<$core.int>(3, 'bits', $pb.PbFieldType.OU3)
    ..e<KeyType>(4, 'type', $pb.PbFieldType.OE, KeyType.SYMMETRIC, KeyType.valueOf, KeyType.values)
    ..e<KeyDisposition>(5, 'disposition', $pb.PbFieldType.OE, KeyDisposition.PRIVATE, KeyDisposition.valueOf, KeyDisposition.values)
    ..e<KeyingScheme>(10, 'scheme', $pb.PbFieldType.OE, KeyingScheme.RSA, KeyingScheme.valueOf, KeyingScheme.values)
    ..a<SymmetricKeyParameters>(11, 'symmetric', $pb.PbFieldType.OM, SymmetricKeyParameters.getDefault, SymmetricKeyParameters.create)
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  KeyParameters() : super();
  KeyParameters.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  KeyParameters.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  KeyParameters clone() => KeyParameters()..mergeFromMessage(this);
  KeyParameters copyWith(void Function(KeyParameters) updates) => super.copyWith((message) => updates(message as KeyParameters));
  $pb.BuilderInfo get info_ => _i;
  static KeyParameters create() => KeyParameters();
  KeyParameters createEmptyInstance() => create();
  static $pb.PbList<KeyParameters> createRepeated() => $pb.PbList<KeyParameters>();
  static KeyParameters getDefault() => _defaultInstance ??= create()..freeze();
  static KeyParameters _defaultInstance;

  KeyParameters_Architecture whichArchitecture() => _KeyParameters_ArchitectureByTag[$_whichOneof(0)];
  void clearArchitecture() => clearField($_whichOneof(0));

  $core.String get algorithm => $_getS(0, '');
  set algorithm($core.String v) { $_setString(0, v); }
  $core.bool hasAlgorithm() => $_has(0);
  void clearAlgorithm() => clearField(1);

  $core.String get format => $_getS(1, '');
  set format($core.String v) { $_setString(1, v); }
  $core.bool hasFormat() => $_has(1);
  void clearFormat() => clearField(2);

  $core.int get bits => $_get(2, 0);
  set bits($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasBits() => $_has(2);
  void clearBits() => clearField(3);

  KeyType get type => $_getN(3);
  set type(KeyType v) { setField(4, v); }
  $core.bool hasType() => $_has(3);
  void clearType() => clearField(4);

  KeyDisposition get disposition => $_getN(4);
  set disposition(KeyDisposition v) { setField(5, v); }
  $core.bool hasDisposition() => $_has(4);
  void clearDisposition() => clearField(5);

  KeyingScheme get scheme => $_getN(5);
  set scheme(KeyingScheme v) { setField(10, v); }
  $core.bool hasScheme() => $_has(5);
  void clearScheme() => clearField(10);

  SymmetricKeyParameters get symmetric => $_getN(6);
  set symmetric(SymmetricKeyParameters v) { setField(11, v); }
  $core.bool hasSymmetric() => $_has(6);
  void clearSymmetric() => clearField(11);
}

enum InitializationVector_Value {
  raw, 
  b64, 
  number, 
  notSet
}

class InitializationVector extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, InitializationVector_Value> _InitializationVector_ValueByTag = {
    10 : InitializationVector_Value.raw,
    11 : InitializationVector_Value.b64,
    12 : InitializationVector_Value.number,
    0 : InitializationVector_Value.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InitializationVector', package: const $pb.PackageName('opencannabis.crypto'))
    ..e<InitializationVectorMode>(1, 'mode', $pb.PbFieldType.OE, InitializationVectorMode.STATIC_IV, InitializationVectorMode.valueOf, InitializationVectorMode.values)
    ..a<$core.List<$core.int>>(10, 'raw', $pb.PbFieldType.OY)
    ..aOS(11, 'b64')
    ..a<$core.int>(12, 'number', $pb.PbFieldType.OU3)
    ..oo(0, [10, 11, 12])
    ..hasRequiredFields = false
  ;

  InitializationVector() : super();
  InitializationVector.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InitializationVector.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InitializationVector clone() => InitializationVector()..mergeFromMessage(this);
  InitializationVector copyWith(void Function(InitializationVector) updates) => super.copyWith((message) => updates(message as InitializationVector));
  $pb.BuilderInfo get info_ => _i;
  static InitializationVector create() => InitializationVector();
  InitializationVector createEmptyInstance() => create();
  static $pb.PbList<InitializationVector> createRepeated() => $pb.PbList<InitializationVector>();
  static InitializationVector getDefault() => _defaultInstance ??= create()..freeze();
  static InitializationVector _defaultInstance;

  InitializationVector_Value whichValue() => _InitializationVector_ValueByTag[$_whichOneof(0)];
  void clearValue() => clearField($_whichOneof(0));

  InitializationVectorMode get mode => $_getN(0);
  set mode(InitializationVectorMode v) { setField(1, v); }
  $core.bool hasMode() => $_has(0);
  void clearMode() => clearField(1);

  $core.List<$core.int> get raw => $_getN(1);
  set raw($core.List<$core.int> v) { $_setBytes(1, v); }
  $core.bool hasRaw() => $_has(1);
  void clearRaw() => clearField(10);

  $core.String get b64 => $_getS(2, '');
  set b64($core.String v) { $_setString(2, v); }
  $core.bool hasB64() => $_has(2);
  void clearB64() => clearField(11);

  $core.int get number => $_get(3, 0);
  set number($core.int v) { $_setUnsignedInt32(3, v); }
  $core.bool hasNumber() => $_has(3);
  void clearNumber() => clearField(12);
}

enum SymmetricKey_Data {
  raw, 
  b64, 
  notSet
}

class SymmetricKey extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SymmetricKey_Data> _SymmetricKey_DataByTag = {
    10 : SymmetricKey_Data.raw,
    11 : SymmetricKey_Data.b64,
    0 : SymmetricKey_Data.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SymmetricKey', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$core.int>(1, 'bits', $pb.PbFieldType.OU3)
    ..a<InitializationVector>(2, 'iv', $pb.PbFieldType.OM, InitializationVector.getDefault, InitializationVector.create)
    ..a<$core.List<$core.int>>(10, 'raw', $pb.PbFieldType.OY)
    ..aOS(11, 'b64')
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  SymmetricKey() : super();
  SymmetricKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SymmetricKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SymmetricKey clone() => SymmetricKey()..mergeFromMessage(this);
  SymmetricKey copyWith(void Function(SymmetricKey) updates) => super.copyWith((message) => updates(message as SymmetricKey));
  $pb.BuilderInfo get info_ => _i;
  static SymmetricKey create() => SymmetricKey();
  SymmetricKey createEmptyInstance() => create();
  static $pb.PbList<SymmetricKey> createRepeated() => $pb.PbList<SymmetricKey>();
  static SymmetricKey getDefault() => _defaultInstance ??= create()..freeze();
  static SymmetricKey _defaultInstance;

  SymmetricKey_Data whichData() => _SymmetricKey_DataByTag[$_whichOneof(0)];
  void clearData() => clearField($_whichOneof(0));

  $core.int get bits => $_get(0, 0);
  set bits($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasBits() => $_has(0);
  void clearBits() => clearField(1);

  InitializationVector get iv => $_getN(1);
  set iv(InitializationVector v) { setField(2, v); }
  $core.bool hasIv() => $_has(1);
  void clearIv() => clearField(2);

  $core.List<$core.int> get raw => $_getN(2);
  set raw($core.List<$core.int> v) { $_setBytes(2, v); }
  $core.bool hasRaw() => $_has(2);
  void clearRaw() => clearField(10);

  $core.String get b64 => $_getS(3, '');
  set b64($core.String v) { $_setString(3, v); }
  $core.bool hasB64() => $_has(3);
  void clearB64() => clearField(11);
}

enum KeyMaterial_Data {
  raw, 
  pem, 
  notSet
}

class KeyMaterial extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, KeyMaterial_Data> _KeyMaterial_DataByTag = {
    10 : KeyMaterial_Data.raw,
    11 : KeyMaterial_Data.pem,
    0 : KeyMaterial_Data.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('KeyMaterial', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$44.Hash>(1, 'fingerprint', $pb.PbFieldType.OM, $44.Hash.getDefault, $44.Hash.create)
    ..a<KeyParameters>(2, 'params', $pb.PbFieldType.OM, KeyParameters.getDefault, KeyParameters.create)
    ..a<$core.List<$core.int>>(10, 'raw', $pb.PbFieldType.OY)
    ..aOS(11, 'pem')
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  KeyMaterial() : super();
  KeyMaterial.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  KeyMaterial.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  KeyMaterial clone() => KeyMaterial()..mergeFromMessage(this);
  KeyMaterial copyWith(void Function(KeyMaterial) updates) => super.copyWith((message) => updates(message as KeyMaterial));
  $pb.BuilderInfo get info_ => _i;
  static KeyMaterial create() => KeyMaterial();
  KeyMaterial createEmptyInstance() => create();
  static $pb.PbList<KeyMaterial> createRepeated() => $pb.PbList<KeyMaterial>();
  static KeyMaterial getDefault() => _defaultInstance ??= create()..freeze();
  static KeyMaterial _defaultInstance;

  KeyMaterial_Data whichData() => _KeyMaterial_DataByTag[$_whichOneof(0)];
  void clearData() => clearField($_whichOneof(0));

  $44.Hash get fingerprint => $_getN(0);
  set fingerprint($44.Hash v) { setField(1, v); }
  $core.bool hasFingerprint() => $_has(0);
  void clearFingerprint() => clearField(1);

  KeyParameters get params => $_getN(1);
  set params(KeyParameters v) { setField(2, v); }
  $core.bool hasParams() => $_has(1);
  void clearParams() => clearField(2);

  $core.List<$core.int> get raw => $_getN(2);
  set raw($core.List<$core.int> v) { $_setBytes(2, v); }
  $core.bool hasRaw() => $_has(2);
  void clearRaw() => clearField(10);

  $core.String get pem => $_getS(3, '');
  set pem($core.String v) { $_setString(3, v); }
  $core.bool hasPem() => $_has(3);
  void clearPem() => clearField(11);
}

class Keypair extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Keypair', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<KeyMaterial>(1, 'public', $pb.PbFieldType.OM, KeyMaterial.getDefault, KeyMaterial.create)
    ..a<KeyMaterial>(2, 'private', $pb.PbFieldType.OM, KeyMaterial.getDefault, KeyMaterial.create)
    ..hasRequiredFields = false
  ;

  Keypair() : super();
  Keypair.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Keypair.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Keypair clone() => Keypair()..mergeFromMessage(this);
  Keypair copyWith(void Function(Keypair) updates) => super.copyWith((message) => updates(message as Keypair));
  $pb.BuilderInfo get info_ => _i;
  static Keypair create() => Keypair();
  Keypair createEmptyInstance() => create();
  static $pb.PbList<Keypair> createRepeated() => $pb.PbList<Keypair>();
  static Keypair getDefault() => _defaultInstance ??= create()..freeze();
  static Keypair _defaultInstance;

  KeyMaterial get public => $_getN(0);
  set public(KeyMaterial v) { setField(1, v); }
  $core.bool hasPublic() => $_has(0);
  void clearPublic() => clearField(1);

  KeyMaterial get private => $_getN(1);
  set private(KeyMaterial v) { setField(2, v); }
  $core.bool hasPrivate() => $_has(1);
  void clearPrivate() => clearField(2);
}

