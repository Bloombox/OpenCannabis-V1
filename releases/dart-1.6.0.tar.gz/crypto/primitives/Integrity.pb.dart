///
//  Generated code. Do not modify.
//  source: crypto/primitives/Integrity.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Integrity.pbenum.dart';

export 'Integrity.pbenum.dart';

enum Hash_Digest {
  raw, 
  hex, 
  b64, 
  notSet
}

class Hash extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Hash_Digest> _Hash_DigestByTag = {
    2 : Hash_Digest.raw,
    3 : Hash_Digest.hex,
    4 : Hash_Digest.b64,
    0 : Hash_Digest.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Hash', package: const $pb.PackageName('opencannabis.crypto'))
    ..e<HashAlgorithm>(1, 'algorithm', $pb.PbFieldType.OE, HashAlgorithm.SHA1, HashAlgorithm.valueOf, HashAlgorithm.values)
    ..a<$core.List<$core.int>>(2, 'raw', $pb.PbFieldType.OY)
    ..aOS(3, 'hex')
    ..aOS(4, 'b64')
    ..oo(0, [2, 3, 4])
    ..hasRequiredFields = false
  ;

  Hash() : super();
  Hash.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Hash.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Hash clone() => Hash()..mergeFromMessage(this);
  Hash copyWith(void Function(Hash) updates) => super.copyWith((message) => updates(message as Hash));
  $pb.BuilderInfo get info_ => _i;
  static Hash create() => Hash();
  Hash createEmptyInstance() => create();
  static $pb.PbList<Hash> createRepeated() => $pb.PbList<Hash>();
  static Hash getDefault() => _defaultInstance ??= create()..freeze();
  static Hash _defaultInstance;

  Hash_Digest whichDigest() => _Hash_DigestByTag[$_whichOneof(0)];
  void clearDigest() => clearField($_whichOneof(0));

  HashAlgorithm get algorithm => $_getN(0);
  set algorithm(HashAlgorithm v) { setField(1, v); }
  $core.bool hasAlgorithm() => $_has(0);
  void clearAlgorithm() => clearField(1);

  $core.List<$core.int> get raw => $_getN(1);
  set raw($core.List<$core.int> v) { $_setBytes(1, v); }
  $core.bool hasRaw() => $_has(1);
  void clearRaw() => clearField(2);

  $core.String get hex => $_getS(2, '');
  set hex($core.String v) { $_setString(2, v); }
  $core.bool hasHex() => $_has(2);
  void clearHex() => clearField(3);

  $core.String get b64 => $_getS(3, '');
  set b64($core.String v) { $_setString(3, v); }
  $core.bool hasB64() => $_has(3);
  void clearB64() => clearField(4);
}

class HashedData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('HashedData', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$core.List<$core.int>>(1, 'data', $pb.PbFieldType.OY)
    ..a<Hash>(2, 'hash', $pb.PbFieldType.OM, Hash.getDefault, Hash.create)
    ..hasRequiredFields = false
  ;

  HashedData() : super();
  HashedData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  HashedData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  HashedData clone() => HashedData()..mergeFromMessage(this);
  HashedData copyWith(void Function(HashedData) updates) => super.copyWith((message) => updates(message as HashedData));
  $pb.BuilderInfo get info_ => _i;
  static HashedData create() => HashedData();
  HashedData createEmptyInstance() => create();
  static $pb.PbList<HashedData> createRepeated() => $pb.PbList<HashedData>();
  static HashedData getDefault() => _defaultInstance ??= create()..freeze();
  static HashedData _defaultInstance;

  $core.List<$core.int> get data => $_getN(0);
  set data($core.List<$core.int> v) { $_setBytes(0, v); }
  $core.bool hasData() => $_has(0);
  void clearData() => clearField(1);

  Hash get hash => $_getN(1);
  set hash(Hash v) { setField(2, v); }
  $core.bool hasHash() => $_has(1);
  void clearHash() => clearField(2);
}

