///
//  Generated code. Do not modify.
//  source: crypto/primitives/Keys.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const KeyType$json = const {
  '1': 'KeyType',
  '2': const [
    const {'1': 'SYMMETRIC', '2': 0},
    const {'1': 'ASYMMETRIC', '2': 1},
  ],
};

const KeyDisposition$json = const {
  '1': 'KeyDisposition',
  '2': const [
    const {'1': 'PRIVATE', '2': 0},
    const {'1': 'EPHEMERAL', '2': 1},
    const {'1': 'PUBLIC', '2': 2},
  ],
};

const BlockCipher$json = const {
  '1': 'BlockCipher',
  '2': const [
    const {'1': 'UNSPECIFIED_BLOCK_CIPHER', '2': 0},
    const {'1': 'AES', '2': 1},
    const {'1': 'CAMELLIA', '2': 2},
  ],
};

const StreamCipher$json = const {
  '1': 'StreamCipher',
  '2': const [
    const {'1': 'UNSPECIFIED_STREAM_CIPHER', '2': 0},
    const {'1': 'RC5', '2': 1},
    const {'1': 'RC6', '2': 2},
    const {'1': 'CHACHA20', '2': 3},
  ],
};

const KeyAgreement$json = const {
  '1': 'KeyAgreement',
  '2': const [
    const {'1': 'UNSPECIFIED_KEY_AGREEMENT', '2': 0},
    const {'1': 'DHE', '2': 1},
    const {'1': 'ECDHE', '2': 2},
  ],
};

const BlockMode$json = const {
  '1': 'BlockMode',
  '2': const [
    const {'1': 'UNSPECIFIED_BLOCK_MODE', '2': 0},
    const {'1': 'ECB', '2': 1},
    const {'1': 'CBC', '2': 2},
    const {'1': 'CFB', '2': 3},
    const {'1': 'OFB', '2': 4},
    const {'1': 'CTR', '2': 5},
    const {'1': 'CCM', '2': 6},
    const {'1': 'GCM', '2': 7},
    const {'1': 'XTS', '2': 8},
    const {'1': 'KWP', '2': 9},
  ],
};

const KeyingScheme$json = const {
  '1': 'KeyingScheme',
  '2': const [
    const {'1': 'RSA', '2': 0},
    const {'1': 'ECC', '2': 1},
    const {'1': 'DSA', '2': 2},
    const {'1': 'EdDSA', '2': 3},
  ],
};

const InitializationVectorMode$json = const {
  '1': 'InitializationVectorMode',
  '2': const [
    const {'1': 'STATIC_IV', '2': 0},
    const {'1': 'TOTP', '2': 1},
    const {'1': 'COUNTER', '2': 2},
  ],
};

const BlockCipherParameters$json = const {
  '1': 'BlockCipherParameters',
  '2': const [
    const {'1': 'algorithm', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.crypto.BlockCipher', '10': 'algorithm'},
    const {'1': 'mode', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.crypto.BlockMode', '10': 'mode'},
  ],
};

const SymmetricKeyParameters$json = const {
  '1': 'SymmetricKeyParameters',
  '2': const [
    const {'1': 'stream', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.crypto.StreamCipher', '9': 0, '10': 'stream'},
    const {'1': 'block', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.BlockCipherParameters', '9': 0, '10': 'block'},
  ],
  '8': const [
    const {'1': 'cipher'},
  ],
};

const AsymmetricKeypairParameters$json = const {
  '1': 'AsymmetricKeypairParameters',
  '2': const [
    const {'1': 'scheme', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.crypto.KeyingScheme', '10': 'scheme'},
    const {'1': 'fingerprint', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'fingerprint'},
  ],
};

const KeyParameters$json = const {
  '1': 'KeyParameters',
  '2': const [
    const {'1': 'algorithm', '3': 1, '4': 1, '5': 9, '10': 'algorithm'},
    const {'1': 'format', '3': 2, '4': 1, '5': 9, '10': 'format'},
    const {'1': 'bits', '3': 3, '4': 1, '5': 13, '10': 'bits'},
    const {'1': 'type', '3': 4, '4': 1, '5': 14, '6': '.opencannabis.crypto.KeyType', '10': 'type'},
    const {'1': 'disposition', '3': 5, '4': 1, '5': 14, '6': '.opencannabis.crypto.KeyDisposition', '10': 'disposition'},
    const {'1': 'scheme', '3': 10, '4': 1, '5': 14, '6': '.opencannabis.crypto.KeyingScheme', '9': 0, '10': 'scheme'},
    const {'1': 'symmetric', '3': 11, '4': 1, '5': 11, '6': '.opencannabis.crypto.SymmetricKeyParameters', '9': 0, '10': 'symmetric'},
  ],
  '8': const [
    const {'1': 'architecture'},
  ],
};

const InitializationVector$json = const {
  '1': 'InitializationVector',
  '2': const [
    const {'1': 'mode', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.crypto.InitializationVectorMode', '10': 'mode'},
    const {'1': 'raw', '3': 10, '4': 1, '5': 12, '9': 0, '10': 'raw'},
    const {'1': 'b64', '3': 11, '4': 1, '5': 9, '9': 0, '10': 'b64'},
    const {'1': 'number', '3': 12, '4': 1, '5': 13, '9': 0, '10': 'number'},
  ],
  '8': const [
    const {'1': 'value'},
  ],
};

const SymmetricKey$json = const {
  '1': 'SymmetricKey',
  '2': const [
    const {'1': 'bits', '3': 1, '4': 1, '5': 13, '10': 'bits'},
    const {'1': 'iv', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.InitializationVector', '10': 'iv'},
    const {'1': 'raw', '3': 10, '4': 1, '5': 12, '9': 0, '10': 'raw'},
    const {'1': 'b64', '3': 11, '4': 1, '5': 9, '9': 0, '10': 'b64'},
  ],
  '8': const [
    const {'1': 'data'},
  ],
};

const KeyMaterial$json = const {
  '1': 'KeyMaterial',
  '2': const [
    const {'1': 'fingerprint', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'fingerprint'},
    const {'1': 'params', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.KeyParameters', '10': 'params'},
    const {'1': 'raw', '3': 10, '4': 1, '5': 12, '9': 0, '10': 'raw'},
    const {'1': 'pem', '3': 11, '4': 1, '5': 9, '9': 0, '10': 'pem'},
  ],
  '8': const [
    const {'1': 'data'},
  ],
};

const Keypair$json = const {
  '1': 'Keypair',
  '2': const [
    const {'1': 'public', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.crypto.KeyMaterial', '10': 'public'},
    const {'1': 'private', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.KeyMaterial', '10': 'private'},
  ],
};

