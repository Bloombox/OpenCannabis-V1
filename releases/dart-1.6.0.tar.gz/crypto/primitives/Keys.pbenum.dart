///
//  Generated code. Do not modify.
//  source: crypto/primitives/Keys.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class KeyType extends $pb.ProtobufEnum {
  static const KeyType SYMMETRIC = KeyType._(0, 'SYMMETRIC');
  static const KeyType ASYMMETRIC = KeyType._(1, 'ASYMMETRIC');

  static const $core.List<KeyType> values = <KeyType> [
    SYMMETRIC,
    ASYMMETRIC,
  ];

  static final $core.Map<$core.int, KeyType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static KeyType valueOf($core.int value) => _byValue[value];

  const KeyType._($core.int v, $core.String n) : super(v, n);
}

class KeyDisposition extends $pb.ProtobufEnum {
  static const KeyDisposition PRIVATE = KeyDisposition._(0, 'PRIVATE');
  static const KeyDisposition EPHEMERAL = KeyDisposition._(1, 'EPHEMERAL');
  static const KeyDisposition PUBLIC = KeyDisposition._(2, 'PUBLIC');

  static const $core.List<KeyDisposition> values = <KeyDisposition> [
    PRIVATE,
    EPHEMERAL,
    PUBLIC,
  ];

  static final $core.Map<$core.int, KeyDisposition> _byValue = $pb.ProtobufEnum.initByValue(values);
  static KeyDisposition valueOf($core.int value) => _byValue[value];

  const KeyDisposition._($core.int v, $core.String n) : super(v, n);
}

class BlockCipher extends $pb.ProtobufEnum {
  static const BlockCipher UNSPECIFIED_BLOCK_CIPHER = BlockCipher._(0, 'UNSPECIFIED_BLOCK_CIPHER');
  static const BlockCipher AES = BlockCipher._(1, 'AES');
  static const BlockCipher CAMELLIA = BlockCipher._(2, 'CAMELLIA');

  static const $core.List<BlockCipher> values = <BlockCipher> [
    UNSPECIFIED_BLOCK_CIPHER,
    AES,
    CAMELLIA,
  ];

  static final $core.Map<$core.int, BlockCipher> _byValue = $pb.ProtobufEnum.initByValue(values);
  static BlockCipher valueOf($core.int value) => _byValue[value];

  const BlockCipher._($core.int v, $core.String n) : super(v, n);
}

class StreamCipher extends $pb.ProtobufEnum {
  static const StreamCipher UNSPECIFIED_STREAM_CIPHER = StreamCipher._(0, 'UNSPECIFIED_STREAM_CIPHER');
  static const StreamCipher RC5 = StreamCipher._(1, 'RC5');
  static const StreamCipher RC6 = StreamCipher._(2, 'RC6');
  static const StreamCipher CHACHA20 = StreamCipher._(3, 'CHACHA20');

  static const $core.List<StreamCipher> values = <StreamCipher> [
    UNSPECIFIED_STREAM_CIPHER,
    RC5,
    RC6,
    CHACHA20,
  ];

  static final $core.Map<$core.int, StreamCipher> _byValue = $pb.ProtobufEnum.initByValue(values);
  static StreamCipher valueOf($core.int value) => _byValue[value];

  const StreamCipher._($core.int v, $core.String n) : super(v, n);
}

class KeyAgreement extends $pb.ProtobufEnum {
  static const KeyAgreement UNSPECIFIED_KEY_AGREEMENT = KeyAgreement._(0, 'UNSPECIFIED_KEY_AGREEMENT');
  static const KeyAgreement DHE = KeyAgreement._(1, 'DHE');
  static const KeyAgreement ECDHE = KeyAgreement._(2, 'ECDHE');

  static const $core.List<KeyAgreement> values = <KeyAgreement> [
    UNSPECIFIED_KEY_AGREEMENT,
    DHE,
    ECDHE,
  ];

  static final $core.Map<$core.int, KeyAgreement> _byValue = $pb.ProtobufEnum.initByValue(values);
  static KeyAgreement valueOf($core.int value) => _byValue[value];

  const KeyAgreement._($core.int v, $core.String n) : super(v, n);
}

class BlockMode extends $pb.ProtobufEnum {
  static const BlockMode UNSPECIFIED_BLOCK_MODE = BlockMode._(0, 'UNSPECIFIED_BLOCK_MODE');
  static const BlockMode ECB = BlockMode._(1, 'ECB');
  static const BlockMode CBC = BlockMode._(2, 'CBC');
  static const BlockMode CFB = BlockMode._(3, 'CFB');
  static const BlockMode OFB = BlockMode._(4, 'OFB');
  static const BlockMode CTR = BlockMode._(5, 'CTR');
  static const BlockMode CCM = BlockMode._(6, 'CCM');
  static const BlockMode GCM = BlockMode._(7, 'GCM');
  static const BlockMode XTS = BlockMode._(8, 'XTS');
  static const BlockMode KWP = BlockMode._(9, 'KWP');

  static const $core.List<BlockMode> values = <BlockMode> [
    UNSPECIFIED_BLOCK_MODE,
    ECB,
    CBC,
    CFB,
    OFB,
    CTR,
    CCM,
    GCM,
    XTS,
    KWP,
  ];

  static final $core.Map<$core.int, BlockMode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static BlockMode valueOf($core.int value) => _byValue[value];

  const BlockMode._($core.int v, $core.String n) : super(v, n);
}

class KeyingScheme extends $pb.ProtobufEnum {
  static const KeyingScheme RSA = KeyingScheme._(0, 'RSA');
  static const KeyingScheme ECC = KeyingScheme._(1, 'ECC');
  static const KeyingScheme DSA = KeyingScheme._(2, 'DSA');
  static const KeyingScheme EdDSA = KeyingScheme._(3, 'EdDSA');

  static const $core.List<KeyingScheme> values = <KeyingScheme> [
    RSA,
    ECC,
    DSA,
    EdDSA,
  ];

  static final $core.Map<$core.int, KeyingScheme> _byValue = $pb.ProtobufEnum.initByValue(values);
  static KeyingScheme valueOf($core.int value) => _byValue[value];

  const KeyingScheme._($core.int v, $core.String n) : super(v, n);
}

class InitializationVectorMode extends $pb.ProtobufEnum {
  static const InitializationVectorMode STATIC_IV = InitializationVectorMode._(0, 'STATIC_IV');
  static const InitializationVectorMode TOTP = InitializationVectorMode._(1, 'TOTP');
  static const InitializationVectorMode COUNTER = InitializationVectorMode._(2, 'COUNTER');

  static const $core.List<InitializationVectorMode> values = <InitializationVectorMode> [
    STATIC_IV,
    TOTP,
    COUNTER,
  ];

  static final $core.Map<$core.int, InitializationVectorMode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static InitializationVectorMode valueOf($core.int value) => _byValue[value];

  const InitializationVectorMode._($core.int v, $core.String n) : super(v, n);
}

