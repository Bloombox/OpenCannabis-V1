///
//  Generated code. Do not modify.
//  source: crypto/Signature.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'primitives/Keys.pb.dart' as $55;
import 'primitives/Integrity.pb.dart' as $44;

enum Signature_Signature {
  raw, 
  b64, 
  hex, 
  notSet
}

class Signature extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Signature_Signature> _Signature_SignatureByTag = {
    5 : Signature_Signature.raw,
    6 : Signature_Signature.b64,
    7 : Signature_Signature.hex,
    0 : Signature_Signature.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Signature', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$55.KeyMaterial>(1, 'publicKey', $pb.PbFieldType.OM, $55.KeyMaterial.getDefault, $55.KeyMaterial.create)
    ..a<$44.Hash>(2, 'fingerprint', $pb.PbFieldType.OM, $44.Hash.getDefault, $44.Hash.create)
    ..a<$core.List<$core.int>>(5, 'raw', $pb.PbFieldType.OY)
    ..aOS(6, 'b64')
    ..aOS(7, 'hex')
    ..oo(0, [5, 6, 7])
    ..hasRequiredFields = false
  ;

  Signature() : super();
  Signature.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Signature.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Signature clone() => Signature()..mergeFromMessage(this);
  Signature copyWith(void Function(Signature) updates) => super.copyWith((message) => updates(message as Signature));
  $pb.BuilderInfo get info_ => _i;
  static Signature create() => Signature();
  Signature createEmptyInstance() => create();
  static $pb.PbList<Signature> createRepeated() => $pb.PbList<Signature>();
  static Signature getDefault() => _defaultInstance ??= create()..freeze();
  static Signature _defaultInstance;

  Signature_Signature whichSignature() => _Signature_SignatureByTag[$_whichOneof(0)];
  void clearSignature() => clearField($_whichOneof(0));

  $55.KeyMaterial get publicKey => $_getN(0);
  set publicKey($55.KeyMaterial v) { setField(1, v); }
  $core.bool hasPublicKey() => $_has(0);
  void clearPublicKey() => clearField(1);

  $44.Hash get fingerprint => $_getN(1);
  set fingerprint($44.Hash v) { setField(2, v); }
  $core.bool hasFingerprint() => $_has(1);
  void clearFingerprint() => clearField(2);

  $core.List<$core.int> get raw => $_getN(2);
  set raw($core.List<$core.int> v) { $_setBytes(2, v); }
  $core.bool hasRaw() => $_has(2);
  void clearRaw() => clearField(5);

  $core.String get b64 => $_getS(3, '');
  set b64($core.String v) { $_setString(3, v); }
  $core.bool hasB64() => $_has(3);
  void clearB64() => clearField(6);

  $core.String get hex => $_getS(4, '');
  set hex($core.String v) { $_setString(4, v); }
  $core.bool hasHex() => $_has(4);
  void clearHex() => clearField(7);
}

