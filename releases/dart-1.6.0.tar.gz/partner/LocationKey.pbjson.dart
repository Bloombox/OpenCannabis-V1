///
//  Generated code. Do not modify.
//  source: partner/LocationKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const LocationKey$json = const {
  '1': 'LocationKey',
  '2': const [
    const {'1': 'partner', '3': 1, '4': 1, '5': 11, '6': '.bloombox.partner.PartnerKey', '8': const {}, '10': 'partner'},
    const {'1': 'code', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'code'},
  ],
};

