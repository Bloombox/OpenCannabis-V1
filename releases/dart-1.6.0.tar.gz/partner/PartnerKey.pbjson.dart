///
//  Generated code. Do not modify.
//  source: partner/PartnerKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PartnerKey$json = const {
  '1': 'PartnerKey',
  '2': const [
    const {'1': 'code', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'code'},
  ],
};

