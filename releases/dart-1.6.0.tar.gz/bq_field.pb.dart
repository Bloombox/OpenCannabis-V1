///
//  Generated code. Do not modify.
//  source: bq_field.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Bq_field {
  static final $pb.Extension require = $pb.Extension<$core.bool>('google.protobuf.FieldOptions', 'require', 1022, $pb.PbFieldType.OB);
  static final $pb.Extension typeOverride = $pb.Extension<$core.String>('google.protobuf.FieldOptions', 'typeOverride', 1023, $pb.PbFieldType.OS);
  static final $pb.Extension ignore = $pb.Extension<$core.bool>('google.protobuf.FieldOptions', 'ignore', 1024, $pb.PbFieldType.OB);
  static final $pb.Extension description = $pb.Extension<$core.String>('google.protobuf.FieldOptions', 'description', 1025, $pb.PbFieldType.OS);
  static void registerAllExtensions($pb.ExtensionRegistry registry) {
    registry.add(require);
    registry.add(typeOverride);
    registry.add(ignore);
    registry.add(description);
  }
}

