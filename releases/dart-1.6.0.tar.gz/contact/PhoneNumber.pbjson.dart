///
//  Generated code. Do not modify.
//  source: contact/PhoneNumber.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PhoneNumber$json = const {
  '1': 'PhoneNumber',
  '2': const [
    const {'1': 'e164', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'e164'},
    const {'1': 'validated', '3': 2, '4': 1, '5': 8, '8': const {}, '10': 'validated'},
    const {'1': 'display', '3': 3, '4': 1, '5': 9, '8': const {}, '10': 'display'},
  ],
};

