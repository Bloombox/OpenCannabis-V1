///
//  Generated code. Do not modify.
//  source: contact/ContactInfo.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../geo/Location.pb.dart' as $5;
import 'PhoneNumber.pb.dart' as $6;
import 'EmailAddress.pb.dart' as $7;
import 'Website.pb.dart' as $8;

import 'ContactInfo.pbenum.dart';

export 'ContactInfo.pbenum.dart';

class ContactInfo extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ContactInfo', package: const $pb.PackageName('opencannabis.contact'))
    ..a<$5.Location>(1, 'location', $pb.PbFieldType.OM, $5.Location.getDefault, $5.Location.create)
    ..a<$6.PhoneNumber>(2, 'phone', $pb.PbFieldType.OM, $6.PhoneNumber.getDefault, $6.PhoneNumber.create)
    ..a<$7.EmailAddress>(3, 'email', $pb.PbFieldType.OM, $7.EmailAddress.getDefault, $7.EmailAddress.create)
    ..a<$8.Website>(4, 'website', $pb.PbFieldType.OM, $8.Website.getDefault, $8.Website.create)
    ..hasRequiredFields = false
  ;

  ContactInfo() : super();
  ContactInfo.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ContactInfo.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ContactInfo clone() => ContactInfo()..mergeFromMessage(this);
  ContactInfo copyWith(void Function(ContactInfo) updates) => super.copyWith((message) => updates(message as ContactInfo));
  $pb.BuilderInfo get info_ => _i;
  static ContactInfo create() => ContactInfo();
  ContactInfo createEmptyInstance() => create();
  static $pb.PbList<ContactInfo> createRepeated() => $pb.PbList<ContactInfo>();
  static ContactInfo getDefault() => _defaultInstance ??= create()..freeze();
  static ContactInfo _defaultInstance;

  $5.Location get location => $_getN(0);
  set location($5.Location v) { setField(1, v); }
  $core.bool hasLocation() => $_has(0);
  void clearLocation() => clearField(1);

  $6.PhoneNumber get phone => $_getN(1);
  set phone($6.PhoneNumber v) { setField(2, v); }
  $core.bool hasPhone() => $_has(1);
  void clearPhone() => clearField(2);

  $7.EmailAddress get email => $_getN(2);
  set email($7.EmailAddress v) { setField(3, v); }
  $core.bool hasEmail() => $_has(2);
  void clearEmail() => clearField(3);

  $8.Website get website => $_getN(3);
  set website($8.Website v) { setField(4, v); }
  $core.bool hasWebsite() => $_has(3);
  void clearWebsite() => clearField(4);
}

enum SocialInfo_SocialProfile_Provider {
  known, 
  custom, 
  notSet
}

class SocialInfo_SocialProfile extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SocialInfo_SocialProfile_Provider> _SocialInfo_SocialProfile_ProviderByTag = {
    10 : SocialInfo_SocialProfile_Provider.known,
    11 : SocialInfo_SocialProfile_Provider.custom,
    0 : SocialInfo_SocialProfile_Provider.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SocialInfo.SocialProfile', package: const $pb.PackageName('opencannabis.contact'))
    ..aOS(1, 'username')
    ..a<$8.Website>(2, 'url', $pb.PbFieldType.OM, $8.Website.getDefault, $8.Website.create)
    ..e<SocialInfo_SocialProvider>(10, 'known', $pb.PbFieldType.OE, SocialInfo_SocialProvider.UNSPECIFIED_SOCIAL_PROVIDER, SocialInfo_SocialProvider.valueOf, SocialInfo_SocialProvider.values)
    ..aOS(11, 'custom')
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  SocialInfo_SocialProfile() : super();
  SocialInfo_SocialProfile.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SocialInfo_SocialProfile.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SocialInfo_SocialProfile clone() => SocialInfo_SocialProfile()..mergeFromMessage(this);
  SocialInfo_SocialProfile copyWith(void Function(SocialInfo_SocialProfile) updates) => super.copyWith((message) => updates(message as SocialInfo_SocialProfile));
  $pb.BuilderInfo get info_ => _i;
  static SocialInfo_SocialProfile create() => SocialInfo_SocialProfile();
  SocialInfo_SocialProfile createEmptyInstance() => create();
  static $pb.PbList<SocialInfo_SocialProfile> createRepeated() => $pb.PbList<SocialInfo_SocialProfile>();
  static SocialInfo_SocialProfile getDefault() => _defaultInstance ??= create()..freeze();
  static SocialInfo_SocialProfile _defaultInstance;

  SocialInfo_SocialProfile_Provider whichProvider() => _SocialInfo_SocialProfile_ProviderByTag[$_whichOneof(0)];
  void clearProvider() => clearField($_whichOneof(0));

  $core.String get username => $_getS(0, '');
  set username($core.String v) { $_setString(0, v); }
  $core.bool hasUsername() => $_has(0);
  void clearUsername() => clearField(1);

  $8.Website get url => $_getN(1);
  set url($8.Website v) { setField(2, v); }
  $core.bool hasUrl() => $_has(1);
  void clearUrl() => clearField(2);

  SocialInfo_SocialProvider get known => $_getN(2);
  set known(SocialInfo_SocialProvider v) { setField(10, v); }
  $core.bool hasKnown() => $_has(2);
  void clearKnown() => clearField(10);

  $core.String get custom => $_getS(3, '');
  set custom($core.String v) { $_setString(3, v); }
  $core.bool hasCustom() => $_has(3);
  void clearCustom() => clearField(11);
}

class SocialInfo extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SocialInfo', package: const $pb.PackageName('opencannabis.contact'))
    ..pc<SocialInfo_SocialProfile>(1, 'profile', $pb.PbFieldType.PM,SocialInfo_SocialProfile.create)
    ..hasRequiredFields = false
  ;

  SocialInfo() : super();
  SocialInfo.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SocialInfo.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SocialInfo clone() => SocialInfo()..mergeFromMessage(this);
  SocialInfo copyWith(void Function(SocialInfo) updates) => super.copyWith((message) => updates(message as SocialInfo));
  $pb.BuilderInfo get info_ => _i;
  static SocialInfo create() => SocialInfo();
  SocialInfo createEmptyInstance() => create();
  static $pb.PbList<SocialInfo> createRepeated() => $pb.PbList<SocialInfo>();
  static SocialInfo getDefault() => _defaultInstance ??= create()..freeze();
  static SocialInfo _defaultInstance;

  $core.List<SocialInfo_SocialProfile> get profile => $_getList(0);
}

