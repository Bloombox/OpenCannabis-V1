///
//  Generated code. Do not modify.
//  source: contact/ContactInfo.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class SocialInfo_SocialProvider extends $pb.ProtobufEnum {
  static const SocialInfo_SocialProvider UNSPECIFIED_SOCIAL_PROVIDER = SocialInfo_SocialProvider._(0, 'UNSPECIFIED_SOCIAL_PROVIDER');
  static const SocialInfo_SocialProvider FACEBOOK = SocialInfo_SocialProvider._(1, 'FACEBOOK');
  static const SocialInfo_SocialProvider TWITTER = SocialInfo_SocialProvider._(2, 'TWITTER');
  static const SocialInfo_SocialProvider INSTAGRAM = SocialInfo_SocialProvider._(3, 'INSTAGRAM');
  static const SocialInfo_SocialProvider YOUTUBE = SocialInfo_SocialProvider._(4, 'YOUTUBE');
  static const SocialInfo_SocialProvider LEAFLY = SocialInfo_SocialProvider._(5, 'LEAFLY');
  static const SocialInfo_SocialProvider WEEDMAPS = SocialInfo_SocialProvider._(6, 'WEEDMAPS');

  static const $core.List<SocialInfo_SocialProvider> values = <SocialInfo_SocialProvider> [
    UNSPECIFIED_SOCIAL_PROVIDER,
    FACEBOOK,
    TWITTER,
    INSTAGRAM,
    YOUTUBE,
    LEAFLY,
    WEEDMAPS,
  ];

  static final $core.Map<$core.int, SocialInfo_SocialProvider> _byValue = $pb.ProtobufEnum.initByValue(values);
  static SocialInfo_SocialProvider valueOf($core.int value) => _byValue[value];

  const SocialInfo_SocialProvider._($core.int v, $core.String n) : super(v, n);
}

