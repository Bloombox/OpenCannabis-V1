///
//  Generated code. Do not modify.
//  source: oauth/Client.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ResponseType extends $pb.ProtobufEnum {
  static const ResponseType UNSPECIFIED_RESPONSE_TYPE = ResponseType._(0, 'UNSPECIFIED_RESPONSE_TYPE');
  static const ResponseType TOKEN = ResponseType._(1, 'TOKEN');
  static const ResponseType CODE = ResponseType._(2, 'CODE');
  static const ResponseType ID_TOKEN = ResponseType._(3, 'ID_TOKEN');

  static const $core.List<ResponseType> values = <ResponseType> [
    UNSPECIFIED_RESPONSE_TYPE,
    TOKEN,
    CODE,
    ID_TOKEN,
  ];

  static final $core.Map<$core.int, ResponseType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ResponseType valueOf($core.int value) => _byValue[value];

  const ResponseType._($core.int v, $core.String n) : super(v, n);
}

class GrantType extends $pb.ProtobufEnum {
  static const GrantType UNSPECIFIED_GRANT_TYPE = GrantType._(0, 'UNSPECIFIED_GRANT_TYPE');
  static const GrantType AUTHORIZATION_CODE = GrantType._(1, 'AUTHORIZATION_CODE');
  static const GrantType REFRESH_TOKEN = GrantType._(2, 'REFRESH_TOKEN');
  static const GrantType CLIENT_CREDENTIALS = GrantType._(3, 'CLIENT_CREDENTIALS');

  static const $core.List<GrantType> values = <GrantType> [
    UNSPECIFIED_GRANT_TYPE,
    AUTHORIZATION_CODE,
    REFRESH_TOKEN,
    CLIENT_CREDENTIALS,
  ];

  static final $core.Map<$core.int, GrantType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static GrantType valueOf($core.int value) => _byValue[value];

  const GrantType._($core.int v, $core.String n) : super(v, n);
}

