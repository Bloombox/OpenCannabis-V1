///
//  Generated code. Do not modify.
//  source: identity/UserKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class UserKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('UserKey', package: const $pb.PackageName('bloombox.identity'))
    ..aOS(1, 'uid')
    ..aOS(2, 'identity')
    ..hasRequiredFields = false
  ;

  UserKey() : super();
  UserKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  UserKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  UserKey clone() => UserKey()..mergeFromMessage(this);
  UserKey copyWith(void Function(UserKey) updates) => super.copyWith((message) => updates(message as UserKey));
  $pb.BuilderInfo get info_ => _i;
  static UserKey create() => UserKey();
  UserKey createEmptyInstance() => create();
  static $pb.PbList<UserKey> createRepeated() => $pb.PbList<UserKey>();
  static UserKey getDefault() => _defaultInstance ??= create()..freeze();
  static UserKey _defaultInstance;

  $core.String get uid => $_getS(0, '');
  set uid($core.String v) { $_setString(0, v); }
  $core.bool hasUid() => $_has(0);
  void clearUid() => clearField(1);

  $core.String get identity => $_getS(1, '');
  set identity($core.String v) { $_setString(1, v); }
  $core.bool hasIdentity() => $_has(1);
  void clearIdentity() => clearField(2);
}

