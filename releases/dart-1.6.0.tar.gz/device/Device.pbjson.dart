///
//  Generated code. Do not modify.
//  source: device/Device.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const DeviceType$json = const {
  '1': 'DeviceType',
  '2': const [
    const {'1': 'UNKNOWN_DEVICE_TYPE', '2': 0},
    const {'1': 'DESKTOP', '2': 1},
    const {'1': 'PHONE', '2': 2},
    const {'1': 'TABLET', '2': 3},
    const {'1': 'TV', '2': 4},
    const {'1': 'EMBEDDED', '2': 5},
    const {'1': 'SERVER', '2': 6},
  ],
};

const Device$json = const {
  '1': 'Device',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'uuid'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.device.DeviceType', '8': const {}, '10': 'type'},
    const {'1': 'flags', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.device.DeviceFlags', '8': const {}, '10': 'flags'},
    const {'1': 'key', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.device.DeviceCredentials', '8': const {}, '10': 'key'},
  ],
};

const DeviceFlags$json = const {
  '1': 'DeviceFlags',
  '2': const [
    const {'1': 'ephemeral', '3': 1, '4': 1, '5': 8, '8': const {}, '10': 'ephemeral'},
    const {'1': 'managed', '3': 2, '4': 1, '5': 8, '8': const {}, '10': 'managed'},
  ],
};

const DeviceCredentials$json = const {
  '1': 'DeviceCredentials',
  '2': const [
    const {'1': 'public_key', '3': 1, '4': 1, '5': 12, '8': const {}, '10': 'publicKey'},
    const {'1': 'private_key', '3': 2, '4': 1, '5': 12, '8': const {}, '10': 'privateKey'},
    const {'1': 'sha256', '3': 3, '4': 1, '5': 9, '8': const {}, '10': 'sha256'},
    const {'1': 'identity', '3': 4, '4': 1, '5': 9, '8': const {}, '10': 'identity'},
    const {'1': 'authorities', '3': 5, '4': 3, '5': 12, '8': const {}, '10': 'authorities'},
  ],
};

