///
//  Generated code. Do not modify.
//  source: device/Device.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class DeviceType extends $pb.ProtobufEnum {
  static const DeviceType UNKNOWN_DEVICE_TYPE = DeviceType._(0, 'UNKNOWN_DEVICE_TYPE');
  static const DeviceType DESKTOP = DeviceType._(1, 'DESKTOP');
  static const DeviceType PHONE = DeviceType._(2, 'PHONE');
  static const DeviceType TABLET = DeviceType._(3, 'TABLET');
  static const DeviceType TV = DeviceType._(4, 'TV');
  static const DeviceType EMBEDDED = DeviceType._(5, 'EMBEDDED');
  static const DeviceType SERVER = DeviceType._(6, 'SERVER');

  static const $core.List<DeviceType> values = <DeviceType> [
    UNKNOWN_DEVICE_TYPE,
    DESKTOP,
    PHONE,
    TABLET,
    TV,
    EMBEDDED,
    SERVER,
  ];

  static final $core.Map<$core.int, DeviceType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DeviceType valueOf($core.int value) => _byValue[value];

  const DeviceType._($core.int v, $core.String n) : super(v, n);
}

