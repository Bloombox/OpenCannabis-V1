///
//  Generated code. Do not modify.
//  source: person/Person.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Gender$json = const {
  '1': 'Gender',
  '2': const [
    const {'1': 'UNSPECIFIED', '2': 0},
    const {'1': 'MALE', '2': 1},
    const {'1': 'FEMALE', '2': 2},
    const {'1': 'OTHER', '2': 3},
  ],
};

const Person$json = const {
  '1': 'Person',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'name'},
    const {'1': 'legal_name', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'legalName'},
    const {'1': 'alternate_name', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'alternateName'},
    const {'1': 'contact', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.contact.ContactInfo', '8': const {}, '10': 'contact'},
    const {'1': 'date_of_birth', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Date', '8': const {}, '10': 'dateOfBirth'},
    const {'1': 'gender', '3': 6, '4': 1, '5': 14, '6': '.opencannabis.person.Gender', '8': const {}, '10': 'gender'},
  ],
};

