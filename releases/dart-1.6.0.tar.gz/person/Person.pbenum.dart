///
//  Generated code. Do not modify.
//  source: person/Person.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Gender extends $pb.ProtobufEnum {
  static const Gender UNSPECIFIED = Gender._(0, 'UNSPECIFIED');
  static const Gender MALE = Gender._(1, 'MALE');
  static const Gender FEMALE = Gender._(2, 'FEMALE');
  static const Gender OTHER = Gender._(3, 'OTHER');

  static const $core.List<Gender> values = <Gender> [
    UNSPECIFIED,
    MALE,
    FEMALE,
    OTHER,
  ];

  static final $core.Map<$core.int, Gender> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Gender valueOf($core.int value) => _byValue[value];

  const Gender._($core.int v, $core.String n) : super(v, n);
}

