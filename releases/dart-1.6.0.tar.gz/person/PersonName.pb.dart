///
//  Generated code. Do not modify.
//  source: person/PersonName.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Name extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Name', package: const $pb.PackageName('opencannabis.person'))
    ..aOS(1, 'fullName')
    ..aOS(2, 'firstName')
    ..aOS(3, 'lastName')
    ..aOS(4, 'middleName')
    ..aOS(5, 'prefix')
    ..aOS(6, 'postfix')
    ..hasRequiredFields = false
  ;

  Name() : super();
  Name.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Name.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Name clone() => Name()..mergeFromMessage(this);
  Name copyWith(void Function(Name) updates) => super.copyWith((message) => updates(message as Name));
  $pb.BuilderInfo get info_ => _i;
  static Name create() => Name();
  Name createEmptyInstance() => create();
  static $pb.PbList<Name> createRepeated() => $pb.PbList<Name>();
  static Name getDefault() => _defaultInstance ??= create()..freeze();
  static Name _defaultInstance;

  $core.String get fullName => $_getS(0, '');
  set fullName($core.String v) { $_setString(0, v); }
  $core.bool hasFullName() => $_has(0);
  void clearFullName() => clearField(1);

  $core.String get firstName => $_getS(1, '');
  set firstName($core.String v) { $_setString(1, v); }
  $core.bool hasFirstName() => $_has(1);
  void clearFirstName() => clearField(2);

  $core.String get lastName => $_getS(2, '');
  set lastName($core.String v) { $_setString(2, v); }
  $core.bool hasLastName() => $_has(2);
  void clearLastName() => clearField(3);

  $core.String get middleName => $_getS(3, '');
  set middleName($core.String v) { $_setString(3, v); }
  $core.bool hasMiddleName() => $_has(3);
  void clearMiddleName() => clearField(4);

  $core.String get prefix => $_getS(4, '');
  set prefix($core.String v) { $_setString(4, v); }
  $core.bool hasPrefix() => $_has(4);
  void clearPrefix() => clearField(5);

  $core.String get postfix => $_getS(5, '');
  set postfix($core.String v) { $_setString(5, v); }
  $core.bool hasPostfix() => $_has(5);
  void clearPostfix() => clearField(6);
}

