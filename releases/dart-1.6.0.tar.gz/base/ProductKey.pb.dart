///
//  Generated code. Do not modify.
//  source: base/ProductKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../content/Name.pb.dart' as $3;

import 'ProductKind.pbenum.dart' as $14;

class ProductReference extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductReference', package: const $pb.PackageName('opencannabis.base'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<ProductKey>(2, 'key', $pb.PbFieldType.OM, ProductKey.getDefault, ProductKey.create)
    ..hasRequiredFields = false
  ;

  ProductReference() : super();
  ProductReference.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductReference.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductReference clone() => ProductReference()..mergeFromMessage(this);
  ProductReference copyWith(void Function(ProductReference) updates) => super.copyWith((message) => updates(message as ProductReference));
  $pb.BuilderInfo get info_ => _i;
  static ProductReference create() => ProductReference();
  ProductReference createEmptyInstance() => create();
  static $pb.PbList<ProductReference> createRepeated() => $pb.PbList<ProductReference>();
  static ProductReference getDefault() => _defaultInstance ??= create()..freeze();
  static ProductReference _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  ProductKey get key => $_getN(1);
  set key(ProductKey v) { setField(2, v); }
  $core.bool hasKey() => $_has(1);
  void clearKey() => clearField(2);
}

class ProductKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductKey', package: const $pb.PackageName('opencannabis.base'))
    ..aOS(1, 'id')
    ..e<$14.ProductKind>(2, 'type', $pb.PbFieldType.OE, $14.ProductKind.FLOWERS, $14.ProductKind.valueOf, $14.ProductKind.values)
    ..hasRequiredFields = false
  ;

  ProductKey() : super();
  ProductKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductKey clone() => ProductKey()..mergeFromMessage(this);
  ProductKey copyWith(void Function(ProductKey) updates) => super.copyWith((message) => updates(message as ProductKey));
  $pb.BuilderInfo get info_ => _i;
  static ProductKey create() => ProductKey();
  ProductKey createEmptyInstance() => create();
  static $pb.PbList<ProductKey> createRepeated() => $pb.PbList<ProductKey>();
  static ProductKey getDefault() => _defaultInstance ??= create()..freeze();
  static ProductKey _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $14.ProductKind get type => $_getN(1);
  set type($14.ProductKind v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);
}

