///
//  Generated code. Do not modify.
//  source: base/ProductKind.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ProductKind extends $pb.ProtobufEnum {
  static const ProductKind FLOWERS = ProductKind._(0, 'FLOWERS');
  static const ProductKind EDIBLES = ProductKind._(1, 'EDIBLES');
  static const ProductKind EXTRACTS = ProductKind._(2, 'EXTRACTS');
  static const ProductKind PREROLLS = ProductKind._(3, 'PREROLLS');
  static const ProductKind APOTHECARY = ProductKind._(4, 'APOTHECARY');
  static const ProductKind CARTRIDGES = ProductKind._(5, 'CARTRIDGES');
  static const ProductKind PLANTS = ProductKind._(6, 'PLANTS');
  static const ProductKind MERCHANDISE = ProductKind._(7, 'MERCHANDISE');

  static const $core.List<ProductKind> values = <ProductKind> [
    FLOWERS,
    EDIBLES,
    EXTRACTS,
    PREROLLS,
    APOTHECARY,
    CARTRIDGES,
    PLANTS,
    MERCHANDISE,
  ];

  static final $core.Map<$core.int, ProductKind> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ProductKind valueOf($core.int value) => _byValue[value];

  const ProductKind._($core.int v, $core.String n) : super(v, n);
}

