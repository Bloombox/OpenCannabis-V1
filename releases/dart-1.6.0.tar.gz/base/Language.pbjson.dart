///
//  Generated code. Do not modify.
//  source: base/Language.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Language$json = const {
  '1': 'Language',
  '2': const [
    const {'1': 'LANGUAGE_UNSPECIFIED', '2': 0},
    const {'1': 'ENGLISH', '2': 1},
    const {'1': 'SPANISH', '2': 2},
    const {'1': 'FRENCH', '2': 3},
  ],
};

