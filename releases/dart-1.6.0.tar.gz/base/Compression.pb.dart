///
//  Generated code. Do not modify.
//  source: base/Compression.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Compression.pbenum.dart';

export 'Compression.pbenum.dart';

class Compression extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Compression', package: const $pb.PackageName('opencannabis.base'))
    ..aOB(1, 'enabled')
    ..e<Compression_Type>(2, 'type', $pb.PbFieldType.OE, Compression_Type.NO_COMPRESSION, Compression_Type.valueOf, Compression_Type.values)
    ..hasRequiredFields = false
  ;

  Compression() : super();
  Compression.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Compression.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Compression clone() => Compression()..mergeFromMessage(this);
  Compression copyWith(void Function(Compression) updates) => super.copyWith((message) => updates(message as Compression));
  $pb.BuilderInfo get info_ => _i;
  static Compression create() => Compression();
  Compression createEmptyInstance() => create();
  static $pb.PbList<Compression> createRepeated() => $pb.PbList<Compression>();
  static Compression getDefault() => _defaultInstance ??= create()..freeze();
  static Compression _defaultInstance;

  $core.bool get enabled => $_get(0, false);
  set enabled($core.bool v) { $_setBool(0, v); }
  $core.bool hasEnabled() => $_has(0);
  void clearEnabled() => clearField(1);

  Compression_Type get type => $_getN(1);
  set type(Compression_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);
}

