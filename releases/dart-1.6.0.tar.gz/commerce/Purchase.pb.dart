///
//  Generated code. Do not modify.
//  source: commerce/Purchase.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;
import '../accounting/Taxes.pb.dart' as $56;
import 'Discounts.pb.dart' as $57;
import '../inventory/InventoryProduct.pb.dart' as $58;
import 'Item.pb.dart' as $21;
import '../crypto/Signature.pb.dart' as $59;
import 'Currency.pb.dart' as $15;

import 'Purchase.pbenum.dart';
import 'payments/Payment.pbenum.dart' as $22;

export 'Purchase.pbenum.dart';

class PurchaseLogEntry extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseLogEntry', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<PurchaseStatus>(1, 'status', $pb.PbFieldType.OE, PurchaseStatus.FRESH, PurchaseStatus.valueOf, PurchaseStatus.values)
    ..e<PurchaseEvent>(2, 'event', $pb.PbFieldType.OE, PurchaseEvent.STATUS, PurchaseEvent.valueOf, PurchaseEvent.values)
    ..a<$0.Instant>(3, 'instant', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..aOS(4, 'sku')
    ..aOS(5, 'message')
    ..hasRequiredFields = false
  ;

  PurchaseLogEntry() : super();
  PurchaseLogEntry.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseLogEntry.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseLogEntry clone() => PurchaseLogEntry()..mergeFromMessage(this);
  PurchaseLogEntry copyWith(void Function(PurchaseLogEntry) updates) => super.copyWith((message) => updates(message as PurchaseLogEntry));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseLogEntry create() => PurchaseLogEntry();
  PurchaseLogEntry createEmptyInstance() => create();
  static $pb.PbList<PurchaseLogEntry> createRepeated() => $pb.PbList<PurchaseLogEntry>();
  static PurchaseLogEntry getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseLogEntry _defaultInstance;

  PurchaseStatus get status => $_getN(0);
  set status(PurchaseStatus v) { setField(1, v); }
  $core.bool hasStatus() => $_has(0);
  void clearStatus() => clearField(1);

  PurchaseEvent get event => $_getN(1);
  set event(PurchaseEvent v) { setField(2, v); }
  $core.bool hasEvent() => $_has(1);
  void clearEvent() => clearField(2);

  $0.Instant get instant => $_getN(2);
  set instant($0.Instant v) { setField(3, v); }
  $core.bool hasInstant() => $_has(2);
  void clearInstant() => clearField(3);

  $core.String get sku => $_getS(3, '');
  set sku($core.String v) { $_setString(3, v); }
  $core.bool hasSku() => $_has(3);
  void clearSku() => clearField(4);

  $core.String get message => $_getS(4, '');
  set message($core.String v) { $_setString(4, v); }
  $core.bool hasMessage() => $_has(4);
  void clearMessage() => clearField(5);
}

class BillOfCharges extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BillOfCharges', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<$22.BillStatus>(1, 'status', $pb.PbFieldType.OE, $22.BillStatus.SUSPENSE, $22.BillStatus.valueOf, $22.BillStatus.values)
    ..pc<$56.Tax>(2, 'tax', $pb.PbFieldType.PM,$56.Tax.create)
    ..pc<$57.Discount>(3, 'discount', $pb.PbFieldType.PM,$57.Discount.create)
    ..a<$core.double>(4, 'price', $pb.PbFieldType.OD)
    ..a<$core.double>(5, 'taxes', $pb.PbFieldType.OD)
    ..a<$core.double>(6, 'discounts', $pb.PbFieldType.OD)
    ..a<$core.double>(7, 'subtotal', $pb.PbFieldType.OD)
    ..a<$core.double>(8, 'total', $pb.PbFieldType.OD)
    ..hasRequiredFields = false
  ;

  BillOfCharges() : super();
  BillOfCharges.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BillOfCharges.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BillOfCharges clone() => BillOfCharges()..mergeFromMessage(this);
  BillOfCharges copyWith(void Function(BillOfCharges) updates) => super.copyWith((message) => updates(message as BillOfCharges));
  $pb.BuilderInfo get info_ => _i;
  static BillOfCharges create() => BillOfCharges();
  BillOfCharges createEmptyInstance() => create();
  static $pb.PbList<BillOfCharges> createRepeated() => $pb.PbList<BillOfCharges>();
  static BillOfCharges getDefault() => _defaultInstance ??= create()..freeze();
  static BillOfCharges _defaultInstance;

  $22.BillStatus get status => $_getN(0);
  set status($22.BillStatus v) { setField(1, v); }
  $core.bool hasStatus() => $_has(0);
  void clearStatus() => clearField(1);

  $core.List<$56.Tax> get tax => $_getList(1);

  $core.List<$57.Discount> get discount => $_getList(2);

  $core.double get price => $_getN(3);
  set price($core.double v) { $_setDouble(3, v); }
  $core.bool hasPrice() => $_has(3);
  void clearPrice() => clearField(4);

  $core.double get taxes => $_getN(4);
  set taxes($core.double v) { $_setDouble(4, v); }
  $core.bool hasTaxes() => $_has(4);
  void clearTaxes() => clearField(5);

  $core.double get discounts => $_getN(5);
  set discounts($core.double v) { $_setDouble(5, v); }
  $core.bool hasDiscounts() => $_has(5);
  void clearDiscounts() => clearField(6);

  $core.double get subtotal => $_getN(6);
  set subtotal($core.double v) { $_setDouble(6, v); }
  $core.bool hasSubtotal() => $_has(6);
  void clearSubtotal() => clearField(7);

  $core.double get total => $_getN(7);
  set total($core.double v) { $_setDouble(7, v); }
  $core.bool hasTotal() => $_has(7);
  void clearTotal() => clearField(8);
}

class TicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TicketItem', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$58.InventoryKey>(1, 'key', $pb.PbFieldType.OM, $58.InventoryKey.getDefault, $58.InventoryKey.create)
    ..aOS(2, 'sku')
    ..a<$21.Item>(3, 'item', $pb.PbFieldType.OM, $21.Item.getDefault, $21.Item.create)
    ..a<BillOfCharges>(4, 'line', $pb.PbFieldType.OM, BillOfCharges.getDefault, BillOfCharges.create)
    ..hasRequiredFields = false
  ;

  TicketItem() : super();
  TicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TicketItem clone() => TicketItem()..mergeFromMessage(this);
  TicketItem copyWith(void Function(TicketItem) updates) => super.copyWith((message) => updates(message as TicketItem));
  $pb.BuilderInfo get info_ => _i;
  static TicketItem create() => TicketItem();
  TicketItem createEmptyInstance() => create();
  static $pb.PbList<TicketItem> createRepeated() => $pb.PbList<TicketItem>();
  static TicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static TicketItem _defaultInstance;

  $58.InventoryKey get key => $_getN(0);
  set key($58.InventoryKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.String get sku => $_getS(1, '');
  set sku($core.String v) { $_setString(1, v); }
  $core.bool hasSku() => $_has(1);
  void clearSku() => clearField(2);

  $21.Item get item => $_getN(2);
  set item($21.Item v) { setField(3, v); }
  $core.bool hasItem() => $_has(2);
  void clearItem() => clearField(3);

  BillOfCharges get line => $_getN(3);
  set line(BillOfCharges v) { setField(4, v); }
  $core.bool hasLine() => $_has(3);
  void clearLine() => clearField(4);
}

class PurchaseTimestamps extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseTimestamps', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$0.Instant>(1, 'established', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(2, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(3, 'modified', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(4, 'executed', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(5, 'finalized', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  PurchaseTimestamps() : super();
  PurchaseTimestamps.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseTimestamps.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseTimestamps clone() => PurchaseTimestamps()..mergeFromMessage(this);
  PurchaseTimestamps copyWith(void Function(PurchaseTimestamps) updates) => super.copyWith((message) => updates(message as PurchaseTimestamps));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseTimestamps create() => PurchaseTimestamps();
  PurchaseTimestamps createEmptyInstance() => create();
  static $pb.PbList<PurchaseTimestamps> createRepeated() => $pb.PbList<PurchaseTimestamps>();
  static PurchaseTimestamps getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseTimestamps _defaultInstance;

  $0.Instant get established => $_getN(0);
  set established($0.Instant v) { setField(1, v); }
  $core.bool hasEstablished() => $_has(0);
  void clearEstablished() => clearField(1);

  $0.Instant get created => $_getN(1);
  set created($0.Instant v) { setField(2, v); }
  $core.bool hasCreated() => $_has(1);
  void clearCreated() => clearField(2);

  $0.Instant get modified => $_getN(2);
  set modified($0.Instant v) { setField(3, v); }
  $core.bool hasModified() => $_has(2);
  void clearModified() => clearField(3);

  $0.Instant get executed => $_getN(3);
  set executed($0.Instant v) { setField(4, v); }
  $core.bool hasExecuted() => $_has(3);
  void clearExecuted() => clearField(4);

  $0.Instant get finalized => $_getN(4);
  set finalized($0.Instant v) { setField(5, v); }
  $core.bool hasFinalized() => $_has(4);
  void clearFinalized() => clearField(5);
}

class PurchaseKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseKey', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'uuid')
    ..hasRequiredFields = false
  ;

  PurchaseKey() : super();
  PurchaseKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseKey clone() => PurchaseKey()..mergeFromMessage(this);
  PurchaseKey copyWith(void Function(PurchaseKey) updates) => super.copyWith((message) => updates(message as PurchaseKey));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseKey create() => PurchaseKey();
  PurchaseKey createEmptyInstance() => create();
  static $pb.PbList<PurchaseKey> createRepeated() => $pb.PbList<PurchaseKey>();
  static PurchaseKey getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseKey _defaultInstance;

  $core.String get uuid => $_getS(0, '');
  set uuid($core.String v) { $_setString(0, v); }
  $core.bool hasUuid() => $_has(0);
  void clearUuid() => clearField(1);
}

class PurchaseSignature extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseSignature', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'nonce')
    ..a<$59.Signature>(2, 'facilitator', $pb.PbFieldType.OM, $59.Signature.getDefault, $59.Signature.create)
    ..a<$59.Signature>(3, 'customer', $pb.PbFieldType.OM, $59.Signature.getDefault, $59.Signature.create)
    ..hasRequiredFields = false
  ;

  PurchaseSignature() : super();
  PurchaseSignature.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseSignature.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseSignature clone() => PurchaseSignature()..mergeFromMessage(this);
  PurchaseSignature copyWith(void Function(PurchaseSignature) updates) => super.copyWith((message) => updates(message as PurchaseSignature));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseSignature create() => PurchaseSignature();
  PurchaseSignature createEmptyInstance() => create();
  static $pb.PbList<PurchaseSignature> createRepeated() => $pb.PbList<PurchaseSignature>();
  static PurchaseSignature getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseSignature _defaultInstance;

  $core.String get nonce => $_getS(0, '');
  set nonce($core.String v) { $_setString(0, v); }
  $core.bool hasNonce() => $_has(0);
  void clearNonce() => clearField(1);

  $59.Signature get facilitator => $_getN(1);
  set facilitator($59.Signature v) { setField(2, v); }
  $core.bool hasFacilitator() => $_has(1);
  void clearFacilitator() => clearField(2);

  $59.Signature get customer => $_getN(2);
  set customer($59.Signature v) { setField(3, v); }
  $core.bool hasCustomer() => $_has(2);
  void clearCustomer() => clearField(3);
}

class PurchaseCustomer extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseCustomer', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'uniqueId')
    ..a<PurchaseSignature>(2, 'signature', $pb.PbFieldType.OM, PurchaseSignature.getDefault, PurchaseSignature.create)
    ..hasRequiredFields = false
  ;

  PurchaseCustomer() : super();
  PurchaseCustomer.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseCustomer.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseCustomer clone() => PurchaseCustomer()..mergeFromMessage(this);
  PurchaseCustomer copyWith(void Function(PurchaseCustomer) updates) => super.copyWith((message) => updates(message as PurchaseCustomer));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseCustomer create() => PurchaseCustomer();
  PurchaseCustomer createEmptyInstance() => create();
  static $pb.PbList<PurchaseCustomer> createRepeated() => $pb.PbList<PurchaseCustomer>();
  static PurchaseCustomer getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseCustomer _defaultInstance;

  $core.String get uniqueId => $_getS(0, '');
  set uniqueId($core.String v) { $_setString(0, v); }
  $core.bool hasUniqueId() => $_has(0);
  void clearUniqueId() => clearField(1);

  PurchaseSignature get signature => $_getN(1);
  set signature(PurchaseSignature v) { setField(2, v); }
  $core.bool hasSignature() => $_has(1);
  void clearSignature() => clearField(2);
}

class PurchaseFacilitator extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PurchaseFacilitator', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<PurchaseAuthority>(1, 'authority', $pb.PbFieldType.OE, PurchaseAuthority.STANDARD, PurchaseAuthority.valueOf, PurchaseAuthority.values)
    ..aOS(2, 'agent')
    ..aOS(3, 'device')
    ..a<PurchaseSignature>(4, 'signature', $pb.PbFieldType.OM, PurchaseSignature.getDefault, PurchaseSignature.create)
    ..hasRequiredFields = false
  ;

  PurchaseFacilitator() : super();
  PurchaseFacilitator.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PurchaseFacilitator.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PurchaseFacilitator clone() => PurchaseFacilitator()..mergeFromMessage(this);
  PurchaseFacilitator copyWith(void Function(PurchaseFacilitator) updates) => super.copyWith((message) => updates(message as PurchaseFacilitator));
  $pb.BuilderInfo get info_ => _i;
  static PurchaseFacilitator create() => PurchaseFacilitator();
  PurchaseFacilitator createEmptyInstance() => create();
  static $pb.PbList<PurchaseFacilitator> createRepeated() => $pb.PbList<PurchaseFacilitator>();
  static PurchaseFacilitator getDefault() => _defaultInstance ??= create()..freeze();
  static PurchaseFacilitator _defaultInstance;

  PurchaseAuthority get authority => $_getN(0);
  set authority(PurchaseAuthority v) { setField(1, v); }
  $core.bool hasAuthority() => $_has(0);
  void clearAuthority() => clearField(1);

  $core.String get agent => $_getS(1, '');
  set agent($core.String v) { $_setString(1, v); }
  $core.bool hasAgent() => $_has(1);
  void clearAgent() => clearField(2);

  $core.String get device => $_getS(2, '');
  set device($core.String v) { $_setString(2, v); }
  $core.bool hasDevice() => $_has(2);
  void clearDevice() => clearField(3);

  PurchaseSignature get signature => $_getN(3);
  set signature(PurchaseSignature v) { setField(4, v); }
  $core.bool hasSignature() => $_has(3);
  void clearSignature() => clearField(4);
}

class PaymentKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PaymentKey', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'uuid')
    ..hasRequiredFields = false
  ;

  PaymentKey() : super();
  PaymentKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PaymentKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PaymentKey clone() => PaymentKey()..mergeFromMessage(this);
  PaymentKey copyWith(void Function(PaymentKey) updates) => super.copyWith((message) => updates(message as PaymentKey));
  $pb.BuilderInfo get info_ => _i;
  static PaymentKey create() => PaymentKey();
  PaymentKey createEmptyInstance() => create();
  static $pb.PbList<PaymentKey> createRepeated() => $pb.PbList<PaymentKey>();
  static PaymentKey getDefault() => _defaultInstance ??= create()..freeze();
  static PaymentKey _defaultInstance;

  $core.String get uuid => $_getS(0, '');
  set uuid($core.String v) { $_setString(0, v); }
  $core.bool hasUuid() => $_has(0);
  void clearUuid() => clearField(1);
}

class Payment_CashPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment.CashPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$15.CurrencyValue>(1, 'tendered', $pb.PbFieldType.OM, $15.CurrencyValue.getDefault, $15.CurrencyValue.create)
    ..a<$15.CurrencyValue>(2, 'change', $pb.PbFieldType.OM, $15.CurrencyValue.getDefault, $15.CurrencyValue.create)
    ..hasRequiredFields = false
  ;

  Payment_CashPayment() : super();
  Payment_CashPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment_CashPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment_CashPayment clone() => Payment_CashPayment()..mergeFromMessage(this);
  Payment_CashPayment copyWith(void Function(Payment_CashPayment) updates) => super.copyWith((message) => updates(message as Payment_CashPayment));
  $pb.BuilderInfo get info_ => _i;
  static Payment_CashPayment create() => Payment_CashPayment();
  Payment_CashPayment createEmptyInstance() => create();
  static $pb.PbList<Payment_CashPayment> createRepeated() => $pb.PbList<Payment_CashPayment>();
  static Payment_CashPayment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment_CashPayment _defaultInstance;

  $15.CurrencyValue get tendered => $_getN(0);
  set tendered($15.CurrencyValue v) { setField(1, v); }
  $core.bool hasTendered() => $_has(0);
  void clearTendered() => clearField(1);

  $15.CurrencyValue get change => $_getN(1);
  set change($15.CurrencyValue v) { setField(2, v); }
  $core.bool hasChange() => $_has(1);
  void clearChange() => clearField(2);
}

class Payment_CheckPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment.CheckPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'checkNumber')
    ..aOS(2, 'routingNumber')
    ..aOS(3, 'accountNumber')
    ..aOS(4, 'institution')
    ..aOB(5, 'certified')
    ..hasRequiredFields = false
  ;

  Payment_CheckPayment() : super();
  Payment_CheckPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment_CheckPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment_CheckPayment clone() => Payment_CheckPayment()..mergeFromMessage(this);
  Payment_CheckPayment copyWith(void Function(Payment_CheckPayment) updates) => super.copyWith((message) => updates(message as Payment_CheckPayment));
  $pb.BuilderInfo get info_ => _i;
  static Payment_CheckPayment create() => Payment_CheckPayment();
  Payment_CheckPayment createEmptyInstance() => create();
  static $pb.PbList<Payment_CheckPayment> createRepeated() => $pb.PbList<Payment_CheckPayment>();
  static Payment_CheckPayment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment_CheckPayment _defaultInstance;

  $core.String get checkNumber => $_getS(0, '');
  set checkNumber($core.String v) { $_setString(0, v); }
  $core.bool hasCheckNumber() => $_has(0);
  void clearCheckNumber() => clearField(1);

  $core.String get routingNumber => $_getS(1, '');
  set routingNumber($core.String v) { $_setString(1, v); }
  $core.bool hasRoutingNumber() => $_has(1);
  void clearRoutingNumber() => clearField(2);

  $core.String get accountNumber => $_getS(2, '');
  set accountNumber($core.String v) { $_setString(2, v); }
  $core.bool hasAccountNumber() => $_has(2);
  void clearAccountNumber() => clearField(3);

  $core.String get institution => $_getS(3, '');
  set institution($core.String v) { $_setString(3, v); }
  $core.bool hasInstitution() => $_has(3);
  void clearInstitution() => clearField(4);

  $core.bool get certified => $_get(4, false);
  set certified($core.bool v) { $_setBool(4, v); }
  $core.bool hasCertified() => $_has(4);
  void clearCertified() => clearField(5);
}

class Payment_CardPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment.CardPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<$22.PaymentCardType>(1, 'cardType', $pb.PbFieldType.OE, $22.PaymentCardType.NO_CARD_TYPE, $22.PaymentCardType.valueOf, $22.PaymentCardType.values)
    ..hasRequiredFields = false
  ;

  Payment_CardPayment() : super();
  Payment_CardPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment_CardPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment_CardPayment clone() => Payment_CardPayment()..mergeFromMessage(this);
  Payment_CardPayment copyWith(void Function(Payment_CardPayment) updates) => super.copyWith((message) => updates(message as Payment_CardPayment));
  $pb.BuilderInfo get info_ => _i;
  static Payment_CardPayment create() => Payment_CardPayment();
  Payment_CardPayment createEmptyInstance() => create();
  static $pb.PbList<Payment_CardPayment> createRepeated() => $pb.PbList<Payment_CardPayment>();
  static Payment_CardPayment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment_CardPayment _defaultInstance;

  $22.PaymentCardType get cardType => $_getN(0);
  set cardType($22.PaymentCardType v) { setField(1, v); }
  $core.bool hasCardType() => $_has(0);
  void clearCardType() => clearField(1);
}

class Payment_BankPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment.BankPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'routingNumber')
    ..aOS(2, 'accountNumber')
    ..aOS(3, 'reference')
    ..hasRequiredFields = false
  ;

  Payment_BankPayment() : super();
  Payment_BankPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment_BankPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment_BankPayment clone() => Payment_BankPayment()..mergeFromMessage(this);
  Payment_BankPayment copyWith(void Function(Payment_BankPayment) updates) => super.copyWith((message) => updates(message as Payment_BankPayment));
  $pb.BuilderInfo get info_ => _i;
  static Payment_BankPayment create() => Payment_BankPayment();
  Payment_BankPayment createEmptyInstance() => create();
  static $pb.PbList<Payment_BankPayment> createRepeated() => $pb.PbList<Payment_BankPayment>();
  static Payment_BankPayment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment_BankPayment _defaultInstance;

  $core.String get routingNumber => $_getS(0, '');
  set routingNumber($core.String v) { $_setString(0, v); }
  $core.bool hasRoutingNumber() => $_has(0);
  void clearRoutingNumber() => clearField(1);

  $core.String get accountNumber => $_getS(1, '');
  set accountNumber($core.String v) { $_setString(1, v); }
  $core.bool hasAccountNumber() => $_has(1);
  void clearAccountNumber() => clearField(2);

  $core.String get reference => $_getS(2, '');
  set reference($core.String v) { $_setString(2, v); }
  $core.bool hasReference() => $_has(2);
  void clearReference() => clearField(3);
}

class Payment_DigitalPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment.DigitalPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<$22.DigitalPaymentNetwork>(1, 'network', $pb.PbFieldType.OE, $22.DigitalPaymentNetwork.UNSPECIFIED_NETWORK, $22.DigitalPaymentNetwork.valueOf, $22.DigitalPaymentNetwork.values)
    ..aOS(2, 'username')
    ..aOS(3, 'reference')
    ..hasRequiredFields = false
  ;

  Payment_DigitalPayment() : super();
  Payment_DigitalPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment_DigitalPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment_DigitalPayment clone() => Payment_DigitalPayment()..mergeFromMessage(this);
  Payment_DigitalPayment copyWith(void Function(Payment_DigitalPayment) updates) => super.copyWith((message) => updates(message as Payment_DigitalPayment));
  $pb.BuilderInfo get info_ => _i;
  static Payment_DigitalPayment create() => Payment_DigitalPayment();
  Payment_DigitalPayment createEmptyInstance() => create();
  static $pb.PbList<Payment_DigitalPayment> createRepeated() => $pb.PbList<Payment_DigitalPayment>();
  static Payment_DigitalPayment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment_DigitalPayment _defaultInstance;

  $22.DigitalPaymentNetwork get network => $_getN(0);
  set network($22.DigitalPaymentNetwork v) { setField(1, v); }
  $core.bool hasNetwork() => $_has(0);
  void clearNetwork() => clearField(1);

  $core.String get username => $_getS(1, '');
  set username($core.String v) { $_setString(1, v); }
  $core.bool hasUsername() => $_has(1);
  void clearUsername() => clearField(2);

  $core.String get reference => $_getS(2, '');
  set reference($core.String v) { $_setString(2, v); }
  $core.bool hasReference() => $_has(2);
  void clearReference() => clearField(3);
}

enum Payment_Spec {
  cash, 
  check_11, 
  card, 
  bank, 
  digital, 
  notSet
}

class Payment extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Payment_Spec> _Payment_SpecByTag = {
    10 : Payment_Spec.cash,
    11 : Payment_Spec.check_11,
    12 : Payment_Spec.card,
    13 : Payment_Spec.bank,
    14 : Payment_Spec.digital,
    0 : Payment_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Payment', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<PaymentKey>(1, 'key', $pb.PbFieldType.OM, PaymentKey.getDefault, PaymentKey.create)
    ..e<$22.PaymentMethod>(2, 'method', $pb.PbFieldType.OE, $22.PaymentMethod.CASH, $22.PaymentMethod.valueOf, $22.PaymentMethod.values)
    ..e<$22.PaymentStatus>(3, 'status', $pb.PbFieldType.OE, $22.PaymentStatus.NOT_APPLICABLE, $22.PaymentStatus.valueOf, $22.PaymentStatus.values)
    ..a<$core.double>(4, 'amount', $pb.PbFieldType.OD)
    ..aOB(5, 'full')
    ..a<Payment_CashPayment>(10, 'cash', $pb.PbFieldType.OM, Payment_CashPayment.getDefault, Payment_CashPayment.create)
    ..a<Payment_CheckPayment>(11, 'check_11', $pb.PbFieldType.OM, Payment_CheckPayment.getDefault, Payment_CheckPayment.create)
    ..a<Payment_CardPayment>(12, 'card', $pb.PbFieldType.OM, Payment_CardPayment.getDefault, Payment_CardPayment.create)
    ..a<Payment_BankPayment>(13, 'bank', $pb.PbFieldType.OM, Payment_BankPayment.getDefault, Payment_BankPayment.create)
    ..a<Payment_DigitalPayment>(14, 'digital', $pb.PbFieldType.OM, Payment_DigitalPayment.getDefault, Payment_DigitalPayment.create)
    ..oo(0, [10, 11, 12, 13, 14])
    ..hasRequiredFields = false
  ;

  Payment() : super();
  Payment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Payment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Payment clone() => Payment()..mergeFromMessage(this);
  Payment copyWith(void Function(Payment) updates) => super.copyWith((message) => updates(message as Payment));
  $pb.BuilderInfo get info_ => _i;
  static Payment create() => Payment();
  Payment createEmptyInstance() => create();
  static $pb.PbList<Payment> createRepeated() => $pb.PbList<Payment>();
  static Payment getDefault() => _defaultInstance ??= create()..freeze();
  static Payment _defaultInstance;

  Payment_Spec whichSpec() => _Payment_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  PaymentKey get key => $_getN(0);
  set key(PaymentKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $22.PaymentMethod get method => $_getN(1);
  set method($22.PaymentMethod v) { setField(2, v); }
  $core.bool hasMethod() => $_has(1);
  void clearMethod() => clearField(2);

  $22.PaymentStatus get status => $_getN(2);
  set status($22.PaymentStatus v) { setField(3, v); }
  $core.bool hasStatus() => $_has(2);
  void clearStatus() => clearField(3);

  $core.double get amount => $_getN(3);
  set amount($core.double v) { $_setDouble(3, v); }
  $core.bool hasAmount() => $_has(3);
  void clearAmount() => clearField(4);

  $core.bool get full => $_get(4, false);
  set full($core.bool v) { $_setBool(4, v); }
  $core.bool hasFull() => $_has(4);
  void clearFull() => clearField(5);

  Payment_CashPayment get cash => $_getN(5);
  set cash(Payment_CashPayment v) { setField(10, v); }
  $core.bool hasCash() => $_has(5);
  void clearCash() => clearField(10);

  Payment_CheckPayment get check_11 => $_getN(6);
  set check_11(Payment_CheckPayment v) { setField(11, v); }
  $core.bool hasCheck_11() => $_has(6);
  void clearCheck_11() => clearField(11);

  Payment_CardPayment get card => $_getN(7);
  set card(Payment_CardPayment v) { setField(12, v); }
  $core.bool hasCard() => $_has(7);
  void clearCard() => clearField(12);

  Payment_BankPayment get bank => $_getN(8);
  set bank(Payment_BankPayment v) { setField(13, v); }
  $core.bool hasBank() => $_has(8);
  void clearBank() => clearField(13);

  Payment_DigitalPayment get digital => $_getN(9);
  set digital(Payment_DigitalPayment v) { setField(14, v); }
  $core.bool hasDigital() => $_has(9);
  void clearDigital() => clearField(14);
}

