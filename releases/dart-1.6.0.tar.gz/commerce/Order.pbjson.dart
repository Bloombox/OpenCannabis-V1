///
//  Generated code. Do not modify.
//  source: commerce/Order.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const OrderType$json = const {
  '1': 'OrderType',
  '2': const [
    const {'1': 'PICKUP', '2': 0},
    const {'1': 'DELIVERY', '2': 1},
  ],
};

const SchedulingType$json = const {
  '1': 'SchedulingType',
  '2': const [
    const {'1': 'ASAP', '2': 0},
    const {'1': 'TIMED', '2': 1},
  ],
};

const OrderStatus$json = const {
  '1': 'OrderStatus',
  '2': const [
    const {'1': 'PENDING', '2': 0},
    const {'1': 'APPROVED', '2': 1},
    const {'1': 'REJECTED', '2': 2},
    const {'1': 'ASSIGNED', '2': 3},
    const {'1': 'EN_ROUTE', '2': 4},
    const {'1': 'FULFILLED', '2': 5},
  ],
};

const OrderScheduling$json = const {
  '1': 'OrderScheduling',
  '2': const [
    const {'1': 'scheduling', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.SchedulingType', '8': const {}, '10': 'scheduling'},
    const {'1': 'desired_time', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'desiredTime'},
  ],
};

const OrderPayment$json = const {
  '1': 'OrderPayment',
  '2': const [
    const {'1': 'status', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.PaymentStatus', '8': const {}, '10': 'status'},
    const {'1': 'method', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.commerce.PaymentMethod', '8': const {}, '10': 'method'},
    const {'1': 'tax', '3': 3, '4': 1, '5': 1, '8': const {}, '10': 'tax'},
    const {'1': 'paid', '3': 4, '4': 1, '5': 1, '8': const {}, '10': 'paid'},
  ],
};

const StatusCheckin$json = const {
  '1': 'StatusCheckin',
  '2': const [
    const {'1': 'status', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.OrderStatus', '10': 'status'},
    const {'1': 'instant', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'instant'},
    const {'1': 'message', '3': 3, '4': 1, '5': 9, '10': 'message'},
  ],
};

const OrderKey$json = const {
  '1': 'OrderKey',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'id'},
  ],
};

const Order$json = const {
  '1': 'Order',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'id'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.commerce.OrderType', '8': const {}, '10': 'type'},
    const {'1': 'status', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.commerce.OrderStatus', '8': const {}, '10': 'status'},
    const {'1': 'customer', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.commerce.Customer', '8': const {}, '10': 'customer'},
    const {'1': 'scheduling', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.commerce.OrderScheduling', '8': const {}, '10': 'scheduling'},
    const {'1': 'destination', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.commerce.DeliveryDestination', '8': const {}, '10': 'destination'},
    const {'1': 'notes', '3': 7, '4': 1, '5': 9, '8': const {}, '10': 'notes'},
    const {'1': 'item', '3': 8, '4': 3, '5': 11, '6': '.opencannabis.commerce.Item', '8': const {}, '10': 'item'},
    const {'1': 'action_log', '3': 9, '4': 3, '5': 11, '6': '.opencannabis.commerce.StatusCheckin', '8': const {}, '10': 'actionLog'},
    const {'1': 'created_at', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'createdAt'},
    const {'1': 'subtotal', '3': 11, '4': 1, '5': 1, '8': const {}, '10': 'subtotal'},
    const {'1': 'updated_at', '3': 12, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '8': const {}, '10': 'updatedAt'},
    const {'1': 'sid', '3': 13, '4': 1, '5': 9, '8': const {}, '10': 'sid'},
    const {'1': 'payment', '3': 14, '4': 1, '5': 11, '6': '.opencannabis.commerce.OrderPayment', '8': const {}, '10': 'payment'},
  ],
};

