///
//  Generated code. Do not modify.
//  source: commerce/Order.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class OrderType extends $pb.ProtobufEnum {
  static const OrderType PICKUP = OrderType._(0, 'PICKUP');
  static const OrderType DELIVERY = OrderType._(1, 'DELIVERY');

  static const $core.List<OrderType> values = <OrderType> [
    PICKUP,
    DELIVERY,
  ];

  static final $core.Map<$core.int, OrderType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static OrderType valueOf($core.int value) => _byValue[value];

  const OrderType._($core.int v, $core.String n) : super(v, n);
}

class SchedulingType extends $pb.ProtobufEnum {
  static const SchedulingType ASAP = SchedulingType._(0, 'ASAP');
  static const SchedulingType TIMED = SchedulingType._(1, 'TIMED');

  static const $core.List<SchedulingType> values = <SchedulingType> [
    ASAP,
    TIMED,
  ];

  static final $core.Map<$core.int, SchedulingType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static SchedulingType valueOf($core.int value) => _byValue[value];

  const SchedulingType._($core.int v, $core.String n) : super(v, n);
}

class OrderStatus extends $pb.ProtobufEnum {
  static const OrderStatus PENDING = OrderStatus._(0, 'PENDING');
  static const OrderStatus APPROVED = OrderStatus._(1, 'APPROVED');
  static const OrderStatus REJECTED = OrderStatus._(2, 'REJECTED');
  static const OrderStatus ASSIGNED = OrderStatus._(3, 'ASSIGNED');
  static const OrderStatus EN_ROUTE = OrderStatus._(4, 'EN_ROUTE');
  static const OrderStatus FULFILLED = OrderStatus._(5, 'FULFILLED');

  static const $core.List<OrderStatus> values = <OrderStatus> [
    PENDING,
    APPROVED,
    REJECTED,
    ASSIGNED,
    EN_ROUTE,
    FULFILLED,
  ];

  static final $core.Map<$core.int, OrderStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static OrderStatus valueOf($core.int value) => _byValue[value];

  const OrderStatus._($core.int v, $core.String n) : super(v, n);
}

