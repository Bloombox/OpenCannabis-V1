///
//  Generated code. Do not modify.
//  source: commerce/Item.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ProductVariant$json = const {
  '1': 'ProductVariant',
  '2': const [
    const {'1': 'WEIGHT', '2': 0},
    const {'1': 'COLOR', '2': 1},
    const {'1': 'SIZE', '2': 2},
  ],
};

const VariantSpec$json = const {
  '1': 'VariantSpec',
  '2': const [
    const {'1': 'variant', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.ProductVariant', '10': 'variant'},
    const {'1': 'weight', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.PricingWeightTier', '9': 0, '10': 'weight'},
    const {'1': 'size', '3': 3, '4': 1, '5': 9, '9': 0, '10': 'size'},
    const {'1': 'color', '3': 4, '4': 1, '5': 9, '9': 0, '10': 'color'},
  ],
  '8': const [
    const {'1': 'spec'},
  ],
};

const Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'variant', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.commerce.VariantSpec', '10': 'variant'},
    const {'1': 'count', '3': 3, '4': 1, '5': 13, '10': 'count'},
    const {'1': 'uri', '3': 4, '4': 1, '5': 9, '10': 'uri'},
    const {'1': 'image_uri', '3': 5, '4': 1, '5': 9, '10': 'imageUri'},
  ],
};

