///
//  Generated code. Do not modify.
//  source: commerce/Customer.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Customer$json = const {
  '1': 'Customer',
  '2': const [
    const {'1': 'person', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.person.Person', '8': const {}, '10': 'person'},
    const {'1': 'foreign_id', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'foreignId'},
    const {'1': 'user_key', '3': 3, '4': 1, '5': 9, '8': const {}, '10': 'userKey'},
  ],
};

