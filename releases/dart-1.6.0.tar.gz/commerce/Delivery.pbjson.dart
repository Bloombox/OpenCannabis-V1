///
//  Generated code. Do not modify.
//  source: commerce/Delivery.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const DeliveryDestination$json = const {
  '1': 'DeliveryDestination',
  '2': const [
    const {'1': 'address', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.geo.Address', '8': const {}, '10': 'address'},
    const {'1': 'instructions', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'instructions'},
  ],
};

