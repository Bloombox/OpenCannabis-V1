///
//  Generated code. Do not modify.
//  source: commerce/payments/Payment.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PaymentMethod extends $pb.ProtobufEnum {
  static const PaymentMethod CASH = PaymentMethod._(0, 'CASH');
  static const PaymentMethod CHECK = PaymentMethod._(1, 'CHECK');
  static const PaymentMethod DEBIT = PaymentMethod._(2, 'DEBIT');
  static const PaymentMethod CREDIT = PaymentMethod._(3, 'CREDIT');
  static const PaymentMethod DIGITAL = PaymentMethod._(4, 'DIGITAL');
  static const PaymentMethod ACH = PaymentMethod._(5, 'ACH');
  static const PaymentMethod WIRE = PaymentMethod._(6, 'WIRE');
  static const PaymentMethod BLOCKCHAIN = PaymentMethod._(7, 'BLOCKCHAIN');

  static const $core.List<PaymentMethod> values = <PaymentMethod> [
    CASH,
    CHECK,
    DEBIT,
    CREDIT,
    DIGITAL,
    ACH,
    WIRE,
    BLOCKCHAIN,
  ];

  static final $core.Map<$core.int, PaymentMethod> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PaymentMethod valueOf($core.int value) => _byValue[value];

  const PaymentMethod._($core.int v, $core.String n) : super(v, n);
}

class PaymentCardType extends $pb.ProtobufEnum {
  static const PaymentCardType NO_CARD_TYPE = PaymentCardType._(0, 'NO_CARD_TYPE');
  static const PaymentCardType VISA = PaymentCardType._(1, 'VISA');
  static const PaymentCardType MASTERCARD = PaymentCardType._(2, 'MASTERCARD');
  static const PaymentCardType DISCOVER = PaymentCardType._(3, 'DISCOVER');
  static const PaymentCardType AMEX = PaymentCardType._(4, 'AMEX');
  static const PaymentCardType DINERS_CLUB = PaymentCardType._(5, 'DINERS_CLUB');
  static const PaymentCardType MAESTRO = PaymentCardType._(6, 'MAESTRO');

  static const $core.List<PaymentCardType> values = <PaymentCardType> [
    NO_CARD_TYPE,
    VISA,
    MASTERCARD,
    DISCOVER,
    AMEX,
    DINERS_CLUB,
    MAESTRO,
  ];

  static final $core.Map<$core.int, PaymentCardType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PaymentCardType valueOf($core.int value) => _byValue[value];

  const PaymentCardType._($core.int v, $core.String n) : super(v, n);
}

class DigitalPaymentNetwork extends $pb.ProtobufEnum {
  static const DigitalPaymentNetwork UNSPECIFIED_NETWORK = DigitalPaymentNetwork._(0, 'UNSPECIFIED_NETWORK');
  static const DigitalPaymentNetwork PAYPAL = DigitalPaymentNetwork._(1, 'PAYPAL');
  static const DigitalPaymentNetwork VENMO = DigitalPaymentNetwork._(2, 'VENMO');
  static const DigitalPaymentNetwork SQUARE = DigitalPaymentNetwork._(3, 'SQUARE');

  static const $core.List<DigitalPaymentNetwork> values = <DigitalPaymentNetwork> [
    UNSPECIFIED_NETWORK,
    PAYPAL,
    VENMO,
    SQUARE,
  ];

  static final $core.Map<$core.int, DigitalPaymentNetwork> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DigitalPaymentNetwork valueOf($core.int value) => _byValue[value];

  const DigitalPaymentNetwork._($core.int v, $core.String n) : super(v, n);
}

class PaymentStatus extends $pb.ProtobufEnum {
  static const PaymentStatus NOT_APPLICABLE = PaymentStatus._(0, 'NOT_APPLICABLE');
  static const PaymentStatus WAITING = PaymentStatus._(1, 'WAITING');
  static const PaymentStatus PREAUTHORIZED = PaymentStatus._(2, 'PREAUTHORIZED');
  static const PaymentStatus BOUNCED = PaymentStatus._(3, 'BOUNCED');
  static const PaymentStatus RETRIED = PaymentStatus._(4, 'RETRIED');

  static const $core.List<PaymentStatus> values = <PaymentStatus> [
    NOT_APPLICABLE,
    WAITING,
    PREAUTHORIZED,
    BOUNCED,
    RETRIED,
  ];

  static final $core.Map<$core.int, PaymentStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PaymentStatus valueOf($core.int value) => _byValue[value];

  const PaymentStatus._($core.int v, $core.String n) : super(v, n);
}

class BillStatus extends $pb.ProtobufEnum {
  static const BillStatus SUSPENSE = BillStatus._(0, 'SUSPENSE');
  static const BillStatus PARTIAL = BillStatus._(3, 'PARTIAL');
  static const BillStatus SETTLED = BillStatus._(4, 'SETTLED');

  static const $core.List<BillStatus> values = <BillStatus> [
    SUSPENSE,
    PARTIAL,
    SETTLED,
  ];

  static final $core.Map<$core.int, BillStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static BillStatus valueOf($core.int value) => _byValue[value];

  const BillStatus._($core.int v, $core.String n) : super(v, n);
}

