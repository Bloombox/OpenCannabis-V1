///
//  Generated code. Do not modify.
//  source: commerce/Currency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const CurrencyType$json = const {
  '1': 'CurrencyType',
  '2': const [
    const {'1': 'FIAT', '2': 0},
    const {'1': 'REAL', '2': 1},
    const {'1': 'CRYPTO', '2': 2},
  ],
};

const FiatCurrency$json = const {
  '1': 'FiatCurrency',
  '2': const [
    const {'1': 'USD', '2': 0},
    const {'1': 'CAD', '2': 1},
    const {'1': 'EUR', '2': 2},
  ],
};

const CurrencyValue$json = const {
  '1': 'CurrencyValue',
  '2': const [
    const {'1': 'value', '3': 1, '4': 1, '5': 2, '10': 'value'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.commerce.CurrencyType', '10': 'type'},
    const {'1': 'fiat', '3': 10, '4': 1, '5': 14, '6': '.opencannabis.commerce.FiatCurrency', '9': 0, '10': 'fiat'},
    const {'1': 'custom', '3': 100, '4': 1, '5': 9, '9': 0, '10': 'custom'},
  ],
  '8': const [
    const {'1': 'spec'},
  ],
};

