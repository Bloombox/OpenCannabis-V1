///
//  Generated code. Do not modify.
//  source: commerce/Currency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Currency.pbenum.dart';

export 'Currency.pbenum.dart';

enum CurrencyValue_Spec {
  fiat, 
  custom, 
  notSet
}

class CurrencyValue extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, CurrencyValue_Spec> _CurrencyValue_SpecByTag = {
    10 : CurrencyValue_Spec.fiat,
    100 : CurrencyValue_Spec.custom,
    0 : CurrencyValue_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CurrencyValue', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$core.double>(1, 'value', $pb.PbFieldType.OF)
    ..e<CurrencyType>(2, 'type', $pb.PbFieldType.OE, CurrencyType.FIAT, CurrencyType.valueOf, CurrencyType.values)
    ..e<FiatCurrency>(10, 'fiat', $pb.PbFieldType.OE, FiatCurrency.USD, FiatCurrency.valueOf, FiatCurrency.values)
    ..aOS(100, 'custom')
    ..oo(0, [10, 100])
    ..hasRequiredFields = false
  ;

  CurrencyValue() : super();
  CurrencyValue.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CurrencyValue.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CurrencyValue clone() => CurrencyValue()..mergeFromMessage(this);
  CurrencyValue copyWith(void Function(CurrencyValue) updates) => super.copyWith((message) => updates(message as CurrencyValue));
  $pb.BuilderInfo get info_ => _i;
  static CurrencyValue create() => CurrencyValue();
  CurrencyValue createEmptyInstance() => create();
  static $pb.PbList<CurrencyValue> createRepeated() => $pb.PbList<CurrencyValue>();
  static CurrencyValue getDefault() => _defaultInstance ??= create()..freeze();
  static CurrencyValue _defaultInstance;

  CurrencyValue_Spec whichSpec() => _CurrencyValue_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $core.double get value => $_getN(0);
  set value($core.double v) { $_setFloat(0, v); }
  $core.bool hasValue() => $_has(0);
  void clearValue() => clearField(1);

  CurrencyType get type => $_getN(1);
  set type(CurrencyType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  FiatCurrency get fiat => $_getN(2);
  set fiat(FiatCurrency v) { setField(10, v); }
  $core.bool hasFiat() => $_has(2);
  void clearFiat() => clearField(10);

  $core.String get custom => $_getS(3, '');
  set custom($core.String v) { $_setString(3, v); }
  $core.bool hasCustom() => $_has(3);
  void clearCustom() => clearField(100);
}

