///
//  Generated code. Do not modify.
//  source: accounting/Taxes.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../geo/Province.pb.dart' as $24;
import '../geo/Country.pb.dart' as $25;

import 'Taxes.pbenum.dart';

export 'Taxes.pbenum.dart';

class LocalTax extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocalTax', package: const $pb.PackageName('opencannabis.taxes'))
    ..aOS(1, 'municipality')
    ..a<$24.Province>(2, 'province', $pb.PbFieldType.OM, $24.Province.getDefault, $24.Province.create)
    ..a<$25.Country>(3, 'country', $pb.PbFieldType.OM, $25.Country.getDefault, $25.Country.create)
    ..hasRequiredFields = false
  ;

  LocalTax() : super();
  LocalTax.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocalTax.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocalTax clone() => LocalTax()..mergeFromMessage(this);
  LocalTax copyWith(void Function(LocalTax) updates) => super.copyWith((message) => updates(message as LocalTax));
  $pb.BuilderInfo get info_ => _i;
  static LocalTax create() => LocalTax();
  LocalTax createEmptyInstance() => create();
  static $pb.PbList<LocalTax> createRepeated() => $pb.PbList<LocalTax>();
  static LocalTax getDefault() => _defaultInstance ??= create()..freeze();
  static LocalTax _defaultInstance;

  $core.String get municipality => $_getS(0, '');
  set municipality($core.String v) { $_setString(0, v); }
  $core.bool hasMunicipality() => $_has(0);
  void clearMunicipality() => clearField(1);

  $24.Province get province => $_getN(1);
  set province($24.Province v) { setField(2, v); }
  $core.bool hasProvince() => $_has(1);
  void clearProvince() => clearField(2);

  $25.Country get country => $_getN(2);
  set country($25.Country v) { setField(3, v); }
  $core.bool hasCountry() => $_has(2);
  void clearCountry() => clearField(3);
}

class ProvincialTax extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProvincialTax', package: const $pb.PackageName('opencannabis.taxes'))
    ..a<$24.Province>(1, 'province', $pb.PbFieldType.OM, $24.Province.getDefault, $24.Province.create)
    ..a<$25.Country>(2, 'country', $pb.PbFieldType.OM, $25.Country.getDefault, $25.Country.create)
    ..hasRequiredFields = false
  ;

  ProvincialTax() : super();
  ProvincialTax.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProvincialTax.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProvincialTax clone() => ProvincialTax()..mergeFromMessage(this);
  ProvincialTax copyWith(void Function(ProvincialTax) updates) => super.copyWith((message) => updates(message as ProvincialTax));
  $pb.BuilderInfo get info_ => _i;
  static ProvincialTax create() => ProvincialTax();
  ProvincialTax createEmptyInstance() => create();
  static $pb.PbList<ProvincialTax> createRepeated() => $pb.PbList<ProvincialTax>();
  static ProvincialTax getDefault() => _defaultInstance ??= create()..freeze();
  static ProvincialTax _defaultInstance;

  $24.Province get province => $_getN(0);
  set province($24.Province v) { setField(1, v); }
  $core.bool hasProvince() => $_has(0);
  void clearProvince() => clearField(1);

  $25.Country get country => $_getN(1);
  set country($25.Country v) { setField(2, v); }
  $core.bool hasCountry() => $_has(1);
  void clearCountry() => clearField(2);
}

class FederalTax extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('FederalTax', package: const $pb.PackageName('opencannabis.taxes'))
    ..a<$25.Country>(1, 'country', $pb.PbFieldType.OM, $25.Country.getDefault, $25.Country.create)
    ..hasRequiredFields = false
  ;

  FederalTax() : super();
  FederalTax.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  FederalTax.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  FederalTax clone() => FederalTax()..mergeFromMessage(this);
  FederalTax copyWith(void Function(FederalTax) updates) => super.copyWith((message) => updates(message as FederalTax));
  $pb.BuilderInfo get info_ => _i;
  static FederalTax create() => FederalTax();
  FederalTax createEmptyInstance() => create();
  static $pb.PbList<FederalTax> createRepeated() => $pb.PbList<FederalTax>();
  static FederalTax getDefault() => _defaultInstance ??= create()..freeze();
  static FederalTax _defaultInstance;

  $25.Country get country => $_getN(0);
  set country($25.Country v) { setField(1, v); }
  $core.bool hasCountry() => $_has(0);
  void clearCountry() => clearField(1);
}

enum TaxJurisdiction_Jurisdiction {
  local, 
  provincial, 
  federal, 
  notSet
}

class TaxJurisdiction extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, TaxJurisdiction_Jurisdiction> _TaxJurisdiction_JurisdictionByTag = {
    2 : TaxJurisdiction_Jurisdiction.local,
    3 : TaxJurisdiction_Jurisdiction.provincial,
    4 : TaxJurisdiction_Jurisdiction.federal,
    0 : TaxJurisdiction_Jurisdiction.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TaxJurisdiction', package: const $pb.PackageName('opencannabis.taxes'))
    ..e<TaxJurisdictionMode>(1, 'mode', $pb.PbFieldType.OE, TaxJurisdictionMode.LOCAL, TaxJurisdictionMode.valueOf, TaxJurisdictionMode.values)
    ..a<LocalTax>(2, 'local', $pb.PbFieldType.OM, LocalTax.getDefault, LocalTax.create)
    ..a<ProvincialTax>(3, 'provincial', $pb.PbFieldType.OM, ProvincialTax.getDefault, ProvincialTax.create)
    ..a<FederalTax>(4, 'federal', $pb.PbFieldType.OM, FederalTax.getDefault, FederalTax.create)
    ..oo(0, [2, 3, 4])
    ..hasRequiredFields = false
  ;

  TaxJurisdiction() : super();
  TaxJurisdiction.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TaxJurisdiction.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TaxJurisdiction clone() => TaxJurisdiction()..mergeFromMessage(this);
  TaxJurisdiction copyWith(void Function(TaxJurisdiction) updates) => super.copyWith((message) => updates(message as TaxJurisdiction));
  $pb.BuilderInfo get info_ => _i;
  static TaxJurisdiction create() => TaxJurisdiction();
  TaxJurisdiction createEmptyInstance() => create();
  static $pb.PbList<TaxJurisdiction> createRepeated() => $pb.PbList<TaxJurisdiction>();
  static TaxJurisdiction getDefault() => _defaultInstance ??= create()..freeze();
  static TaxJurisdiction _defaultInstance;

  TaxJurisdiction_Jurisdiction whichJurisdiction() => _TaxJurisdiction_JurisdictionByTag[$_whichOneof(0)];
  void clearJurisdiction() => clearField($_whichOneof(0));

  TaxJurisdictionMode get mode => $_getN(0);
  set mode(TaxJurisdictionMode v) { setField(1, v); }
  $core.bool hasMode() => $_has(0);
  void clearMode() => clearField(1);

  LocalTax get local => $_getN(1);
  set local(LocalTax v) { setField(2, v); }
  $core.bool hasLocal() => $_has(1);
  void clearLocal() => clearField(2);

  ProvincialTax get provincial => $_getN(2);
  set provincial(ProvincialTax v) { setField(3, v); }
  $core.bool hasProvincial() => $_has(2);
  void clearProvincial() => clearField(3);

  FederalTax get federal => $_getN(3);
  set federal(FederalTax v) { setField(4, v); }
  $core.bool hasFederal() => $_has(3);
  void clearFederal() => clearField(4);
}

enum TaxSpec_Rate {
  percentage, 
  staticValue, 
  notSet
}

class TaxSpec extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, TaxSpec_Rate> _TaxSpec_RateByTag = {
    4 : TaxSpec_Rate.percentage,
    5 : TaxSpec_Rate.staticValue,
    0 : TaxSpec_Rate.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TaxSpec', package: const $pb.PackageName('opencannabis.taxes'))
    ..e<TaxBasis>(1, 'basis', $pb.PbFieldType.OE, TaxBasis.ITEM, TaxBasis.valueOf, TaxBasis.values)
    ..a<TaxJurisdiction>(2, 'jurisdiction', $pb.PbFieldType.OM, TaxJurisdiction.getDefault, TaxJurisdiction.create)
    ..aOS(3, 'transactionLabel')
    ..a<$core.double>(4, 'percentage', $pb.PbFieldType.OD)
    ..a<$core.double>(5, 'staticValue', $pb.PbFieldType.OD)
    ..oo(0, [4, 5])
    ..hasRequiredFields = false
  ;

  TaxSpec() : super();
  TaxSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TaxSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TaxSpec clone() => TaxSpec()..mergeFromMessage(this);
  TaxSpec copyWith(void Function(TaxSpec) updates) => super.copyWith((message) => updates(message as TaxSpec));
  $pb.BuilderInfo get info_ => _i;
  static TaxSpec create() => TaxSpec();
  TaxSpec createEmptyInstance() => create();
  static $pb.PbList<TaxSpec> createRepeated() => $pb.PbList<TaxSpec>();
  static TaxSpec getDefault() => _defaultInstance ??= create()..freeze();
  static TaxSpec _defaultInstance;

  TaxSpec_Rate whichRate() => _TaxSpec_RateByTag[$_whichOneof(0)];
  void clearRate() => clearField($_whichOneof(0));

  TaxBasis get basis => $_getN(0);
  set basis(TaxBasis v) { setField(1, v); }
  $core.bool hasBasis() => $_has(0);
  void clearBasis() => clearField(1);

  TaxJurisdiction get jurisdiction => $_getN(1);
  set jurisdiction(TaxJurisdiction v) { setField(2, v); }
  $core.bool hasJurisdiction() => $_has(1);
  void clearJurisdiction() => clearField(2);

  $core.String get transactionLabel => $_getS(2, '');
  set transactionLabel($core.String v) { $_setString(2, v); }
  $core.bool hasTransactionLabel() => $_has(2);
  void clearTransactionLabel() => clearField(3);

  $core.double get percentage => $_getN(3);
  set percentage($core.double v) { $_setDouble(3, v); }
  $core.bool hasPercentage() => $_has(3);
  void clearPercentage() => clearField(4);

  $core.double get staticValue => $_getN(4);
  set staticValue($core.double v) { $_setDouble(4, v); }
  $core.bool hasStaticValue() => $_has(4);
  void clearStaticValue() => clearField(5);
}

class Tax extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Tax', package: const $pb.PackageName('opencannabis.taxes'))
    ..aOS(1, 'id')
    ..a<TaxSpec>(2, 'spec', $pb.PbFieldType.OM, TaxSpec.getDefault, TaxSpec.create)
    ..aOS(3, 'name')
    ..aOS(4, 'label')
    ..aOS(5, 'description')
    ..hasRequiredFields = false
  ;

  Tax() : super();
  Tax.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Tax.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Tax clone() => Tax()..mergeFromMessage(this);
  Tax copyWith(void Function(Tax) updates) => super.copyWith((message) => updates(message as Tax));
  $pb.BuilderInfo get info_ => _i;
  static Tax create() => Tax();
  Tax createEmptyInstance() => create();
  static $pb.PbList<Tax> createRepeated() => $pb.PbList<Tax>();
  static Tax getDefault() => _defaultInstance ??= create()..freeze();
  static Tax _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  TaxSpec get spec => $_getN(1);
  set spec(TaxSpec v) { setField(2, v); }
  $core.bool hasSpec() => $_has(1);
  void clearSpec() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  $core.String get label => $_getS(3, '');
  set label($core.String v) { $_setString(3, v); }
  $core.bool hasLabel() => $_has(3);
  void clearLabel() => clearField(4);

  $core.String get description => $_getS(4, '');
  set description($core.String v) { $_setString(4, v); }
  $core.bool hasDescription() => $_has(4);
  void clearDescription() => clearField(5);
}

