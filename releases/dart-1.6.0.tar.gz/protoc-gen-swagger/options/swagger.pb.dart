///
//  Generated code. Do not modify.
//  source: protoc-gen-swagger/options/swagger.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'openapiv2.pb.dart' as $66;

class Swagger {
  static final $pb.Extension openapiv2Swagger = $pb.Extension<$66.Swagger>('google.protobuf.FileOptions', 'openapiv2Swagger', 1042, $pb.PbFieldType.OM, $66.Swagger.getDefault, $66.Swagger.create);
  static final $pb.Extension openapiv2Operation = $pb.Extension<$66.Operation>('google.protobuf.MethodOptions', 'openapiv2Operation', 1042, $pb.PbFieldType.OM, $66.Operation.getDefault, $66.Operation.create);
  static final $pb.Extension openapiv2Schema = $pb.Extension<$66.Schema>('google.protobuf.MessageOptions', 'openapiv2Schema', 1042, $pb.PbFieldType.OM, $66.Schema.getDefault, $66.Schema.create);
  static final $pb.Extension openapiv2Tag = $pb.Extension<$66.Tag>('google.protobuf.ServiceOptions', 'openapiv2Tag', 1042, $pb.PbFieldType.OM, $66.Tag.getDefault, $66.Tag.create);
  static void registerAllExtensions($pb.ExtensionRegistry registry) {
    registry.add(openapiv2Swagger);
    registry.add(openapiv2Operation);
    registry.add(openapiv2Schema);
    registry.add(openapiv2Tag);
  }
}

