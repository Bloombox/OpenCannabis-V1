defmodule Opencannabis.Geo.Address do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          first_line: String.t(),
          second_line: String.t(),
          city: String.t(),
          state: String.t(),
          zipcode: String.t(),
          country: String.t()
        }
  defstruct [:first_line, :second_line, :city, :state, :zipcode, :country]

  field :first_line, 1, type: :string
  field :second_line, 2, type: :string
  field :city, 3, type: :string
  field :state, 4, type: :string
  field :zipcode, 5, type: :string
  field :country, 6, type: :string
end
