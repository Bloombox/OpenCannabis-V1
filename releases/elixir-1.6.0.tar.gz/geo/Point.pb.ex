defmodule Opencannabis.Geo.Point do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          latitude: float,
          longitude: float,
          elevation: Opencannabis.Geo.Distance.t() | nil,
          accuracy: Opencannabis.Geo.Distance.t() | nil
        }
  defstruct [:latitude, :longitude, :elevation, :accuracy]

  field :latitude, 1, type: :double
  field :longitude, 2, type: :double
  field :elevation, 3, type: Opencannabis.Geo.Distance
  field :accuracy, 4, type: Opencannabis.Geo.Distance
end
