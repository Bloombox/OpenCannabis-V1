defmodule Opencannabis.Geo.Geohash do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          component: [String.t()],
          elevation: Opencannabis.Geo.Distance.t() | nil,
          accuracy: Opencannabis.Geo.Distance.t() | nil
        }
  defstruct [:component, :elevation, :accuracy]

  field :component, 1, repeated: true, type: :string
  field :elevation, 2, type: Opencannabis.Geo.Distance
  field :accuracy, 3, type: Opencannabis.Geo.Distance
end
