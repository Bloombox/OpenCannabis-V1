defmodule Opencannabis.Media.MediaType do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          content: {atom, any},
          kind: atom | integer
        }
  defstruct [:content, :kind]

  oneof :content, 0
  field :kind, 1, type: Opencannabis.Media.MediaType.Kind, enum: true
  field :image_type, 101, type: Opencannabis.Media.MediaType.ImageKind, enum: true, oneof: 0
  field :document_type, 201, type: Opencannabis.Media.MediaType.DocumentKind, enum: true, oneof: 0
  field :video_type, 301, type: Opencannabis.Media.MediaType.VideoKind, enum: true, oneof: 0
end

defmodule Opencannabis.Media.MediaType.Kind do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :LINK, 0
  field :IMAGE, 1
  field :DOCUMENT, 2
  field :VIDEO, 3
end

defmodule Opencannabis.Media.MediaType.ImageKind do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_IMAGE_TYPE, 0
  field :PNG, 1
  field :JPG, 2
  field :GIF, 3
  field :SVG, 4
  field :WEBP, 5
end

defmodule Opencannabis.Media.MediaType.ImageDPI do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :X1, 0
  field :X2, 1
  field :X3, 2
end

defmodule Opencannabis.Media.MediaType.DocumentKind do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_DOCUMENT_TYPE, 0
  field :TXT, 1
  field :HTML, 2
  field :PDF, 3
  field :MARKDOWN, 4
end

defmodule Opencannabis.Media.MediaType.VideoKind do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_VIDEO_TYPE, 0
  field :MP4, 1
  field :FLV, 2
  field :HLS, 3
end
