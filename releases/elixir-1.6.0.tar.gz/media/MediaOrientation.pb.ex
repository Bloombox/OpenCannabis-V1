defmodule Opencannabis.Media.MediaOrientation do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UP, 0
  field :DOWN, 1
  field :LEFT, 2
  field :RIGHT, 3
  field :UP_MIRRORED, 4
  field :DOWN_MIRRORED, 5
  field :LEFT_MIRRORED, 6
  field :RIGHT_MIRRORED, 7
end
