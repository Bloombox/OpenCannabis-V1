defmodule Opencannabis.Media.MediaSubject do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          attachment: {atom, any}
        }
  defstruct [:attachment]

  oneof :attachment, 0
  field :product, 2, type: Opencannabis.Base.ProductKey, oneof: 0
  field :partner, 3, type: :string, oneof: 0
  field :location, 4, type: :string, oneof: 0
  field :global, 5, type: :bool, oneof: 0
end

defmodule Opencannabis.Media.MediaUpload do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          token: String.t(),
          operation: String.t(),
          media: Opencannabis.Media.MediaItem.t() | nil,
          mime: String.t(),
          size: non_neg_integer,
          finished: boolean,
          md5: String.t(),
          crc32: String.t(),
          owner: String.t(),
          path: String.t(),
          parent: String.t(),
          created: Opencannabis.Temporal.Instant.t() | nil,
          completed: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [
    :token,
    :operation,
    :media,
    :mime,
    :size,
    :finished,
    :md5,
    :crc32,
    :owner,
    :path,
    :parent,
    :created,
    :completed
  ]

  field :token, 1, type: :string
  field :operation, 2, type: :string
  field :media, 3, type: Opencannabis.Media.MediaItem
  field :mime, 4, type: :string
  field :size, 5, type: :uint64
  field :finished, 6, type: :bool
  field :md5, 7, type: :string
  field :crc32, 8, type: :string
  field :owner, 9, type: :string
  field :path, 10, type: :string
  field :parent, 11, type: :string
  field :created, 20, type: Opencannabis.Temporal.Instant
  field :completed, 21, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Media.MediaItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Media.MediaKey.t() | nil,
          status: atom | integer,
          type: Opencannabis.Media.MediaType.t() | nil,
          name: String.t(),
          uri: String.t(),
          serving_uri: String.t(),
          privacy: atom | integer,
          created: Opencannabis.Temporal.Instant.t() | nil,
          modified: Opencannabis.Temporal.Instant.t() | nil,
          published: Opencannabis.Temporal.Instant.t() | nil,
          scope: String.t(),
          token: String.t()
        }
  defstruct [
    :key,
    :status,
    :type,
    :name,
    :uri,
    :serving_uri,
    :privacy,
    :created,
    :modified,
    :published,
    :scope,
    :token
  ]

  field :key, 1, type: Opencannabis.Media.MediaKey
  field :status, 2, type: Opencannabis.Media.MediaStatus, enum: true
  field :type, 3, type: Opencannabis.Media.MediaType
  field :name, 4, type: :string
  field :uri, 5, type: :string
  field :serving_uri, 6, type: :string
  field :privacy, 7, type: Opencannabis.Media.MediaPrivacy, enum: true
  field :created, 8, type: Opencannabis.Temporal.Instant
  field :modified, 9, type: Opencannabis.Temporal.Instant
  field :published, 10, type: Opencannabis.Temporal.Instant
  field :scope, 11, type: :string
  field :token, 12, type: :string
end

defmodule Opencannabis.Media.MediaStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PROVISIONED, 0
  field :PENDING, 1
  field :UPLOADED, 2
  field :READY, 3
end

defmodule Opencannabis.Media.MediaPrivacy do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DEFAULT_PRIVACY, 0
  field :PARTNER, 1
  field :PUBLIC, 2
end
