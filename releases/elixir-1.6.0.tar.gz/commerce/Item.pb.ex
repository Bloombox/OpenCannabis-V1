defmodule Opencannabis.Commerce.VariantSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any},
          variant: atom | integer
        }
  defstruct [:spec, :variant]

  oneof :spec, 0
  field :variant, 1, type: Opencannabis.Commerce.ProductVariant, enum: true
  field :weight, 2, type: Opencannabis.Structs.Pricing.PricingWeightTier, enum: true, oneof: 0
  field :size, 3, type: :string, oneof: 0
  field :color, 4, type: :string, oneof: 0
end

defmodule Opencannabis.Commerce.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          variant: [Opencannabis.Commerce.VariantSpec.t()],
          count: non_neg_integer,
          uri: String.t(),
          image_uri: String.t()
        }
  defstruct [:key, :variant, :count, :uri, :image_uri]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :variant, 2, repeated: true, type: Opencannabis.Commerce.VariantSpec
  field :count, 3, type: :uint32
  field :uri, 4, type: :string
  field :image_uri, 5, type: :string
end

defmodule Opencannabis.Commerce.ProductVariant do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :WEIGHT, 0
  field :COLOR, 1
  field :SIZE, 2
end
