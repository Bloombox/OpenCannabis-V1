defmodule Opencannabis.Commerce.DiscountSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          rate: {atom, any},
          type: atom | integer,
          basis: atom | integer
        }
  defstruct [:rate, :type, :basis]

  oneof :rate, 0
  field :type, 1, type: Opencannabis.Commerce.DiscountType, enum: true
  field :basis, 2, type: Opencannabis.Commerce.DiscountBasis, enum: true
  field :percentage, 3, type: :double, oneof: 0
  field :static_value, 4, type: :double, oneof: 0
end

defmodule Opencannabis.Commerce.Discount do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          spec: Opencannabis.Commerce.DiscountSpec.t() | nil,
          name: String.t(),
          label: String.t(),
          description: String.t(),
          modified_at: Opencannabis.Temporal.Instant.t() | nil,
          created_at: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:id, :spec, :name, :label, :description, :modified_at, :created_at]

  field :id, 1, type: :string
  field :spec, 2, type: Opencannabis.Commerce.DiscountSpec
  field :name, 3, type: :string
  field :label, 4, type: :string
  field :description, 5, type: :string
  field :modified_at, 7, type: Opencannabis.Temporal.Instant
  field :created_at, 6, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Commerce.DiscountType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :STATUTORY, 1
  field :COMMERCIAL, 2
end

defmodule Opencannabis.Commerce.DiscountBasis do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ITEM, 0
  field :ORDER_SUBTOTAL, 1
  field :ORDER_TOTAL, 2
end
