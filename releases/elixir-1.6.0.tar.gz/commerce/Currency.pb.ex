defmodule Opencannabis.Commerce.CurrencyValue do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any},
          value: float,
          type: atom | integer
        }
  defstruct [:spec, :value, :type]

  oneof :spec, 0
  field :value, 1, type: :float
  field :type, 2, type: Opencannabis.Commerce.CurrencyType, enum: true
  field :fiat, 10, type: Opencannabis.Commerce.FiatCurrency, enum: true, oneof: 0
  field :custom, 100, type: :string, oneof: 0
end

defmodule Opencannabis.Commerce.CurrencyType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :FIAT, 0
  field :REAL, 1
  field :CRYPTO, 2
end

defmodule Opencannabis.Commerce.FiatCurrency do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :USD, 0
  field :CAD, 1
  field :EUR, 2
end
