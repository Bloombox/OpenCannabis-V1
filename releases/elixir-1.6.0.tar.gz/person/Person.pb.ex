defmodule Opencannabis.Person.Person do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Person.Name.t() | nil,
          legal_name: Opencannabis.Person.Name.t() | nil,
          alternate_name: Opencannabis.Person.Name.t() | nil,
          contact: Opencannabis.Contact.ContactInfo.t() | nil,
          date_of_birth: Opencannabis.Temporal.Date.t() | nil,
          gender: atom | integer
        }
  defstruct [:name, :legal_name, :alternate_name, :contact, :date_of_birth, :gender]

  field :name, 1, type: Opencannabis.Person.Name
  field :legal_name, 2, type: Opencannabis.Person.Name
  field :alternate_name, 3, type: Opencannabis.Person.Name
  field :contact, 4, type: Opencannabis.Contact.ContactInfo
  field :date_of_birth, 5, type: Opencannabis.Temporal.Date
  field :gender, 6, type: Opencannabis.Person.Gender, enum: true
end

defmodule Opencannabis.Person.Gender do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED, 0
  field :MALE, 1
  field :FEMALE, 2
  field :OTHER, 3
end
