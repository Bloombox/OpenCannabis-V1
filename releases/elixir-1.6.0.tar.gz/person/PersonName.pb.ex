defmodule Opencannabis.Person.Name do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          full_name: String.t(),
          first_name: String.t(),
          last_name: String.t(),
          middle_name: String.t(),
          prefix: String.t(),
          postfix: String.t()
        }
  defstruct [:full_name, :first_name, :last_name, :middle_name, :prefix, :postfix]

  field :full_name, 1, type: :string
  field :first_name, 2, type: :string
  field :last_name, 3, type: :string
  field :middle_name, 4, type: :string
  field :prefix, 5, type: :string
  field :postfix, 6, type: :string
end
