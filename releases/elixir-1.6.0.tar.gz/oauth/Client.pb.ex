defmodule Opencannabis.Oauth.Client do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          secret: String.t(),
          name: String.t(),
          contact: [String.t()],
          grant_types: [atom | integer],
          branding: Opencannabis.Media.MediaItem.t() | nil,
          owner: String.t(),
          policy: Opencannabis.Media.MediaItem.t() | nil,
          terms: Opencannabis.Media.MediaItem.t() | nil,
          public: boolean,
          redirect_uri: [String.t()],
          response_type: [atom | integer],
          scope: [Opencannabis.Oauth.AuthorizationScope.t()]
        }
  defstruct [
    :id,
    :secret,
    :name,
    :contact,
    :grant_types,
    :branding,
    :owner,
    :policy,
    :terms,
    :public,
    :redirect_uri,
    :response_type,
    :scope
  ]

  field :id, 1, type: :string
  field :secret, 2, type: :string
  field :name, 3, type: :string
  field :contact, 4, repeated: true, type: :string
  field :grant_types, 5, repeated: true, type: Opencannabis.Oauth.GrantType, enum: true
  field :branding, 6, type: Opencannabis.Media.MediaItem
  field :owner, 7, type: :string
  field :policy, 8, type: Opencannabis.Media.MediaItem
  field :terms, 9, type: Opencannabis.Media.MediaItem
  field :public, 10, type: :bool
  field :redirect_uri, 11, repeated: true, type: :string
  field :response_type, 12, repeated: true, type: Opencannabis.Oauth.ResponseType, enum: true
  field :scope, 13, repeated: true, type: Opencannabis.Oauth.AuthorizationScope
end

defmodule Opencannabis.Oauth.Consent do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          client_id: String.t(),
          expires_at: Opencannabis.Temporal.Instant.t() | nil,
          redirect_uri: String.t(),
          requested_scope: [String.t()]
        }
  defstruct [:id, :client_id, :expires_at, :redirect_uri, :requested_scope]

  field :id, 1, type: :string
  field :client_id, 2, type: :string
  field :expires_at, 3, type: Opencannabis.Temporal.Instant
  field :redirect_uri, 4, type: :string
  field :requested_scope, 5, repeated: true, type: :string
end

defmodule Opencannabis.Oauth.ConsentTicket do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          client: Opencannabis.Oauth.Client.t() | nil,
          consent: Opencannabis.Oauth.Consent.t() | nil
        }
  defstruct [:client, :consent]

  field :client, 1, type: Opencannabis.Oauth.Client
  field :consent, 2, type: Opencannabis.Oauth.Consent
end

defmodule Opencannabis.Oauth.ResponseType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_RESPONSE_TYPE, 0
  field :TOKEN, 1
  field :CODE, 2
  field :ID_TOKEN, 3
end

defmodule Opencannabis.Oauth.GrantType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_GRANT_TYPE, 0
  field :AUTHORIZATION_CODE, 1
  field :REFRESH_TOKEN, 2
  field :CLIENT_CREDENTIALS, 3
end
