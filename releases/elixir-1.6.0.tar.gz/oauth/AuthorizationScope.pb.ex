defmodule Opencannabis.Oauth.AuthorizationScope do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          label: String.t(),
          uri: String.t(),
          icon: String.t()
        }
  defstruct [:id, :label, :uri, :icon]

  field :id, 1, type: :string
  field :label, 2, type: :string
  field :uri, 3, type: :string
  field :icon, 4, type: :string
end
