defmodule Opencannabis.Device.Device do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uuid: String.t(),
          type: atom | integer,
          flags: Opencannabis.Device.DeviceFlags.t() | nil,
          key: Opencannabis.Device.DeviceCredentials.t() | nil
        }
  defstruct [:uuid, :type, :flags, :key]

  field :uuid, 1, type: :string
  field :type, 2, type: Opencannabis.Device.DeviceType, enum: true
  field :flags, 3, type: Opencannabis.Device.DeviceFlags
  field :key, 4, type: Opencannabis.Device.DeviceCredentials
end

defmodule Opencannabis.Device.DeviceFlags do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          ephemeral: boolean,
          managed: boolean
        }
  defstruct [:ephemeral, :managed]

  field :ephemeral, 1, type: :bool
  field :managed, 2, type: :bool
end

defmodule Opencannabis.Device.DeviceCredentials do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          public_key: binary,
          private_key: binary,
          sha256: String.t(),
          identity: String.t(),
          authorities: [binary]
        }
  defstruct [:public_key, :private_key, :sha256, :identity, :authorities]

  field :public_key, 1, type: :bytes
  field :private_key, 2, type: :bytes
  field :sha256, 3, type: :string
  field :identity, 4, type: :string
  field :authorities, 5, repeated: true, type: :bytes
end

defmodule Opencannabis.Device.DeviceType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN_DEVICE_TYPE, 0
  field :DESKTOP, 1
  field :PHONE, 2
  field :TABLET, 3
  field :TV, 4
  field :EMBEDDED, 5
  field :SERVER, 6
end
