defmodule Opencannabis.Crypto.Hash do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          digest: {atom, any},
          algorithm: atom | integer
        }
  defstruct [:digest, :algorithm]

  oneof :digest, 0
  field :algorithm, 1, type: Opencannabis.Crypto.HashAlgorithm, enum: true
  field :raw, 2, type: :bytes, oneof: 0
  field :hex, 3, type: :string, oneof: 0
  field :b64, 4, type: :string, oneof: 0
end

defmodule Opencannabis.Crypto.HashedData do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          data: binary,
          hash: Opencannabis.Crypto.Hash.t() | nil
        }
  defstruct [:data, :hash]

  field :data, 1, type: :bytes
  field :hash, 2, type: Opencannabis.Crypto.Hash
end

defmodule Opencannabis.Crypto.HashAlgorithm do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :SHA1, 0
  field :MD5, 1
  field :SHA256, 2
  field :SHA384, 3
  field :SHA512, 4
  field :MURMUR, 6
end
