defmodule Grpc.Gateway.ProtocGenSwagger.Options.Swagger do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          swagger: String.t(),
          info: Grpc.Gateway.ProtocGenSwagger.Options.Info.t() | nil,
          host: String.t(),
          base_path: String.t(),
          schemes: [atom | integer],
          consumes: [String.t()],
          produces: [String.t()],
          security_definitions:
            Grpc.Gateway.ProtocGenSwagger.Options.SecurityDefinitions.t() | nil,
          security: [Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.t()],
          external_docs: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation.t() | nil
        }
  defstruct [
    :swagger,
    :info,
    :host,
    :base_path,
    :schemes,
    :consumes,
    :produces,
    :security_definitions,
    :security,
    :external_docs
  ]

  field :swagger, 1, type: :string
  field :info, 2, type: Grpc.Gateway.ProtocGenSwagger.Options.Info
  field :host, 3, type: :string
  field :base_path, 4, type: :string

  field :schemes, 5,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.Swagger.SwaggerScheme,
    enum: true

  field :consumes, 6, repeated: true, type: :string
  field :produces, 7, repeated: true, type: :string
  field :security_definitions, 11, type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityDefinitions

  field :security, 12,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement

  field :external_docs, 14, type: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Swagger.SwaggerScheme do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN, 0
  field :HTTP, 1
  field :HTTPS, 2
  field :WS, 3
  field :WSS, 4
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Operation do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          tags: [String.t()],
          summary: String.t(),
          description: String.t(),
          external_docs: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation.t() | nil,
          operation_id: String.t(),
          consumes: [String.t()],
          produces: [String.t()],
          schemes: [String.t()],
          deprecated: boolean,
          security: [Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.t()]
        }
  defstruct [
    :tags,
    :summary,
    :description,
    :external_docs,
    :operation_id,
    :consumes,
    :produces,
    :schemes,
    :deprecated,
    :security
  ]

  field :tags, 1, repeated: true, type: :string
  field :summary, 2, type: :string
  field :description, 3, type: :string
  field :external_docs, 4, type: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation
  field :operation_id, 5, type: :string
  field :consumes, 6, repeated: true, type: :string
  field :produces, 7, repeated: true, type: :string
  field :schemes, 10, repeated: true, type: :string
  field :deprecated, 11, type: :bool

  field :security, 12,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Info do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          title: String.t(),
          description: String.t(),
          terms_of_service: String.t(),
          contact: Grpc.Gateway.ProtocGenSwagger.Options.Contact.t() | nil,
          version: String.t()
        }
  defstruct [:title, :description, :terms_of_service, :contact, :version]

  field :title, 1, type: :string
  field :description, 2, type: :string
  field :terms_of_service, 3, type: :string
  field :contact, 4, type: Grpc.Gateway.ProtocGenSwagger.Options.Contact
  field :version, 6, type: :string
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Contact do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: String.t(),
          url: String.t(),
          email: String.t()
        }
  defstruct [:name, :url, :email]

  field :name, 1, type: :string
  field :url, 2, type: :string
  field :email, 3, type: :string
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          description: String.t(),
          url: String.t()
        }
  defstruct [:description, :url]

  field :description, 1, type: :string
  field :url, 2, type: :string
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Schema do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          json_schema: Grpc.Gateway.ProtocGenSwagger.Options.JSONSchema.t() | nil,
          discriminator: String.t(),
          read_only: boolean,
          external_docs: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation.t() | nil,
          example: Google.Protobuf.Any.t() | nil
        }
  defstruct [:json_schema, :discriminator, :read_only, :external_docs, :example]

  field :json_schema, 1, type: Grpc.Gateway.ProtocGenSwagger.Options.JSONSchema
  field :discriminator, 2, type: :string
  field :read_only, 3, type: :bool
  field :external_docs, 5, type: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation
  field :example, 6, type: Google.Protobuf.Any
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.JSONSchema do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          title: String.t(),
          description: String.t(),
          default: String.t(),
          multiple_of: float,
          maximum: float,
          exclusive_maximum: boolean,
          minimum: float,
          exclusive_minimum: boolean,
          max_length: non_neg_integer,
          min_length: non_neg_integer,
          pattern: String.t(),
          max_items: non_neg_integer,
          min_items: non_neg_integer,
          unique_items: boolean,
          max_properties: non_neg_integer,
          min_properties: non_neg_integer,
          required: [String.t()],
          array: [String.t()],
          type: [atom | integer]
        }
  defstruct [
    :title,
    :description,
    :default,
    :multiple_of,
    :maximum,
    :exclusive_maximum,
    :minimum,
    :exclusive_minimum,
    :max_length,
    :min_length,
    :pattern,
    :max_items,
    :min_items,
    :unique_items,
    :max_properties,
    :min_properties,
    :required,
    :array,
    :type
  ]

  field :title, 5, type: :string
  field :description, 6, type: :string
  field :default, 7, type: :string
  field :multiple_of, 10, type: :double
  field :maximum, 11, type: :double
  field :exclusive_maximum, 12, type: :bool
  field :minimum, 13, type: :double
  field :exclusive_minimum, 14, type: :bool
  field :max_length, 15, type: :uint64
  field :min_length, 16, type: :uint64
  field :pattern, 17, type: :string
  field :max_items, 20, type: :uint64
  field :min_items, 21, type: :uint64
  field :unique_items, 22, type: :bool
  field :max_properties, 24, type: :uint64
  field :min_properties, 25, type: :uint64
  field :required, 26, repeated: true, type: :string
  field :array, 34, repeated: true, type: :string

  field :type, 35,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.JSONSchema.JSONSchemaSimpleTypes,
    enum: true
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.JSONSchema.JSONSchemaSimpleTypes do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN, 0
  field :ARRAY, 1
  field :BOOLEAN, 2
  field :INTEGER, 3
  field :NULL, 4
  field :NUMBER, 5
  field :OBJECT, 6
  field :STRING, 7
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Tag do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          description: String.t(),
          external_docs: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation.t() | nil
        }
  defstruct [:description, :external_docs]

  field :description, 2, type: :string
  field :external_docs, 3, type: Grpc.Gateway.ProtocGenSwagger.Options.ExternalDocumentation
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityDefinitions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          security: %{
            String.t() => Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.t() | nil
          }
        }
  defstruct [:security]

  field :security, 1,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityDefinitions.SecurityEntry,
    map: true
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityDefinitions.SecurityEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          description: String.t(),
          name: String.t(),
          in: atom | integer,
          flow: atom | integer,
          authorization_url: String.t(),
          token_url: String.t(),
          scopes: Grpc.Gateway.ProtocGenSwagger.Options.Scopes.t() | nil
        }
  defstruct [:type, :description, :name, :in, :flow, :authorization_url, :token_url, :scopes]

  field :type, 1, type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.Type, enum: true
  field :description, 2, type: :string
  field :name, 3, type: :string
  field :in, 4, type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.In, enum: true
  field :flow, 5, type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.Flow, enum: true
  field :authorization_url, 6, type: :string
  field :token_url, 7, type: :string
  field :scopes, 8, type: Grpc.Gateway.ProtocGenSwagger.Options.Scopes
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :TYPE_INVALID, 0
  field :TYPE_BASIC, 1
  field :TYPE_API_KEY, 2
  field :TYPE_OAUTH2, 3
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.In do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :IN_INVALID, 0
  field :IN_QUERY, 1
  field :IN_HEADER, 2
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityScheme.Flow do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :FLOW_INVALID, 0
  field :FLOW_IMPLICIT, 1
  field :FLOW_PASSWORD, 2
  field :FLOW_APPLICATION, 3
  field :FLOW_ACCESS_CODE, 4
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          security_requirement: %{
            String.t() =>
              Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementValue.t()
              | nil
          }
        }
  defstruct [:security_requirement]

  field :security_requirement, 1,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementEntry,
    map: true
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementValue do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          scope: [String.t()]
        }
  defstruct [:scope]

  field :scope, 1, repeated: true, type: :string
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value:
            Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementValue.t()
            | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string

  field :value, 2,
    type: Grpc.Gateway.ProtocGenSwagger.Options.SecurityRequirement.SecurityRequirementValue
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Scopes do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          scope: %{String.t() => String.t()}
        }
  defstruct [:scope]

  field :scope, 1,
    repeated: true,
    type: Grpc.Gateway.ProtocGenSwagger.Options.Scopes.ScopeEntry,
    map: true
end

defmodule Grpc.Gateway.ProtocGenSwagger.Options.Scopes.ScopeEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: String.t()
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: :string
end
