defmodule Opencannabis.Contact.EmailAddress do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          address: String.t(),
          validated: boolean,
          name: String.t()
        }
  defstruct [:address, :validated, :name]

  field :address, 1, type: :string
  field :validated, 2, type: :bool
  field :name, 3, type: :string
end
