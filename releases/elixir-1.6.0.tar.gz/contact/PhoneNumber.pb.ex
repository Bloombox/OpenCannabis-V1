defmodule Opencannabis.Contact.PhoneNumber do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          e164: String.t(),
          validated: boolean,
          display: String.t()
        }
  defstruct [:e164, :validated, :display]

  field :e164, 1, type: :string
  field :validated, 2, type: :bool
  field :display, 3, type: :string
end
