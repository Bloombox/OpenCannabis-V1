defmodule Opencannabis.Contact.ContactInfo do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          location: Opencannabis.Geo.Location.t() | nil,
          phone: Opencannabis.Contact.PhoneNumber.t() | nil,
          email: Opencannabis.Contact.EmailAddress.t() | nil,
          website: Opencannabis.Contact.Website.t() | nil
        }
  defstruct [:location, :phone, :email, :website]

  field :location, 1, type: Opencannabis.Geo.Location
  field :phone, 2, type: Opencannabis.Contact.PhoneNumber
  field :email, 3, type: Opencannabis.Contact.EmailAddress
  field :website, 4, type: Opencannabis.Contact.Website
end

defmodule Opencannabis.Contact.SocialInfo do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          profile: [Opencannabis.Contact.SocialInfo.SocialProfile.t()]
        }
  defstruct [:profile]

  field :profile, 1, repeated: true, type: Opencannabis.Contact.SocialInfo.SocialProfile
end

defmodule Opencannabis.Contact.SocialInfo.SocialProfile do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          provider: {atom, any},
          username: String.t(),
          url: Opencannabis.Contact.Website.t() | nil
        }
  defstruct [:provider, :username, :url]

  oneof :provider, 0
  field :known, 10, type: Opencannabis.Contact.SocialInfo.SocialProvider, enum: true, oneof: 0
  field :custom, 11, type: :string, oneof: 0
  field :username, 1, type: :string
  field :url, 2, type: Opencannabis.Contact.Website
end

defmodule Opencannabis.Contact.SocialInfo.SocialProvider do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_SOCIAL_PROVIDER, 0
  field :FACEBOOK, 1
  field :TWITTER, 2
  field :INSTAGRAM, 3
  field :YOUTUBE, 4
  field :LEAFLY, 5
  field :WEEDMAPS, 6
end
