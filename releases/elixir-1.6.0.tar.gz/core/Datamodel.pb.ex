defmodule Core.DatapointOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          visibility: atom | integer,
          required: boolean
        }
  defstruct [:visibility, :required]

  field :visibility, 1, type: Core.Visibility, enum: true
  field :required, 2, type: :bool
end

defmodule Core.PersistenceOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          mode: atom | integer,
          path: String.t()
        }
  defstruct [:mode, :path]

  field :mode, 1, type: Core.CollectionMode, enum: true
  field :path, 2, type: :string
end

defmodule Core.TableOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: String.t(),
          description: String.t()
        }
  defstruct [:name, :description]

  field :name, 1, type: :string
  field :description, 2, type: :string
end

defmodule Core.SubmessageOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          mode: atom | integer,
          path: String.t()
        }
  defstruct [:mode, :path]

  field :mode, 1, type: Core.CollectionMode, enum: true
  field :path, 3, type: :string
end

defmodule Core.FieldPersistenceOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          description: String.t()
        }
  defstruct [:type, :description]

  field :type, 1, type: Core.FieldType, enum: true
  field :description, 2, type: :string
end

defmodule Core.TableFieldOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          require: boolean,
          ignore: boolean,
          bqtype: String.t()
        }
  defstruct [:require, :ignore, :bqtype]

  field :require, 1, type: :bool
  field :ignore, 2, type: :bool
  field :bqtype, 3, type: :string
end

defmodule Core.ObjectMapping do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          instance: [String.t()]
        }
  defstruct [:instance]

  field :instance, 1, repeated: true, type: :string
end

defmodule Core.Visibility do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PUBLIC, 0
  field :PRIVATE, 1
  field :PROTECTED, 2
  field :PACKAGE, 3
  field :EXPORT, 4
end

defmodule Core.CollectionMode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NESTED, 0
  field :COLLECTION, 1
  field :GROUP, 2
end

defmodule Core.FieldType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STANDARD, 0
  field :KEY, 1
  field :ID, 2
  field :TAGS, 3
  field :FLAGS, 4
end
