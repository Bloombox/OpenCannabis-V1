defmodule Opencannabis.Structs.Grow do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :GENERIC, 0
  field :INDOOR, 1
  field :GREENHOUSE, 2
  field :OUTDOOR, 3
end
