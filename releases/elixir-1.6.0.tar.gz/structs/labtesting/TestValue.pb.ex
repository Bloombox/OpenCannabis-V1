defmodule Opencannabis.Structs.Labtesting.TestValue do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          value: {atom, any},
          type: atom | integer,
          error: Opencannabis.Structs.Labtesting.TestValue.TestError.t() | nil
        }
  defstruct [:value, :type, :error]

  oneof :value, 0
  field :type, 1, type: Opencannabis.Structs.Labtesting.TestValueType, enum: true
  field :error, 2, type: Opencannabis.Structs.Labtesting.TestValue.TestError
  field :measurement, 10, type: :double, oneof: 0
  field :present, 20, type: :bool, oneof: 0
end

defmodule Opencannabis.Structs.Labtesting.TestValue.TestError do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          value: float
        }
  defstruct [:type, :value]

  field :type, 1, type: Opencannabis.Structs.Labtesting.TestErrorType, enum: true
  field :value, 2, type: :double
end

defmodule Opencannabis.Structs.Labtesting.TestMedia do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          media_item: Opencannabis.Media.MediaItem.t() | nil
        }
  defstruct [:type, :media_item]

  field :type, 1, type: Opencannabis.Structs.Labtesting.TestMediaType, enum: true
  field :media_item, 2, type: Opencannabis.Media.MediaItem
end

defmodule Opencannabis.Structs.Labtesting.TestValueType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :MILLIGRAMS, 0
  field :PERCENTAGE, 1
  field :PRESENCE, 2
end

defmodule Opencannabis.Structs.Labtesting.TestErrorType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PERCENT, 0
  field :ABSOLUTE, 1
  field :RELATIVE, 2
end

defmodule Opencannabis.Structs.Labtesting.TestMediaType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CERTIFICATE, 0
  field :RESULTS, 1
  field :PRODUCT_IMAGE, 2
end
