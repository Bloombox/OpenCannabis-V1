defmodule Opencannabis.Structs.Species do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED, 0
  field :SATIVA, 1
  field :HYBRID_SATIVA, 2
  field :HYBRID, 3
  field :HYBRID_INDICA, 4
  field :INDICA, 5
end
