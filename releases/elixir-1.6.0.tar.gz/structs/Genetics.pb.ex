defmodule Opencannabis.Structs.Genetics do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          male: Opencannabis.Base.ProductReference.t() | nil,
          female: Opencannabis.Base.ProductReference.t() | nil
        }
  defstruct [:male, :female]

  field :male, 1, type: Opencannabis.Base.ProductReference
  field :female, 2, type: Opencannabis.Base.ProductReference
end
