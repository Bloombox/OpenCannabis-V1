defmodule Opencannabis.Structs.ProductFlag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :VISIBLE, 0
  field :HIDDEN, 1
  field :PREMIUM, 2
  field :FEATURED, 3
  field :EXCLUSIVE, 4
  field :IN_HOUSE, 5
  field :LAST_CHANCE, 6
  field :LIMITED_TIME, 7
  field :LOCAL, 8
  field :ON_SALE, 20
end
