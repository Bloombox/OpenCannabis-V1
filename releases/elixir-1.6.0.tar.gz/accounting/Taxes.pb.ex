defmodule Opencannabis.Taxes.LocalTax do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          municipality: String.t(),
          province: Opencannabis.Geo.Province.t() | nil,
          country: Opencannabis.Geo.Country.t() | nil
        }
  defstruct [:municipality, :province, :country]

  field :municipality, 1, type: :string
  field :province, 2, type: Opencannabis.Geo.Province
  field :country, 3, type: Opencannabis.Geo.Country
end

defmodule Opencannabis.Taxes.ProvincialTax do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          province: Opencannabis.Geo.Province.t() | nil,
          country: Opencannabis.Geo.Country.t() | nil
        }
  defstruct [:province, :country]

  field :province, 1, type: Opencannabis.Geo.Province
  field :country, 2, type: Opencannabis.Geo.Country
end

defmodule Opencannabis.Taxes.FederalTax do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          country: Opencannabis.Geo.Country.t() | nil
        }
  defstruct [:country]

  field :country, 1, type: Opencannabis.Geo.Country
end

defmodule Opencannabis.Taxes.TaxJurisdiction do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          jurisdiction: {atom, any},
          mode: atom | integer
        }
  defstruct [:jurisdiction, :mode]

  oneof :jurisdiction, 0
  field :mode, 1, type: Opencannabis.Taxes.TaxJurisdictionMode, enum: true
  field :local, 2, type: Opencannabis.Taxes.LocalTax, oneof: 0
  field :provincial, 3, type: Opencannabis.Taxes.ProvincialTax, oneof: 0
  field :federal, 4, type: Opencannabis.Taxes.FederalTax, oneof: 0
end

defmodule Opencannabis.Taxes.TaxSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          rate: {atom, any},
          basis: atom | integer,
          jurisdiction: Opencannabis.Taxes.TaxJurisdiction.t() | nil,
          transaction_label: String.t()
        }
  defstruct [:rate, :basis, :jurisdiction, :transaction_label]

  oneof :rate, 0
  field :basis, 1, type: Opencannabis.Taxes.TaxBasis, enum: true
  field :jurisdiction, 2, type: Opencannabis.Taxes.TaxJurisdiction
  field :transaction_label, 3, type: :string
  field :percentage, 4, type: :double, oneof: 0
  field :static_value, 5, type: :double, oneof: 0
end

defmodule Opencannabis.Taxes.Tax do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          spec: Opencannabis.Taxes.TaxSpec.t() | nil,
          name: String.t(),
          label: String.t(),
          description: String.t()
        }
  defstruct [:id, :spec, :name, :label, :description]

  field :id, 1, type: :string
  field :spec, 2, type: Opencannabis.Taxes.TaxSpec
  field :name, 3, type: :string
  field :label, 4, type: :string
  field :description, 5, type: :string
end

defmodule Opencannabis.Taxes.TaxJurisdictionMode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :LOCAL, 0
  field :PROVINCE, 1
  field :FEDERAL, 2
end

defmodule Opencannabis.Taxes.TaxBasis do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ITEM, 0
  field :ORDER_SUBTOTAL, 1
  field :ORDER_TOTAL, 2
end
