defmodule Opencannabis.Temporal.Time do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any}
        }
  defstruct [:spec]

  oneof :spec, 0
  field :iso8601, 1, type: :string, oneof: 0
end
