defmodule Opencannabis.Temporal.TimeInterval do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          interval: atom | integer,
          every: non_neg_integer
        }
  defstruct [:interval, :every]

  field :interval, 1, type: Opencannabis.Temporal.Interval, enum: true
  field :every, 2, type: :uint32
end

defmodule Opencannabis.Temporal.Interval do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :MINUTELY, 0
  field :HOURLY, 1
  field :DAILY, 2
  field :WEEKLY, 3
  field :MONTHLY, 4
end
