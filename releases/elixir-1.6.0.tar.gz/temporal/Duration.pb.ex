defmodule Opencannabis.Temporal.Duration do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          unit: atom | integer,
          amount: non_neg_integer
        }
  defstruct [:unit, :amount]

  field :unit, 1, type: Opencannabis.Temporal.TimeUnit, enum: true
  field :amount, 2, type: :uint32
end

defmodule Opencannabis.Temporal.TimeUnit do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :MILLISECONDS, 0
  field :MICROSECONDS, 1
  field :SECONDS, 2
  field :MINUTES, 3
  field :HOURS, 4
  field :DAYS, 5
  field :WEEKS, 6
  field :MONTHS, 7
  field :YEARS, 8
end
