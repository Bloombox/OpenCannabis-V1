defmodule Opencannabis.Base.Compression do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          enabled: boolean,
          type: atom | integer
        }
  defstruct [:enabled, :type]

  field :enabled, 1, type: :bool
  field :type, 2, type: Opencannabis.Base.Compression.Type, enum: true
end

defmodule Opencannabis.Base.Compression.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_COMPRESSION, 0
  field :GZIP, 1
  field :BROTLI, 2
  field :SNAPPY, 3
end
