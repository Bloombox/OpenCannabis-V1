defmodule Opencannabis.Base.ProductKind do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :FLOWERS, 0
  field :EDIBLES, 1
  field :EXTRACTS, 2
  field :PREROLLS, 3
  field :APOTHECARY, 4
  field :CARTRIDGES, 5
  field :PLANTS, 6
  field :MERCHANDISE, 7
end
