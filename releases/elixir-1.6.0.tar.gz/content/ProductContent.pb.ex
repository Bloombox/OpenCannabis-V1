defmodule Opencannabis.Content.ProductTimestamps do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          created: Opencannabis.Temporal.Instant.t() | nil,
          modified: Opencannabis.Temporal.Instant.t() | nil,
          published: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:created, :modified, :published]

  field :created, 1, type: Opencannabis.Temporal.Instant
  field :modified, 2, type: Opencannabis.Temporal.Instant
  field :published, 3, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Content.ProductContent do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Content.Name.t() | nil,
          brand: Opencannabis.Content.Brand.t() | nil,
          summary: Opencannabis.Content.Content.t() | nil,
          usage: Opencannabis.Content.Content.t() | nil,
          dosage: Opencannabis.Content.Content.t() | nil,
          media: [Opencannabis.Media.MediaReference.t()],
          pricing: Opencannabis.Structs.Pricing.ProductPricing.t() | nil,
          tests: Opencannabis.Structs.Labtesting.TestResults.t() | nil,
          flags: [atom | integer],
          ts: Opencannabis.Content.ProductTimestamps.t() | nil
        }
  defstruct [:name, :brand, :summary, :usage, :dosage, :media, :pricing, :tests, :flags, :ts]

  field :name, 1, type: Opencannabis.Content.Name
  field :brand, 2, type: Opencannabis.Content.Brand
  field :summary, 3, type: Opencannabis.Content.Content
  field :usage, 4, type: Opencannabis.Content.Content
  field :dosage, 5, type: Opencannabis.Content.Content
  field :media, 6, repeated: true, type: Opencannabis.Media.MediaReference
  field :pricing, 7, type: Opencannabis.Structs.Pricing.ProductPricing
  field :tests, 8, type: Opencannabis.Structs.Labtesting.TestResults
  field :flags, 9, repeated: true, type: Opencannabis.Structs.ProductFlag, enum: true
  field :ts, 10, type: Opencannabis.Content.ProductTimestamps
end
