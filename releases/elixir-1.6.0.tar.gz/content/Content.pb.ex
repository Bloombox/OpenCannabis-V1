defmodule Opencannabis.Content.Content do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          payload: {atom, any},
          type: atom | integer,
          encoding: atom | integer,
          language: atom | integer,
          compression: Opencannabis.Base.Compression.t() | nil
        }
  defstruct [:payload, :type, :encoding, :language, :compression]

  oneof :payload, 0
  field :type, 1, type: Opencannabis.Content.Content.Type, enum: true
  field :encoding, 2, type: Opencannabis.Content.Encoding, enum: true
  field :language, 3, type: Opencannabis.Base.Language, enum: true
  field :compression, 4, type: Opencannabis.Base.Compression
  field :content, 10, type: :string, oneof: 0
  field :raw, 20, type: :bytes, oneof: 0
end

defmodule Opencannabis.Content.Content.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :TEXT, 0
  field :MARKDOWN, 1
  field :HTML, 2
  field :BINARY, 3
end

defmodule Opencannabis.Content.Encoding do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UTF8, 0
  field :B64, 1
  field :B64_ASCII, 2
end
