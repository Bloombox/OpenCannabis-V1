defmodule Opencannabis.Content.Name do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          primary: String.t(),
          display: String.t()
        }
  defstruct [:primary, :display]

  field :primary, 1, type: :string
  field :display, 2, type: :string
end
