defmodule Opencannabis.Proximity.BluetoothBeacon do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uuid: String.t(),
          major: non_neg_integer,
          minor: non_neg_integer,
          seen: Opencannabis.Temporal.Instant.t() | nil,
          location: Opencannabis.Geo.Location.t() | nil,
          accuracy: Opencannabis.Geo.LocationAccuracy.t() | nil
        }
  defstruct [:uuid, :major, :minor, :seen, :location, :accuracy]

  field :uuid, 1, type: :string
  field :major, 2, type: :uint32
  field :minor, 3, type: :uint32
  field :seen, 4, type: Opencannabis.Temporal.Instant
  field :location, 5, type: Opencannabis.Geo.Location
  field :accuracy, 6, type: Opencannabis.Geo.LocationAccuracy
end
