defmodule Opencannabis.Inventory.InventoryKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          uuid: String.t()
        }
  defstruct [:key, :uuid]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :uuid, 2, type: :string
end

defmodule Opencannabis.Inventory.InventoryCoordinates do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          location: String.t(),
          zone: String.t(),
          rack: String.t(),
          shelf: String.t(),
          bin: String.t(),
          batch: String.t()
        }
  defstruct [:location, :zone, :rack, :shelf, :bin, :batch]

  field :location, 1, type: :string
  field :zone, 2, type: :string
  field :rack, 3, type: :string
  field :shelf, 4, type: :string
  field :bin, 5, type: :string
  field :batch, 6, type: :string
end

defmodule Opencannabis.Inventory.InventoryAmount do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          basis: {atom, any},
          type: atom | integer,
          quantity: non_neg_integer
        }
  defstruct [:basis, :type, :quantity]

  oneof :basis, 0
  field :type, 1, type: Opencannabis.Structs.Pricing.PricingType, enum: true
  field :unit, 2, type: :bool, oneof: 0
  field :weight, 3, type: Opencannabis.Structs.Pricing.PricingWeightTier, enum: true, oneof: 0
  field :quantity, 4, type: :uint64
end

defmodule Opencannabis.Inventory.InventoryState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          status: atom | integer,
          coordinates: Opencannabis.Inventory.InventoryCoordinates.t() | nil,
          fit_for_sale: boolean,
          amount: Opencannabis.Inventory.InventoryAmount.t() | nil,
          created: Opencannabis.Temporal.Instant.t() | nil,
          modified: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:status, :coordinates, :fit_for_sale, :amount, :created, :modified]

  field :status, 1, type: Opencannabis.Inventory.InventoryState.Status, enum: true
  field :coordinates, 2, type: Opencannabis.Inventory.InventoryCoordinates
  field :fit_for_sale, 3, type: :bool
  field :amount, 4, type: Opencannabis.Inventory.InventoryAmount
  field :created, 98, type: Opencannabis.Temporal.Instant
  field :modified, 99, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Inventory.InventoryState.Status do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNRECONCILED, 0
  field :RECEIVING, 1
  field :QUARANTINE, 2
  field :ON_HAND, 3
  field :FOR_SALE, 4
  field :CLAIMED, 5
  field :COMMITTED, 6
end

defmodule Opencannabis.Inventory.InventoryProduct do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Inventory.InventoryKey.t() | nil,
          sku: [String.t()],
          variant: [Opencannabis.Commerce.VariantSpec.t()],
          state: Opencannabis.Inventory.InventoryState.t() | nil,
          history: [Opencannabis.Inventory.InventoryState.t()],
          item: Opencannabis.Products.Menu.MenuProduct.t() | nil
        }
  defstruct [:key, :sku, :variant, :state, :history, :item]

  field :key, 1, type: Opencannabis.Inventory.InventoryKey
  field :sku, 2, repeated: true, type: :string
  field :variant, 3, repeated: true, type: Opencannabis.Commerce.VariantSpec
  field :state, 10, type: Opencannabis.Inventory.InventoryState
  field :history, 11, repeated: true, type: Opencannabis.Inventory.InventoryState
  field :item, 20, type: Opencannabis.Products.Menu.MenuProduct
end
