defmodule Opencannabis.Inventory.Rfid.BoundaryConfig do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          start: Opencannabis.Inventory.Rfid.BoundaryConfig.StartTrigger.t() | nil,
          stop: Opencannabis.Inventory.Rfid.BoundaryConfig.StopTrigger.t() | nil
        }
  defstruct [:start, :stop]

  field :start, 1, type: Opencannabis.Inventory.Rfid.BoundaryConfig.StartTrigger
  field :stop, 2, type: Opencannabis.Inventory.Rfid.BoundaryConfig.StopTrigger
end

defmodule Opencannabis.Inventory.Rfid.BoundaryConfig.StartTrigger do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          schedule: non_neg_integer
        }
  defstruct [:type, :schedule]

  field :type, 1, type: Opencannabis.Inventory.Rfid.StartTriggerType, enum: true
  field :schedule, 2, type: :uint64
end

defmodule Opencannabis.Inventory.Rfid.BoundaryConfig.StopTrigger do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          schedule: non_neg_integer
        }
  defstruct [:type, :schedule]

  field :type, 1, type: Opencannabis.Inventory.Rfid.StopTriggerType, enum: true
  field :schedule, 2, type: :uint64
end

defmodule Opencannabis.Inventory.Rfid.ReportingConfig do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{}
  defstruct []
end

defmodule Opencannabis.Inventory.Rfid.ROSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: non_neg_integer,
          priority: non_neg_integer,
          boundary: Opencannabis.Inventory.Rfid.BoundaryConfig.t() | nil,
          reporting: Opencannabis.Inventory.Rfid.ReportingConfig.t() | nil
        }
  defstruct [:id, :priority, :boundary, :reporting]

  field :id, 1, type: :uint32
  field :priority, 2, type: :uint32
  field :boundary, 3, type: Opencannabis.Inventory.Rfid.BoundaryConfig
  field :reporting, 4, type: Opencannabis.Inventory.Rfid.ReportingConfig
end

defmodule Opencannabis.Inventory.Rfid.TagReportOrigin do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          reader: Opencannabis.Inventory.Rfid.Reader.t() | nil,
          partner: String.t(),
          location: String.t()
        }
  defstruct [:reader, :partner, :location]

  field :reader, 1, type: Opencannabis.Inventory.Rfid.Reader
  field :partner, 2, type: :string
  field :location, 3, type: :string
end

defmodule Opencannabis.Inventory.Rfid.TagReport do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          antenna: Opencannabis.Inventory.Rfid.Antenna.t() | nil,
          tag: Opencannabis.Inventory.Rfid.Tag.t() | nil,
          rssi: float,
          first_seen: Opencannabis.Temporal.Instant.t() | nil,
          last_seen: Opencannabis.Temporal.Instant.t() | nil,
          received: Opencannabis.Temporal.Instant.t() | nil,
          peers: non_neg_integer
        }
  defstruct [:antenna, :tag, :rssi, :first_seen, :last_seen, :received, :peers]

  field :antenna, 1, type: Opencannabis.Inventory.Rfid.Antenna
  field :tag, 2, type: Opencannabis.Inventory.Rfid.Tag
  field :rssi, 3, type: :double
  field :first_seen, 4, type: Opencannabis.Temporal.Instant
  field :last_seen, 5, type: Opencannabis.Temporal.Instant
  field :received, 6, type: Opencannabis.Temporal.Instant
  field :peers, 7, type: :uint32
end

defmodule Opencannabis.Inventory.Rfid.TagReportSet do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          origin: Opencannabis.Inventory.Rfid.TagReportOrigin.t() | nil,
          report: [Opencannabis.Inventory.Rfid.TagReport.t()]
        }
  defstruct [:origin, :report]

  field :origin, 1, type: Opencannabis.Inventory.Rfid.TagReportOrigin
  field :report, 2, repeated: true, type: Opencannabis.Inventory.Rfid.TagReport
end

defmodule Opencannabis.Inventory.Rfid.RegulatoryCapability do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_REGULATORY_REGION, 0
  field :US_FCC, 1
  field :ETSI_302_208, 2
  field :ETSI_300_220, 3
  field :AUSTRALIA_LIPD_1W, 4
  field :AUSTRALIA_LIPD_4W, 5
  field :JAPAN_ARIB_STD_T89, 6
  field :HONGKONG_OFTA_1049, 7
  field :TAIWAN_DGT_LP0002, 8
  field :KOREA_MIC_ARTICLE_5_2, 9
end

defmodule Opencannabis.Inventory.Rfid.StartTriggerType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_START_TRIGGER, 0
  field :IMMEDIATE, 1
  field :PERIODIC, 2
  field :GPIO_START, 3
end

defmodule Opencannabis.Inventory.Rfid.StopTriggerType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_STOP_TRIGGER, 0
  field :DURATION, 1
  field :GPIO_STOP, 2
end
