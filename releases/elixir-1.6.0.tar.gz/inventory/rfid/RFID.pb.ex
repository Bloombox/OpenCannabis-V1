defmodule Opencannabis.Inventory.Rfid.Reader do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: String.t(),
          mac: String.t(),
          ip: String.t(),
          vendor: atom | integer,
          model: atom | integer
        }
  defstruct [:name, :mac, :ip, :vendor, :model]

  field :name, 1, type: :string
  field :mac, 2, type: :string
  field :ip, 3, type: :string
  field :vendor, 4, type: Opencannabis.Inventory.Rfid.ReaderVendor, enum: true
  field :model, 5, type: Opencannabis.Inventory.Rfid.ReaderModel, enum: true
end

defmodule Opencannabis.Inventory.Rfid.Antenna do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          index: non_neg_integer
        }
  defstruct [:index]

  field :index, 1, type: :uint32
end

defmodule Opencannabis.Inventory.Rfid.Tag do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          content: {atom, any},
          tid: String.t(),
          payload: binary
        }
  defstruct [:content, :tid, :payload]

  oneof :content, 0
  field :tid, 1, type: :string
  field :payload, 2, type: :bytes
  field :epc, 10, type: :string, oneof: 0
end

defmodule Opencannabis.Inventory.Rfid.ReaderVendor do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNRECOGNIZED_VENDOR, 0
  field :IMPINJ, 25882
  field :ALIEN, 2
end

defmodule Opencannabis.Inventory.Rfid.ReaderModel do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNRECOGNIZED_READER, 0
  field :SPEEDWAY_R120, 1
  field :SPEEDWAY_R220, 2
  field :SPEEDWAY_R420, 2_001_002
  field :SPEEDWAY_XPORTAL, 4
  field :ALIEN_ALRH450, 5
  field :ALIEN_F800, 6
  field :ALIEN_ALR9680, 7
end
