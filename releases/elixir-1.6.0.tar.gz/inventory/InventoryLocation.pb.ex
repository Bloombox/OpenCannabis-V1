defmodule Opencannabis.Inventory.InventoryLocationKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uuid: String.t(),
          partner: String.t(),
          location: String.t()
        }
  defstruct [:uuid, :partner, :location]

  field :uuid, 1, type: :string
  field :partner, 2, type: :string
  field :location, 3, type: :string
end

defmodule Opencannabis.Inventory.InventoryLocation do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Inventory.InventoryLocationKey.t() | nil,
          type: atom | integer,
          name: String.t(),
          contact: Opencannabis.Contact.ContactInfo.t() | nil
        }
  defstruct [:key, :type, :name, :contact]

  field :key, 1, type: Opencannabis.Inventory.InventoryLocationKey
  field :type, 2, type: Opencannabis.Inventory.InventoryLocationType, enum: true
  field :name, 3, type: :string
  field :contact, 4, type: Opencannabis.Contact.ContactInfo
end

defmodule Opencannabis.Inventory.InventoryBinding do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          held_by: Opencannabis.Inventory.InventoryLocationKey.t() | nil,
          item: Opencannabis.Inventory.InventoryProduct.t() | nil
        }
  defstruct [:held_by, :item]

  field :held_by, 1, type: Opencannabis.Inventory.InventoryLocationKey
  field :item, 2, type: Opencannabis.Inventory.InventoryProduct
end

defmodule Opencannabis.Inventory.InventoryLocationType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :RETAIL, 0
  field :WAREHOUSE, 1
  field :PRODUCTION, 2
end
