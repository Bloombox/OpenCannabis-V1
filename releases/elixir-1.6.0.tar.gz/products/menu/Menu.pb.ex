defmodule Opencannabis.Products.Menu.MenuSettings do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          full: boolean,
          keys_only: boolean,
          snapshot: Opencannabis.Crypto.Hash.t() | nil,
          fingerprint: Opencannabis.Crypto.Hash.t() | nil,
          section: [atom | integer],
          available_section: [atom | integer]
        }
  defstruct [:full, :keys_only, :snapshot, :fingerprint, :section, :available_section]

  field :full, 1, type: :bool
  field :keys_only, 2, type: :bool
  field :snapshot, 3, type: Opencannabis.Crypto.Hash
  field :fingerprint, 4, type: Opencannabis.Crypto.Hash
  field :section, 5, repeated: true, type: Opencannabis.Products.Menu.Section.Section, enum: true

  field :available_section, 6,
    repeated: true,
    type: Opencannabis.Products.Menu.Section.Section,
    enum: true
end

defmodule Opencannabis.Products.Menu.Metadata do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          scope: String.t(),
          version: non_neg_integer,
          status: atom | integer,
          flags: [atom | integer],
          published: Opencannabis.Temporal.Instant.t() | nil,
          settings: Opencannabis.Products.Menu.MenuSettings.t() | nil
        }
  defstruct [:scope, :version, :status, :flags, :published, :settings]

  field :scope, 1, type: :string
  field :version, 2, type: :uint64
  field :status, 3, type: Opencannabis.Products.Menu.Status, enum: true
  field :flags, 4, repeated: true, type: Opencannabis.Products.Menu.Flag, enum: true
  field :published, 5, type: Opencannabis.Temporal.Instant
  field :settings, 6, type: Opencannabis.Products.Menu.MenuSettings
end

defmodule Opencannabis.Products.Menu.ProductTag do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          display: String.t(),
          color: String.t()
        }
  defstruct [:id, :display, :color]

  field :id, 1, type: :string
  field :display, 2, type: :string
  field :color, 3, type: :string
end

defmodule Opencannabis.Products.Menu.ForeignReference do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          domain: String.t(),
          link: String.t(),
          attached: Opencannabis.Temporal.Instant.t() | nil,
          validated: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:key, :domain, :link, :attached, :validated]

  field :key, 1, type: :string
  field :domain, 2, type: :string
  field :link, 3, type: :string
  field :attached, 4, type: Opencannabis.Temporal.Instant
  field :validated, 5, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Products.Menu.MenuProduct do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          product: {atom, any},
          key: Opencannabis.Base.ProductKey.t() | nil,
          tag: [Opencannabis.Products.Menu.ProductTag.t()],
          ref: [Opencannabis.Products.Menu.ForeignReference.t()]
        }
  defstruct [:product, :key, :tag, :ref]

  oneof :product, 0
  field :key, 1, type: Opencannabis.Base.ProductKey
  field :tag, 2, repeated: true, type: Opencannabis.Products.Menu.ProductTag
  field :ref, 3, repeated: true, type: Opencannabis.Products.Menu.ForeignReference
  field :apothecary, 10, type: Opencannabis.Products.Apothecary, oneof: 0
  field :cartridge, 11, type: Opencannabis.Products.Cartridge, oneof: 0
  field :edible, 12, type: Opencannabis.Products.Edible, oneof: 0
  field :extract, 13, type: Opencannabis.Products.Extract, oneof: 0
  field :flower, 14, type: Opencannabis.Products.Flower, oneof: 0
  field :merchandise, 15, type: Opencannabis.Products.Merchandise, oneof: 0
  field :plant, 16, type: Opencannabis.Products.Plant, oneof: 0
  field :preroll, 17, type: Opencannabis.Products.Preroll, oneof: 0
end

defmodule Opencannabis.Products.Menu.SectionData do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          count: integer,
          section: Opencannabis.Products.Menu.Section.SectionSpec.t() | nil,
          product: [Opencannabis.Products.Menu.MenuProduct.t()]
        }
  defstruct [:count, :section, :product]

  field :count, 1, type: :int32
  field :section, 2, type: Opencannabis.Products.Menu.Section.SectionSpec
  field :product, 3, repeated: true, type: Opencannabis.Products.Menu.MenuProduct
end

defmodule Opencannabis.Products.Menu.SectionedMenu do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          count: integer,
          payload: [Opencannabis.Products.Menu.SectionData.t()]
        }
  defstruct [:count, :payload]

  field :count, 1, type: :int32
  field :payload, 2, repeated: true, type: Opencannabis.Products.Menu.SectionData
end

defmodule Opencannabis.Products.Menu.StaticMenu do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          apothecary: %{String.t() => Opencannabis.Products.Apothecary.t() | nil},
          cartridges: %{String.t() => Opencannabis.Products.Cartridge.t() | nil},
          edibles: %{String.t() => Opencannabis.Products.Edible.t() | nil},
          extracts: %{String.t() => Opencannabis.Products.Extract.t() | nil},
          flowers: %{String.t() => Opencannabis.Products.Flower.t() | nil},
          merchandise: %{String.t() => Opencannabis.Products.Merchandise.t() | nil},
          plants: %{String.t() => Opencannabis.Products.Plant.t() | nil},
          prerolls: %{String.t() => Opencannabis.Products.Preroll.t() | nil}
        }
  defstruct [
    :apothecary,
    :cartridges,
    :edibles,
    :extracts,
    :flowers,
    :merchandise,
    :plants,
    :prerolls
  ]

  field :apothecary, 1,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.ApothecaryEntry,
    map: true

  field :cartridges, 2,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.CartridgesEntry,
    map: true

  field :edibles, 3,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.EdiblesEntry,
    map: true

  field :extracts, 4,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.ExtractsEntry,
    map: true

  field :flowers, 5,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.FlowersEntry,
    map: true

  field :merchandise, 6,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.MerchandiseEntry,
    map: true

  field :plants, 7,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.PlantsEntry,
    map: true

  field :prerolls, 8,
    repeated: true,
    type: Opencannabis.Products.Menu.StaticMenu.PrerollsEntry,
    map: true
end

defmodule Opencannabis.Products.Menu.StaticMenu.ApothecaryEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Apothecary.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Apothecary
end

defmodule Opencannabis.Products.Menu.StaticMenu.CartridgesEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Cartridge.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Cartridge
end

defmodule Opencannabis.Products.Menu.StaticMenu.EdiblesEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Edible.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Edible
end

defmodule Opencannabis.Products.Menu.StaticMenu.ExtractsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Extract.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Extract
end

defmodule Opencannabis.Products.Menu.StaticMenu.FlowersEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Flower.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Flower
end

defmodule Opencannabis.Products.Menu.StaticMenu.MerchandiseEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Merchandise.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Merchandise
end

defmodule Opencannabis.Products.Menu.StaticMenu.PlantsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Plant.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Plant
end

defmodule Opencannabis.Products.Menu.StaticMenu.PrerollsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Products.Preroll.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Products.Preroll
end

defmodule Opencannabis.Products.Menu.Menu do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          content: {atom, any},
          metadata: Opencannabis.Products.Menu.Metadata.t() | nil
        }
  defstruct [:content, :metadata]

  oneof :content, 0
  field :metadata, 1, type: Opencannabis.Products.Menu.Metadata
  field :payload, 3, type: Opencannabis.Products.Menu.SectionedMenu, oneof: 0
  field :menu, 4, type: Opencannabis.Products.Menu.StaticMenu, oneof: 0
end

defmodule Opencannabis.Products.Menu.Status do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNPUBLISHED, 0
  field :LIVE, 1
end

defmodule Opencannabis.Products.Menu.Flag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DRAFT, 0
  field :PRIVATE, 1
  field :OUT_OF_DATE, 2
end
