defmodule Opencannabis.Products.Apothecary do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :type, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.ApothecaryType, enum: true
  field :product, 3, type: Opencannabis.Content.ProductContent
  field :material, 4, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.ApothecaryType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_APOTHECARY, 0
  field :TOPICAL, 1
  field :TINCTURE, 2
  field :CAPSULE, 3
  field :INJECTOR, 4
end
