defmodule Opencannabis.Products.EdibleIngredient do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          label: String.t(),
          amount: String.t()
        }
  defstruct [:label, :amount]

  field :label, 1, type: :string
  field :amount, 2, type: :string
end

defmodule Opencannabis.Products.Edible do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          flags: [atom | integer],
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil,
          ingredients: [Opencannabis.Products.EdibleIngredient.t()]
        }
  defstruct [:key, :type, :flags, :product, :material, :ingredients]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.EdibleType, enum: true
  field :flags, 3, repeated: true, type: Opencannabis.Products.EdibleFlag, enum: true
  field :product, 4, type: Opencannabis.Content.ProductContent
  field :material, 5, type: Opencannabis.Content.MaterialsData
  field :ingredients, 6, repeated: true, type: Opencannabis.Products.EdibleIngredient
end

defmodule Opencannabis.Products.EdibleType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_EDIBLE, 0
  field :CHOCOLATE, 1
  field :BAKED_GOOD, 2
  field :CANDY, 3
  field :BEVERAGE, 4
  field :LOZENGE, 5
  field :SUBLINGUAL, 6
  field :GUMMY, 7
  field :BUTTER, 8
  field :OILS, 9
  field :CEREAL, 10
end

defmodule Opencannabis.Products.EdibleFlag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_EDIBLE_FLAG, 0
  field :VEGAN, 1
  field :GLUTEN_FREE, 2
  field :SUGAR_FREE, 3
  field :FAIR_TRADE, 4
  field :ORGANIC, 5
  field :LOCAL, 6
end
