defmodule Bloombox.Partner.LocationKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          partner: Bloombox.Partner.PartnerKey.t() | nil,
          code: String.t()
        }
  defstruct [:partner, :code]

  field :partner, 1, type: Bloombox.Partner.PartnerKey
  field :code, 2, type: :string
end
